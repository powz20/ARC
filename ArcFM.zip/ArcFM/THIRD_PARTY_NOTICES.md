# Avisos de terceiros

## zstd 1.5.7

Biblioteca de compressão Zstandard (Facebook/Meta, Yann Collet). Fontes em `app/src/main/cpp/zstd/`,
licença em `app/src/main/cpp/zstd/LICENSE` (dupla: BSD ou GPLv2, usada aqui sob BSD).
A camada JNI (`zstd_jni.c`, `zstd_core.c`) é do ArcFM.

## Bibliotecas

- lz4-java (at.yawk.lz4), Apache 2.0
- Apache Commons Compress, Apache Commons Lang, Apache 2.0
- XZ for Java (org.tukaani), Public Domain
- Commons IO, Apache 2.0
- AndroidX Annotation, Apache 2.0
