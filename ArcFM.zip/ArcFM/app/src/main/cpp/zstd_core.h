#ifndef ARCFM_ZSTD_CORE_H
#define ARCFM_ZSTD_CORE_H
#include <stddef.h>

/* Compressão em streaming. Retorna NULL se falhar. */
void* arcfm_cctx_new(int level);
void arcfm_cctx_free(void* c);

/*
 * Um passo de compressão: consome de in (a partir de *inPos) e grava em out (a partir de *outPos).
 * end != 0 finaliza o frame. Retorno: 0 = pronto (com end, frame finalizado);
 * >0 = ainda há saída pendente; <0 = erro (ver arcfm_last_error).
 */
long arcfm_compress(void* c, const void* in, size_t inLen, size_t* inPos,
                    void* out, size_t outCap, size_t* outPos, int end);

/* Descompressão em streaming. */
void* arcfm_dctx_new(void);
void arcfm_dctx_free(void* d);

/* Retorno: 0 = frame completo; >0 = precisa de mais entrada ou saída; <0 = erro. */
long arcfm_decompress(void* d, const void* in, size_t inLen, size_t* inPos,
                      void* out, size_t outCap, size_t* outPos);

/* Mensagem do último erro (texto do zstd). */
const char* arcfm_last_error(void);

#endif
