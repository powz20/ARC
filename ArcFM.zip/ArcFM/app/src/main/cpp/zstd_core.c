#include "zstd_core.h"
#include "zstd/zstd.h"
#include "zstd/zstd_errors.h"

static size_t g_last_err = 0;

void* arcfm_cctx_new(int level) {
    ZSTD_CCtx* c = ZSTD_createCCtx();
    if (c == NULL) return NULL;
    if (ZSTD_isError(ZSTD_CCtx_setParameter(c, ZSTD_c_compressionLevel, level))) {
        ZSTD_freeCCtx(c);
        return NULL;
    }
    /* checksum do conteúdo: detecta arquivo corrompido ao descompactar */
    ZSTD_CCtx_setParameter(c, ZSTD_c_checksumFlag, 1);
    return c;
}

void arcfm_cctx_free(void* c) {
    if (c != NULL) ZSTD_freeCCtx((ZSTD_CCtx*)c);
}

long arcfm_compress(void* c, const void* in, size_t inLen, size_t* inPos,
                    void* out, size_t outCap, size_t* outPos, int end) {
    ZSTD_inBuffer ib;
    ZSTD_outBuffer ob;
    size_t r;
    ib.src = in;  ib.size = inLen;  ib.pos = *inPos;
    ob.dst = out; ob.size = outCap; ob.pos = *outPos;
    r = ZSTD_compressStream2((ZSTD_CCtx*)c, &ob, &ib, end ? ZSTD_e_end : ZSTD_e_continue);
    *inPos = ib.pos;
    *outPos = ob.pos;
    if (ZSTD_isError(r)) {
        g_last_err = r;
        return -1;
    }
    return (long)r;
}

void* arcfm_dctx_new(void) {
    return ZSTD_createDCtx();
}

void arcfm_dctx_free(void* d) {
    if (d != NULL) ZSTD_freeDCtx((ZSTD_DCtx*)d);
}

long arcfm_decompress(void* d, const void* in, size_t inLen, size_t* inPos,
                      void* out, size_t outCap, size_t* outPos) {
    ZSTD_inBuffer ib;
    ZSTD_outBuffer ob;
    size_t r;
    ib.src = in;  ib.size = inLen;  ib.pos = *inPos;
    ob.dst = out; ob.size = outCap; ob.pos = *outPos;
    r = ZSTD_decompressStream((ZSTD_DCtx*)d, &ob, &ib);
    *inPos = ib.pos;
    *outPos = ob.pos;
    if (ZSTD_isError(r)) {
        g_last_err = r;
        return -1;
    }
    return (long)r;
}

const char* arcfm_last_error(void) {
    return ZSTD_getErrorName(g_last_err);
}
