LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := arcfmzstd
LOCAL_SRC_FILES := zstd_core.c zstd_jni.c \
    $(patsubst $(LOCAL_PATH)/%,%,$(wildcard $(LOCAL_PATH)/zstd/common/*.c)) \
    $(patsubst $(LOCAL_PATH)/%,%,$(wildcard $(LOCAL_PATH)/zstd/compress/*.c)) \
    $(patsubst $(LOCAL_PATH)/%,%,$(wildcard $(LOCAL_PATH)/zstd/decompress/*.c))
LOCAL_C_INCLUDES := $(LOCAL_PATH)
LOCAL_CFLAGS := -O2 -Wall -DZSTD_DISABLE_ASM
include $(BUILD_SHARED_LIBRARY)
