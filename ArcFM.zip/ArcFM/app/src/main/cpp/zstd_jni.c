/* Camada JNI fina sobre zstd_core.c (classe com.example.arcfm.zstd.Zstd). */
#include <jni.h>
#include <stddef.h>
#include <stdint.h>
#include "zstd_core.h"

static void throwIo(JNIEnv* env, const char* msg) {
    jclass cls = (*env)->FindClass(env, "java/io/IOException");
    if (cls != NULL) (*env)->ThrowNew(env, cls, msg);
}

JNIEXPORT jlong JNICALL
Java_com_example_arcfm_zstd_Zstd_nCreateC(JNIEnv* env, jclass clazz, jint level) {
    void* c = arcfm_cctx_new((int)level);
    if (c == NULL) throwIo(env, "zstd: não foi possível criar o compressor");
    return (jlong)(intptr_t)c;
}

JNIEXPORT void JNICALL
Java_com_example_arcfm_zstd_Zstd_nFreeC(JNIEnv* env, jclass clazz, jlong h) {
    arcfm_cctx_free((void*)(intptr_t)h);
}

JNIEXPORT jlong JNICALL
Java_com_example_arcfm_zstd_Zstd_nCreateD(JNIEnv* env, jclass clazz) {
    void* d = arcfm_dctx_new();
    if (d == NULL) throwIo(env, "zstd: não foi possível criar o descompressor");
    return (jlong)(intptr_t)d;
}

JNIEXPORT void JNICALL
Java_com_example_arcfm_zstd_Zstd_nFreeD(JNIEnv* env, jclass clazz, jlong h) {
    arcfm_dctx_free((void*)(intptr_t)h);
}

/* st[0] = bytes consumidos da entrada, st[1] = bytes gravados na saída. Retorna o "hint" do zstd. */
JNIEXPORT jint JNICALL
Java_com_example_arcfm_zstd_Zstd_nCompress(JNIEnv* env, jclass clazz, jlong h,
        jbyteArray in, jint inOff, jint inLen,
        jbyteArray out, jint outOff, jint outLen, jboolean end, jintArray st) {
    jbyte* ip = (*env)->GetByteArrayElements(env, in, NULL);
    jbyte* op = (*env)->GetByteArrayElements(env, out, NULL);
    jint* s = (*env)->GetIntArrayElements(env, st, NULL);
    size_t ipos = 0, opos = 0;
    long r = arcfm_compress((void*)(intptr_t)h, ip + inOff, (size_t)inLen, &ipos,
                            op + outOff, (size_t)outLen, &opos, end ? 1 : 0);
    s[0] = (jint)ipos;
    s[1] = (jint)opos;
    (*env)->ReleaseIntArrayElements(env, st, s, 0);
    (*env)->ReleaseByteArrayElements(env, out, op, 0);
    (*env)->ReleaseByteArrayElements(env, in, ip, JNI_ABORT);
    if (r < 0) {
        throwIo(env, arcfm_last_error());
        return 0;
    }
    return (jint)r;
}

JNIEXPORT jint JNICALL
Java_com_example_arcfm_zstd_Zstd_nDecompress(JNIEnv* env, jclass clazz, jlong h,
        jbyteArray in, jint inOff, jint inLen,
        jbyteArray out, jint outOff, jint outLen, jintArray st) {
    jbyte* ip = (*env)->GetByteArrayElements(env, in, NULL);
    jbyte* op = (*env)->GetByteArrayElements(env, out, NULL);
    jint* s = (*env)->GetIntArrayElements(env, st, NULL);
    size_t ipos = 0, opos = 0;
    long r = arcfm_decompress((void*)(intptr_t)h, ip + inOff, (size_t)inLen, &ipos,
                              op + outOff, (size_t)outLen, &opos);
    s[0] = (jint)ipos;
    s[1] = (jint)opos;
    (*env)->ReleaseIntArrayElements(env, st, s, 0);
    (*env)->ReleaseByteArrayElements(env, out, op, 0);
    (*env)->ReleaseByteArrayElements(env, in, ip, JNI_ABORT);
    if (r < 0) {
        throwIo(env, arcfm_last_error());
        return 0;
    }
    return (jint)r;
}
