package com.example.arcfm.filesystem;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Resolve nomes de entradas de arquivos compactados sem sair da pasta de destino. */
public final class SafePath {
    private SafePath() {
    }

    public static File resolve(File destDir, String entryName, FileLimits limits) throws IOException {
        String n = entryName.replace('\\', '/');
        if (n.indexOf('\0') >= 0) throw new IOException("Nome inválido no arquivo");
        while (n.startsWith("./")) n = n.substring(2);
        if (n.startsWith("/") || n.matches("^[A-Za-z]:.*")) {
            throw new IOException("Caminho absoluto no arquivo: " + entryName);
        }
        int depth = 0;
        for (String part : n.split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) throw new IOException("Caminho com '..' no arquivo: " + entryName);
            depth++;
        }
        if (limits != null && limits.enabled && depth > limits.maxDepth) {
            throw new IOException("Pastas aninhadas demais: " + entryName);
        }
        File out = new File(destDir, n);
        String destCanon = destDir.getCanonicalPath();
        String outCanon = out.getCanonicalPath();
        if (!outCanon.equals(destCanon) && !outCanon.startsWith(destCanon + File.separator)) {
            throw new IOException("Entrada fora da pasta de destino: " + entryName);
        }
        rejectSymlinks(destDir, out);
        return out;
    }

    /** Nenhum componente já existente entre o destino e a entrada pode ser link simbólico. */
    private static void rejectSymlinks(File destDir, File out) throws IOException {
        Path base = destDir.toPath().toAbsolutePath().normalize();
        Path p = out.toPath().toAbsolutePath().normalize();
        while (p != null && !p.equals(base) && p.startsWith(base)) {
            if (Files.isSymbolicLink(p)) throw new IOException("O destino passa por um link simbólico: " + p.getFileName());
            p = p.getParent();
        }
    }
}
