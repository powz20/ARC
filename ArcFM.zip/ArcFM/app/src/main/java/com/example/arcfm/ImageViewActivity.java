package com.example.arcfm;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

/** Visualizador simples: pinça para zoom, arrastar, toque duplo para ampliar; X ou Voltar para sair. */
public class ImageViewActivity extends Activity {
    private ImageView image;
    private final Matrix matrix = new Matrix();
    private Bitmap bmp;
    private float minScale = 1f;
    private ScaleGestureDetector scaleDetector;
    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        String path = getIntent().getStringExtra("path");
        final File f = path == null ? null : new File(path);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final float dens = dm.density;
        int maxSide = Math.max(dm.widthPixels, dm.heightPixels) * 2;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        if (f != null) BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / sample > maxSide) sample *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = sample;
        bmp = f == null ? null : BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        if (bmp == null) {
            Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.MATRIX);
        image.setImageBitmap(bmp);
        root.addView(image, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView close = new TextView(this);
        close.setText("\u2715");
        close.setTextColor(Color.WHITE);
        close.setTextSize(20);
        close.setGravity(Gravity.CENTER);
        close.setBackgroundColor(0x88000000);
        int size = Math.round(48 * dens);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(size, size, Gravity.TOP | Gravity.END);
        int m = Math.round(8 * dens);
        clp.setMargins(m, m, m, m);
        close.setOnClickListener(v -> finish());
        root.addView(close, clp);

        TextView title = new TextView(this);
        title.setText(f.getName());
        title.setTextColor(Color.WHITE);
        title.setTextSize(13);
        title.setSingleLine(true);
        title.setBackgroundColor(0x88000000);
        int p = Math.round(10 * dens);
        title.setPadding(p, p, p, p);
        root.addView(title, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float cur = currentScale();
                float target = Math.max(minScale, Math.min(cur * d.getScaleFactor(), minScale * 8f));
                float k = target / cur;
                matrix.postScale(k, k, d.getFocusX(), d.getFocusY());
                apply();
                return true;
            }
        });
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                matrix.postTranslate(-dx, -dy);
                apply();
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (currentScale() > minScale * 1.5f) {
                    fit();
                } else {
                    float k = (minScale * 3f) / currentScale();
                    matrix.postScale(k, k, e.getX(), e.getY());
                    apply();
                }
                return true;
            }
        });
        image.setOnTouchListener((v, e) -> {
            scaleDetector.onTouchEvent(e);
            gestureDetector.onTouchEvent(e);
            return true;
        });
        setContentView(root);
        image.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                image.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                fit();
            }
        });
    }

    private void fit() {
        int vw = image.getWidth();
        int vh = image.getHeight();
        if (vw == 0 || vh == 0) return;
        float s = Math.min((float) vw / bmp.getWidth(), (float) vh / bmp.getHeight());
        minScale = s;
        matrix.reset();
        matrix.postScale(s, s);
        matrix.postTranslate((vw - bmp.getWidth() * s) / 2f, (vh - bmp.getHeight() * s) / 2f);
        apply();
    }

    private float currentScale() {
        float[] v = new float[9];
        matrix.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    private void apply() {
        keepInside();
        image.setImageMatrix(matrix);
    }

    /** Não deixa a imagem sair totalmente da tela; centraliza quando ela é menor que a tela. */
    private void keepInside() {
        int vw = image.getWidth();
        int vh = image.getHeight();
        if (vw == 0 || vh == 0) return;
        RectF r = new RectF(0, 0, bmp.getWidth(), bmp.getHeight());
        matrix.mapRect(r);
        float dx = 0;
        float dy = 0;
        if (r.width() <= vw) dx = (vw - r.width()) / 2f - r.left;
        else if (r.left > 0) dx = -r.left;
        else if (r.right < vw) dx = vw - r.right;
        if (r.height() <= vh) dy = (vh - r.height()) / 2f - r.top;
        else if (r.top > 0) dy = -r.top;
        else if (r.bottom < vh) dy = vh - r.bottom;
        matrix.postTranslate(dx, dy);
    }

    @Override
    protected void onDestroy() {
        if (bmp != null && !bmp.isRecycled()) bmp.recycle();
        super.onDestroy();
    }
}
