package com.example.arcfm.zstd;

/** Ponte para a biblioteca nativa libarcfmzstd.so (zstd 1.5.7, compilada com NDK). */
public final class Zstd {
    static {
        System.loadLibrary("arcfmzstd");
    }

    private Zstd() {
    }

    static native long nCreateC(int level);

    static native void nFreeC(long h);

    static native long nCreateD();

    static native void nFreeD(long h);

    /** st[0] = consumidos, st[1] = gravados. Retorna 0 quando o frame está finalizado (com end). */
    static native int nCompress(long h, byte[] in, int inOff, int inLen,
                                byte[] out, int outOff, int outLen, boolean end, int[] st);

    /** st[0] = consumidos, st[1] = gravados. Retorna 0 quando o frame está completo. */
    static native int nDecompress(long h, byte[] in, int inOff, int inLen,
                                  byte[] out, int outOff, int outLen, int[] st);
}
