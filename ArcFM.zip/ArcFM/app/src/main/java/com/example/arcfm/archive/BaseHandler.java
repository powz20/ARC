package com.example.arcfm.archive;

import com.example.arcfm.filesystem.FileNames;
import com.example.arcfm.filesystem.FileScanner;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

abstract class BaseHandler implements ArchiveHandler {
    protected final ArchiveOptions o;

    BaseHandler(ArchiveOptions o) {
        this.o = o;
    }

    static boolean ends(File f, String[] exts) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        for (String e : exts) {
            if (n.endsWith(e)) return true;
        }
        return false;
    }

    static void checkCancel(ProgressListener l) throws ArchiveCancelledException {
        if (l != null && l.isCancelled()) throw new ArchiveCancelledException();
    }

    /** Devolve onde gravar, ou null para pular o arquivo (política de sobrescrita). */
    File resolveConflict(File out) {
        if (!out.exists()) return out;
        int act = o.conflicts == null ? ArchiveOptions.REPLACE : o.conflicts.resolve(out);
        if (act == ArchiveOptions.SKIP) {
            o.stats.skipped++;
            return null;
        }
        if (act == ArchiveOptions.KEEP_BOTH) return FileNames.sibling(out);
        FileScanner.deleteTree(out);
        return out;
    }

    @Override
    public void test(File input) throws IOException {
        test(input, ProgressListener.NONE);
    }
}
