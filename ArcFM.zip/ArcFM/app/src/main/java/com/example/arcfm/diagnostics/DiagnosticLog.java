package com.example.arcfm.diagnostics;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Registro de diagnóstico (desligado por padrão, com limite de tamanho e rotação). */
public final class DiagnosticLog {
    private DiagnosticLog() {
    }

    private static final long MAX_BYTES = 512 * 1024;

    private static File file;
    private static File old;
    private static boolean enabled;
    private static String appVersion = "?";
    private static String env = "?";

    public static final class Record {
        public long id;
        public String format = "";
        public String algorithm = "";
        public String level = "";
        public String input = "";
        public String output = "";
        public long inputBytes = -1;
        public long outputBytes = -1;
        public long partialOutputBytes = -1;
        public long processedBytes;
        public long durationMs;
        public String result = "";
        public String stage = "";
        public Throwable error;
    }

    public static synchronized void init(File dir, String versionName, String environment, boolean on) {
        file = new File(dir, "diagnostico.log");
        old = new File(dir, "diagnostico.1.log");
        appVersion = versionName;
        env = environment;
        enabled = on;
    }

    public static synchronized void setEnabled(boolean on) {
        enabled = on;
    }

    public static synchronized boolean isEnabled() {
        return enabled;
    }

    public static synchronized void log(Record r) {
        if (!enabled || file == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("==== tarefa ").append(r.id).append(" — ")
                .append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())).append('\n');
        sb.append("ArcFM ").append(appVersion).append(" | ").append(env).append('\n');
        sb.append("formato: ").append(r.format).append(" | algoritmo: ").append(r.algorithm)
                .append(" | nível: ").append(r.level).append('\n');
        sb.append("entrada: ").append(r.input).append(" (").append(r.inputBytes).append(" bytes)\n");
        sb.append("saída: ").append(r.output).append(" (").append(r.outputBytes).append(" bytes)");
        if (r.partialOutputBytes >= 0) sb.append(" | parcial na falha: ").append(r.partialOutputBytes).append(" bytes");
        sb.append('\n');
        sb.append("processado: ").append(r.processedBytes).append(" bytes | duração: ").append(r.durationMs)
                .append(" ms\n");
        sb.append("resultado: ").append(r.result).append(" | etapa: ").append(r.stage).append('\n');
        if (r.error != null) {
            sb.append("exceção: ").append(r.error.getClass().getName()).append(" — ").append(r.error.getMessage())
                    .append('\n');
            StringWriter sw = new StringWriter();
            r.error.printStackTrace(new PrintWriter(sw));
            sb.append(sw).append('\n');
        }
        sb.append('\n');
        try {
            if (file.length() > MAX_BYTES) {
                old.delete();
                file.renameTo(old);
            }
            try (Writer w = new OutputStreamWriter(new FileOutputStream(file, true), StandardCharsets.UTF_8)) {
                w.write(sb.toString());
            }
        } catch (IOException ignored) {
            // diagnóstico nunca pode quebrar a operação
        }
    }

    public static synchronized String read() {
        StringBuilder sb = new StringBuilder();
        for (File f : new File[]{old, file}) {
            if (f == null || !f.isFile()) continue;
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            } catch (IOException ignored) {
                // segue com o que deu para ler
            }
        }
        return sb.length() == 0 ? "(registro vazio)" : sb.toString();
    }

    public static synchronized void clear() {
        if (file != null) file.delete();
        if (old != null) old.delete();
    }
}
