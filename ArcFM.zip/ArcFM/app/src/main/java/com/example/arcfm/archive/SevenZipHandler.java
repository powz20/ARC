package com.example.arcfm.archive;

import com.example.arcfm.filesystem.FileScanner;
import com.example.arcfm.filesystem.SafePath;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.sevenz.SevenZMethod;
import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;
import org.tukaani.xz.LZMA2Options;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.zip.CRC32;

public final class SevenZipHandler extends BaseHandler {
    private static final String[] EXT = {".7z"};

    public SevenZipHandler(ArchiveOptions o) {
        super(o);
    }

    @Override
    public boolean canRead(File f) {
        return ends(f, EXT);
    }

    @Override
    public String[] getExtensions() {
        return EXT.clone();
    }

    private SevenZFile open(File f) throws IOException {
        SevenZFile.Builder b = SevenZFile.builder();
        b.setFile(f);
        if (o.password != null) b.setPassword(o.password);
        return b.get();
    }

    // ------------------------------------------------------------------ compactar

    @Override
    public void compress(List<File> inputs, File outFile, ProgressListener l) throws IOException {
        long total = FileScanner.sizeOf(inputs);
        SevenZOutputFile out7 = new SevenZOutputFile(outFile);
        boolean ok = false;
        try {
            int level = Math.max(0, Math.min(o.level, 5));
            if (level == 0) {
                out7.setContentCompression(SevenZMethod.COPY);
            } else {
                String m = o.compat ? "LZMA" : o.method7z;
                SevenZMethodConfiguration cfg;
                if ("BZIP2".equals(m)) {
                    cfg = new SevenZMethodConfiguration(SevenZMethod.BZIP2);
                } else if ("DEFLATE".equals(m)) {
                    cfg = new SevenZMethodConfiguration(SevenZMethod.DEFLATE, Codecs.ZIP_LEVELS[level]);
                } else {
                    cfg = new SevenZMethodConfiguration("LZMA".equals(m) ? SevenZMethod.LZMA : SevenZMethod.LZMA2,
                            new LZMA2Options(Codecs.SEVENZ_PRESETS[level]));
                }
                out7.setContentMethods(Collections.singletonList(cfg));
            }
            long[] done = {0};
            byte[] buf = new byte[64 * 1024];
            for (File f : inputs) add(out7, f, f.getName(), outFile, buf, done, total, l);
            checkCancel(l);
            out7.finish();
            out7.close();
            ok = true;
        } finally {
            if (!ok) {
                try {
                    out7.close();
                } catch (IOException ignored) {
                    // incompleto: será apagado
                }
            }
        }
    }

    private void add(SevenZOutputFile out7, File f, String name, File outFile, byte[] buf, long[] done, long total,
                     ProgressListener l) throws IOException {
        checkCancel(l);
        if (f.getAbsolutePath().equals(outFile.getAbsolutePath())) return;
        boolean dir = f.isDirectory();
        if (!dir && !f.isFile()) return;
        SevenZArchiveEntry e = new SevenZArchiveEntry();
        e.setName(name);
        e.setDirectory(dir);
        e.setLastModifiedDate(new Date(f.lastModified()));
        if (dir) {
            out7.putArchiveEntry(e);
            out7.closeArchiveEntry();
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) add(out7, k, name + "/" + k.getName(), outFile, buf, done, total, l);
            }
            return;
        }
        FileInputStream in;
        try {
            in = new FileInputStream(f);
        } catch (FileNotFoundException ex) {
            o.stats.skipped++;
            return;
        }
        try {
            out7.putArchiveEntry(e);
            int n;
            while ((n = in.read(buf)) != -1) {
                out7.write(buf, 0, n);
                done[0] += n;
                l.onProgress(name, done[0], total);
                checkCancel(l);
            }
            out7.closeArchiveEntry();
        } finally {
            in.close();
        }
    }

    // ------------------------------------------------------------------ extrair

    @Override
    public void extract(File input, File dest, ProgressListener l) throws IOException {
        SevenZFile sz = open(input);
        try {
            o.limits.begin(input.length());
            long total = 0;
            for (SevenZArchiveEntry e : sz.getEntries()) {
                if (!e.isDirectory() && e.getSize() > 0) total += e.getSize();
            }
            if (!dest.exists() && !dest.mkdirs()) throw new IOException("Não foi possível criar a pasta de destino");
            byte[] buf = new byte[64 * 1024];
            long done = 0;
            SevenZArchiveEntry e;
            while ((e = sz.getNextEntry()) != null) {
                checkCancel(l);
                o.limits.entry(e.getName(), e.getSize());
                File out = SafePath.resolve(dest, e.getName(), o.limits);
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                if (e.isAntiItem()) continue;
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                File target = resolveConflict(out);
                if (target == null) {
                    if (e.getSize() > 0) done += e.getSize();
                    continue;
                }
                CRC32 crc = new CRC32();
                boolean ok = false;
                try (OutputStream os = new FileOutputStream(target)) {
                    int n;
                    while ((n = sz.read(buf)) != -1) {
                        o.limits.bytes(n);
                        os.write(buf, 0, n);
                        crc.update(buf, 0, n);
                        done += n;
                        l.onProgress(e.getName(), done, total);
                        checkCancel(l);
                    }
                    ok = true;
                } finally {
                    if (!ok) target.delete();
                }
                if (o.verifyAfterExtract && e.getHasCrc() && crc.getValue() != (e.getCrcValue() & 0xFFFFFFFFL)) {
                    target.delete();
                    throw new IOException("CRC inválido após extrair: " + e.getName());
                }
                if (e.getHasLastModifiedDate()) {
                    long t = e.getLastModifiedDate().getTime();
                    if (t > 0) target.setLastModified(t);
                }
                o.stats.files++;
            }
        } finally {
            sz.close();
        }
    }

    // ------------------------------------------------------------------ testar

    @Override
    public void test(File input, ProgressListener l) throws IOException {
        SevenZFile sz = open(input);
        try {
            long total = 0;
            for (SevenZArchiveEntry e : sz.getEntries()) {
                if (!e.isDirectory()) total += Math.max(0, e.getSize());
            }
            long done = 0;
            byte[] buf = new byte[64 * 1024];
            SevenZArchiveEntry e;
            while ((e = sz.getNextEntry()) != null) {
                checkCancel(l);
                if (e.isDirectory()) continue;
                int n;
                while ((n = sz.read(buf)) != -1) {
                    done += n;
                    l.onProgress(e.getName(), done, total);
                    checkCancel(l);
                }
            }
        } finally {
            sz.close();
        }
    }
}
