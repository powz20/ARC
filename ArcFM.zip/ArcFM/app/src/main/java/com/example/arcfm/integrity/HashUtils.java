package com.example.arcfm.integrity;

import com.example.arcfm.archive.ProgressListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.CRC32;

public final class HashUtils {
    private HashUtils() {
    }

    public static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format(Locale.US, "%02x", x));
        return sb.toString();
    }

    public static boolean same(String a, String b) {
        if (a == null || b == null) return false;
        return a.replaceAll("\\s", "").equalsIgnoreCase(b.replaceAll("\\s", ""));
    }

    public static String crc32(File f, ProgressListener l) throws IOException {
        Map<String, String> m = compute(f, l, true, false, false, false);
        return m == null ? null : m.get("CRC32");
    }

    public static String md5(File f, ProgressListener l) throws IOException {
        Map<String, String> m = compute(f, l, false, true, false, false);
        return m == null ? null : m.get("MD5");
    }

    public static String sha1(File f, ProgressListener l) throws IOException {
        Map<String, String> m = compute(f, l, false, false, true, false);
        return m == null ? null : m.get("SHA-1");
    }

    public static String sha256(File f, ProgressListener l) throws IOException {
        Map<String, String> m = compute(f, l, false, false, false, true);
        return m == null ? null : m.get("SHA-256");
    }

    /** CRC32, MD5, SHA-1 e SHA-256 numa única leitura. Devolve null se for cancelado. */
    public static Map<String, String> all(File f, ProgressListener l) throws IOException {
        return compute(f, l, true, true, true, true);
    }

    private static Map<String, String> compute(File f, ProgressListener l, boolean c, boolean m, boolean s1,
                                               boolean s256) throws IOException {
        CRC32 crc = c ? new CRC32() : null;
        MessageDigest md5 = m ? digest("MD5") : null;
        MessageDigest sha1 = s1 ? digest("SHA-1") : null;
        MessageDigest sha256 = s256 ? digest("SHA-256") : null;
        long total = f.length();
        long done = 0;
        byte[] buf = new byte[128 * 1024];
        try (InputStream in = new FileInputStream(f)) {
            int n;
            while ((n = in.read(buf)) != -1) {
                if (crc != null) crc.update(buf, 0, n);
                if (md5 != null) md5.update(buf, 0, n);
                if (sha1 != null) sha1.update(buf, 0, n);
                if (sha256 != null) sha256.update(buf, 0, n);
                done += n;
                if (l != null) {
                    l.onProgress("Hash: " + f.getName(), done, total);
                    if (l.isCancelled()) return null;
                }
            }
        }
        Map<String, String> out = new LinkedHashMap<>();
        if (crc != null) out.put("CRC32", String.format(Locale.US, "%08x", crc.getValue()));
        if (md5 != null) out.put("MD5", hex(md5.digest()));
        if (sha1 != null) out.put("SHA-1", hex(sha1.digest()));
        if (sha256 != null) out.put("SHA-256", hex(sha256.digest()));
        return out;
    }

    private static MessageDigest digest(String algo) throws IOException {
        try {
            return MessageDigest.getInstance(algo);
        } catch (NoSuchAlgorithmException e) {
            throw new IOException("Algoritmo indisponível: " + algo);
        }
    }
}
