package com.example.arcfm;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.DisplayMetrics;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/** Configurações do app (mesmo arquivo usado pela tela de Configurações). */
final class Prefs {
    private Prefs() {
    }

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences("arcfm", Context.MODE_PRIVATE);
    }

    /** As listas das configurações guardam texto; isto lê como número. */
    static int num(Context c, String key, int def) {
        try {
            return Integer.parseInt(get(c).getString(key, String.valueOf(def)));
        } catch (Exception e) {
            return def;
        }
    }

    static void putNum(Context c, String key, int v) {
        get(c).edit().putString(key, String.valueOf(v)).apply();
    }

    static boolean isDark(Context c) {
        int mode = num(c, "themeMode", 0);
        if (mode == 1) return false;
        if (mode == 2) return true;
        int ui = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return ui == Configuration.UI_MODE_NIGHT_YES;
    }

    /** Paleta única do app (pastas, barra e fundo). */
    static final int[] PALETTE = {
            0xFFF4B740, 0xFF4DA3FF, 0xFF7C6FF2, 0xFF36B37E,
            0xFFE85D75, 0xFF00A6A6, 0xFFB86BFF, 0xFF8D6E63
    };

    static String hex(int c) {
        return String.format(java.util.Locale.US, "#%06X", c & 0xFFFFFF);
    }

    /** Aceita "#RRGGBB" ou "RRGGBB"; devolve null se inválido. */
    static String normalizeHex(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.startsWith("#")) t = t.substring(1);
        if (!t.matches("[0-9A-Fa-f]{6}")) return null;
        return "#" + t.toUpperCase(java.util.Locale.US);
    }

    static int parseHex(String s, int fallback) {
        String n = normalizeHex(s);
        return n == null ? fallback : Color.parseColor(n);
    }

    static Charset zipCharset(Context c) {
        try {
            return Charset.forName(get(c).getString("zipCharset", "UTF-8"));
        } catch (Exception e) {
            return StandardCharsets.UTF_8;
        }
    }

    static File bgFile(Context c) {
        return new File(c.getFilesDir(), "bg.jpg");
    }

    /** Reduz a imagem ao tamanho da tela, corrige a rotação (EXIF) e guarda em bg.jpg. */
    static void saveBackground(Context c, Uri uri) throws IOException {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        int target = Math.max(dm.widthPixels, dm.heightPixels);

        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Não foi possível abrir a imagem");
            BitmapFactory.decodeStream(in, null, o);
        }
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= target) sample *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = sample;

        Bitmap bmp;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Não foi possível abrir a imagem");
            bmp = BitmapFactory.decodeStream(in, null, o);
        }
        if (bmp == null) throw new IOException("Imagem inválida");

        int rotation = 0;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in != null) {
                int ori = new ExifInterface(in).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (ori == ExifInterface.ORIENTATION_ROTATE_90) rotation = 90;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rotation = 180;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rotation = 270;
            }
        } catch (Exception ignored) {
            // sem EXIF: segue sem girar
        }
        if (rotation != 0) {
            Matrix m = new Matrix();
            m.postRotate(rotation);
            Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            bmp.recycle();
            bmp = r;
        }
        try (OutputStream os = new FileOutputStream(bgFile(c))) {
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, os);
        }
        bmp.recycle();
    }

    static File toolbarFile(Context c) {
        return new File(c.getFilesDir(), "toolbar.jpg");
    }

    static void saveBackgroundBitmap(Context c, Bitmap source) throws IOException {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        int max = Math.max(dm.widthPixels, dm.heightPixels) * 2;
        Bitmap out = source;
        if (Math.max(source.getWidth(), source.getHeight()) > max) {
            float k = max / (float) Math.max(source.getWidth(), source.getHeight());
            out = Bitmap.createScaledBitmap(source, Math.max(1, Math.round(source.getWidth() * k)),
                    Math.max(1, Math.round(source.getHeight() * k)), true);
        }
        try (OutputStream os = new FileOutputStream(bgFile(c))) {
            out.compress(Bitmap.CompressFormat.JPEG, 95, os);
        }
        if (out != source) out.recycle();
    }

    /** Compatibilidade com o editor de recorte; o fluxo normal da barra usa saveToolbarImage(Uri). */
    static void saveToolbarBitmap(Context c, Bitmap source) throws IOException {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        int w = dm.widthPixels;
        int h = Math.max(1, Math.round(68 * dm.density));
        Bitmap out = Bitmap.createScaledBitmap(source, w, h, true);
        try (OutputStream os = new FileOutputStream(toolbarFile(c))) {
            out.compress(Bitmap.CompressFormat.JPEG, 90, os);
        }
        out.recycle();
    }

    /** Recorta a imagem no formato da barra de ferramentas e guarda em toolbar.jpg. */
    static void saveToolbarImage(Context c, Uri uri) throws IOException {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        int w = dm.widthPixels;
        int h = Math.max(1, Math.round(68 * dm.density));
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Não foi possível abrir a imagem");
            BitmapFactory.decodeStream(in, null, o);
        }
        int sample = 1;
        while (o.outWidth / (sample * 2) >= w) sample *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = sample;
        Bitmap src;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Não foi possível abrir a imagem");
            src = BitmapFactory.decodeStream(in, null, o);
        }
        if (src == null) throw new IOException("Imagem inválida");
        float ratio = w / (float) h;
        int cw = src.getWidth();
        int ch = Math.round(cw / ratio);
        if (ch > src.getHeight()) {
            ch = src.getHeight();
            cw = Math.round(ch * ratio);
        }
        Bitmap crop = Bitmap.createBitmap(src, (src.getWidth() - cw) / 2, (src.getHeight() - ch) / 2, cw, ch);
        Bitmap out = Bitmap.createScaledBitmap(crop, w, h, true);
        try (OutputStream os = new FileOutputStream(toolbarFile(c))) {
            out.compress(Bitmap.CompressFormat.JPEG, 90, os);
        }
    }
}
