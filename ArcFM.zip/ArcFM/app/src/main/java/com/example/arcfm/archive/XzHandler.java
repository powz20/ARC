package com.example.arcfm.archive;

public final class XzHandler extends TarCodecHandler {
    public XzHandler(ArchiveOptions o) {
        super(o, Codecs.XZ, new String[]{".tar.xz", ".txz"}, new String[]{".xz"});
    }
}
