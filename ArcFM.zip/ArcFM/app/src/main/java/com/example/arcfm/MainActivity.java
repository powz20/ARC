package com.example.arcfm;

import com.example.arcfm.archive.TarIO;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.system.Os;
import android.util.LruCache;
import android.view.SubMenu;
import android.widget.GridView;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Window;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Rect;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.media.ExifInterface;
import android.util.DisplayMetrics;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.CRC32;
import android.content.pm.PackageInfo;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfRenderer;
import android.media.MediaMetadataRetriever;
import android.os.ParcelFileDescriptor;
import android.widget.CheckBox;
import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.UncheckedIOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicLong;
import org.apache.commons.compress.archivers.zip.ParallelScatterZipCreator;
import org.apache.commons.compress.archivers.zip.Zip64Mode;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.parallel.FileBasedScatterGatherBackingStore;
import android.content.ComponentName;
import android.os.StatFs;
import android.view.MotionEvent;
import android.view.GestureDetector;
import android.widget.AbsListView;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.tukaani.xz.XZInputStream;
import org.tukaani.xz.XZOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import net.jpountz.lz4.LZ4Compressor;
import net.jpountz.lz4.LZ4Factory;
import net.jpountz.lz4.LZ4FrameInputStream;
import net.jpountz.lz4.LZ4FrameOutputStream;
import net.jpountz.xxhash.XXHashFactory;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.sevenz.SevenZMethod;
import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;
import org.tukaani.xz.LZMA2Options;

public class MainActivity extends Activity {

    private static final int MAX_LIST = 1500;
    private static final String[] LEVELS = {
            "Sem compressão", "Muito rápido", "Rápido", "Normal", "Máximo", "Ultra"
    };
    // nível do Deflate (ZIP) para cada item de LEVELS
    private static final int[] ZIP_LEVELS = {0, 1, 3, 6, 8, 9};
    // 7z (preset LZMA2) para cada item de LEVELS; o item 0 é "sem compressão"
    private static final int[] SEVENZ_PRESETS = {0, 1, 3, 5, 7, 8};

    private static final int C_NONE = 0;
    private static final int C_LZ4 = 1;
    private static final int C_GZ = 2;
    private static final int C_XZ = 3;
    private static final int C_BZ2 = 4;
    private static final int[] BZ2_BLOCKS = {1, 1, 3, 5, 7, 9};

    // formatos do diálogo "Compactar..."
    private static final String[] FORMATS = {"zip", "7z", "tar", "tar.lz4", "tar.gz", "tar.xz", "tar.bz2", "tar.zst"};
    private static final String[] FORMAT_EXT = {".zip", ".7z", ".tar", ".tar.lz4", ".tar.gz", ".tar.xz", ".tar.bz2", ".tar.zst"};

    private static final int REQ_BG = 42;
    private static final String[] THEME_NAMES = {"Automático (sistema)", "Claro", "Escuro"};
    private static final String[] ZIP_EXT = {
            ".zip", ".jar", ".apk", ".xapk", ".cbz", ".mcaddon", ".mcpack", ".mcworld"
    };

    private final File root = Environment.getExternalStorageDirectory();
    private File current;
    private TextView pathView;
    private ListView listView;
    private FileAdapter adapter;
    private ActionMode actionMode;
    private Set<File> selected = new LinkedHashSet<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private ImageView bgImage;
    private View bgScrim;
    private String restoreDir;
    private final List<File> clip = new ArrayList<>();
    private boolean clipCut;
    private View pasteBar;
    private TextView pasteText;
    private GridView gridView;
    private TextView fab;
    private File upItem;
    private volatile int overwriteAll = -1;
    private int jobsRunning;

    private void jobStarted() {
        runOnUiThread(() -> {
            jobsRunning++;
            applyKeepOn(prefs.getBoolean("keepOn", true));
        });
    }

    private void jobEnded() {
        runOnUiThread(() -> {
            if (jobsRunning > 0) jobsRunning--;
            if (jobsRunning == 0) getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    /** Liga/desliga a tela ligada; só mantém a tela enquanto houver operação em andamento. */
    private void applyKeepOn(boolean on) {
        if (on && jobsRunning > 0) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private boolean createdDark;
    private long bgStamp = -1;
    private final ExecutorService thumbPool = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> thumbCache = new LruCache<>(200);
    private final Map<String, String> dimCache = new ConcurrentHashMap<>();
    private final Set<String> thumbLoading = ConcurrentHashMap.newKeySet();

    // ---------------------------------------------------------------- ciclo de vida

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        prefs = getSharedPreferences("arcfm", MODE_PRIVATE);
        CrashLog.install(this);
        setTheme(isDark() ? R.style.AppDark : R.style.AppLight);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        restoreDir = savedInstanceState != null ? savedInstanceState.getString("dir") : null;
        createdDark = isDark();
        com.example.arcfm.diagnostics.DiagnosticLog.init(getFilesDir(), "0.10",
                "Android " + android.os.Build.VERSION.RELEASE + " | ABI " + android.os.Build.SUPPORTED_ABIS[0],
                prefs.getBoolean("diagOn", false));

        bgImage = findViewById(R.id.bgImage);
        bgScrim = findViewById(R.id.bgScrim);
        pathView = findViewById(R.id.pathView);
        listView = findViewById(R.id.listView);
        gridView = findViewById(R.id.gridView);
        fab = findViewById(R.id.fab);
        GradientDrawable fb = new GradientDrawable();
        fb.setShape(GradientDrawable.OVAL);
        fb.setColor(0xFF4A6572);
        fab.setBackground(fb);
        fab.setOnClickListener(v -> {
            if (!clip.isEmpty()) pasteHere();
            else showNewSheet();
        });
        applyBackground();
        pasteBar = findViewById(R.id.pasteBar);
        pasteText = findViewById(R.id.pasteText);
        findViewById(R.id.btnPaste).setOnClickListener(v -> pasteHere());
        findViewById(R.id.btnPasteCancel).setOnClickListener(v -> {
            clip.clear();
            updatePasteBar();
        });
        panes = findViewById(R.id.panes);
        View contentLayer = findViewById(R.id.contentLayer);
        if (contentLayer != null) {
            contentLayer.post(() -> {
                android.app.ActionBar actionBar = getActionBar();
                if (actionBar == null) return;
                ViewGroup.LayoutParams raw = contentLayer.getLayoutParams();
                if (raw instanceof FrameLayout.LayoutParams) {
                    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) raw;
                    lp.topMargin = Math.round(TOOLBAR_DP * getResources().getDisplayMetrics().density);
                    contentLayer.setLayoutParams(lp);
                }
            });
        }
        pageIndicator = findViewById(R.id.pageIndicator);
        bookDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null || !isBook()) return false;
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > dp(60) && Math.abs(dx) > Math.abs(dy) * 1.5f && Math.abs(vx) > dp(300)) {
                    turnPage(dx < 0 ? 1 : -1);
                    return true;
                }
                return false;
            }
        });
        paneBox1 = findViewById(R.id.paneBox1);
        paneBox2 = findViewById(R.id.paneBox2);
        paneDivider = findViewById(R.id.paneDivider);
        toolbarBg = findViewById(R.id.toolbarBg);
        pane1 = new Pane();
        pane1.list = listView;
        pane1.grid = gridView;
        pane1.header = findViewById(R.id.paneHeader1);
        pane2 = new Pane();
        pane2.list = findViewById(R.id.listView2);
        pane2.grid = findViewById(R.id.gridView2);
        pane2.header = findViewById(R.id.paneHeader2);
        for (Pane pn : new Pane[]{pane1, pane2}) {
            pn.adapter = new FileAdapter(pn);
            pn.list.setAdapter(pn.adapter);
            pn.grid.setAdapter(pn.adapter);
            pn.list.setTag(pn);
            pn.grid.setTag(pn);
            pn.header.setTag(pn);
            pn.list.setLayoutAnimation(new android.view.animation.LayoutAnimationController(
                    android.view.animation.AnimationUtils.loadAnimation(this, android.R.anim.fade_in), 0.04f));
            pn.grid.setLayoutAnimation(new android.view.animation.LayoutAnimationController(
                    android.view.animation.AnimationUtils.loadAnimation(this, android.R.anim.fade_in), 0.04f));
            pn.header.setOnClickListener(v -> {
                Pane hp = (Pane) v.getTag();
                if (active == hp) showPlacesPanel();
                else activate(hp);
            });
        }
        active = pane1;
        adapter = pane1.adapter;
        selected = pane1.selected;
        applyViewMode();

        for (Pane pn : new Pane[]{pane1, pane2}) {
            setupList(pn.list);
            setupList(pn.grid);
            pn.list.setOnTouchListener(pullListener);
            pn.grid.setOnTouchListener(pullListener);
        }
        infoPanel = findViewById(R.id.infoPanel);
        infoFolder = findViewById(R.id.infoFolder);
        infoStorage = findViewById(R.id.infoStorage);
        infoBar = findViewById(R.id.infoBar);
        infoShizuku = findViewById(R.id.infoShizuku);
        GradientDrawable pb = new GradientDrawable();
        pb.setColor(isDark() ? 0xF02A2B30 : 0xF0F2F2F2);
        pb.setCornerRadius(dp(14));
        infoPanel.setBackground(pb);
        infoPanel.setOnClickListener(v -> infoPanel.setVisibility(View.GONE));
        setupBar();
        enableShizukuProvider();

        pathView.setOnClickListener(v -> {
            if (!hasAccess()) requestAccess();
        });

        if (!hasAccess()) requestAccess();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isDark() != createdDark) {
            recreate();
            return;
        }
        applyBackground();
        applyViewMode();
        applyToolbar();
        applyFabStyle();
        if (hasAccess()) {
            if (current == null) {
                File start = root;
                String dd = prefs.getString("defaultDir", "");
                if (dd != null && !dd.trim().isEmpty()) {
                    File d0 = new File(dd.trim());
                    if (d0.isDirectory()) start = d0;
                }
                String last = restoreDir;
                if (last == null && prefs.getBoolean("openLast", false)) {
                    last = prefs.getString("lastDir", null);
                }
                restoreDir = null;
                if (last != null) {
                    File d = new File(last);
                    if (d.isDirectory()) start = d;
                }
                openDir(start);
            } else {
                reloadAll();
            }
            applyDual();
        } else {
            pathView.setVisibility(View.VISIBLE);
            pathView.setText("Sem permissão de arquivos. Toque aqui.");
        }
    }

    @Override
    protected void onPause() {
        if (current != null) prefs.edit().putString("lastDir", current.getAbsolutePath()).apply();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (current != null) out.putString("dir", current.getAbsolutePath());
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        thumbPool.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (actionMode != null) {
            actionMode.finish();
            return;
        }
        if (!clip.isEmpty()) {
            clip.clear();
            clipCut = false;
            updatePasteBar();
            toast("Ação cancelada");
            return;
        }
        if (current != null && !current.equals(root) && current.getParentFile() != null) {
            openDir(current.getParentFile());
        } else {
            super.onBackPressed();
        }
    }

    // ---------------------------------------------------------------- permissão

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            requestPermissions(new String[]{
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    // ---------------------------------------------------------------- menu normal

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem v = menu.add(0, 110, 0, "Visualizar");
        v.setIcon(android.R.drawable.ic_menu_sort_by_size);
        v.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add(0, 104, 1, "Multiseleção");
        SubMenu sub = menu.addSubMenu(0, 200, 2, "Novo");
        sub.add(0, 201, 0, "Nova pasta");
        sub.add(0, 202, 1, "Novo arquivo");
        sub.add(0, 203, 2, "Novo arquivo compactado");
        menu.add(0, 103, 3, "Configurações");
        menu.add(0, 122, 3, "Diagnóstico");
        menu.add(0, 120, 4, "Sobre");
        menu.add(0, 121, 5, "Sair");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            case 110:
                showViewPopup();
                return true;
            case 104:
                startMultiSelect();
                return true;
            case 201:
                promptNewFolder();
                return true;
            case 202:
                promptNewFile();
                return true;
            case 203:
                promptNewArchive();
                return true;
            case 103:
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
            case 120:
                showAbout();
                return true;
            case 122:
                showDiagnostics();
                return true;
            case 121:
                finishAffinity();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // ---------------------------------------------------------------- navegação

    private static String extOf(File f) {
        String n = f.getName();
        int d = n.lastIndexOf('.');
        return d > 0 ? n.substring(d + 1) : "";
    }

    private boolean loadDir(File dir) {
        File[] files = dir.listFiles();
        if (files == null) {
            toast("Não foi possível abrir esta pasta");
            return false;
        }
        boolean hidden = prefs.getBoolean("showHidden", false);
        List<File> list = new ArrayList<>();
        for (File f : files) {
            if (hidden || !f.getName().startsWith(".")) list.add(f);
        }
        final int sortBy = Prefs.num(this, "sortBy", 0);
        final boolean desc = prefs.getBoolean("sortDesc", false);
        Collections.sort(list, (a, b) -> {
            if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
            int c;
            if (sortBy == 1) c = Long.compare(a.length(), b.length());
            else if (sortBy == 2) c = Long.compare(a.lastModified(), b.lastModified());
            else if (sortBy == 3) c = extOf(a).compareToIgnoreCase(extOf(b));
            else c = a.getName().compareToIgnoreCase(b.getName());
            if (c == 0) c = a.getName().compareToIgnoreCase(b.getName());
            return desc ? -c : c;
        });
        current = dir;
        active.current = dir;
        adapter.clear();
        adapter.resetCounts();
        adapter.addAll(list);
        upItem = null;
        if (prefs.getBoolean("showUp", true) && !dir.equals(root) && dir.getParentFile() != null) {
            upItem = new File(dir, "..");
            adapter.insert(upItem, 0);
        }
        active.upItem = upItem;
        pathView.setVisibility(View.GONE);
        updateBarText(dir);
        return true;
    }

    private void openDir(File dir) {
        if (actionMode != null) actionMode.finish();
        selected.clear();
        if (loadDir(dir)) {
            (viewMode() == 2 ? gridView : listView).startLayoutAnimation();
            (viewMode() == 2 ? gridView : listView).setSelection(0);
        }
    }

    private void reload() {
        if (current != null) loadDir(current);
    }

    // ---------------------------------------------------------------- seleção

    private final ActionMode.Callback modeCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            menu.clear();
            menu.add(0, 1, 0, "Compactar...").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            if (selected.size() == 1) {
                menu.add(0, 2, 1, "Informações").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            }
            menu.add(0, 3, 2, "Copiar").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            menu.add(0, 4, 3, "Recortar").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            menu.add(0, 5, 4, "Excluir").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            if (selected.size() == 1) {
                menu.add(0, 6, 5, "Renomear").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            }
            menu.add(0, 7, 6, "Compartilhar").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            menu.add(0, 8, 7, "Selecionar tudo").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            return true;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            List<File> items = new ArrayList<>(selected);
            int id = item.getItemId();
            if (id == 8) {
                selectAll();
                return true;
            }
            if (items.isEmpty()) {
                toast("Selecione pelo menos um item");
                return true;
            }
            switch (id) {
                case 1:
                    showCompressDialog(items);
                    return true;
                case 2:
                    showInfo(items.get(0));
                    return true;
                case 3:
                    setClip(items, false);
                    return true;
                case 4:
                    setClip(items, true);
                    return true;
                case 5:
                    confirmDelete(items);
                    return true;
                case 6:
                    promptRename(items.get(0));
                    return true;
                case 7:
                    shareFiles(items);
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            selected.clear();
            actionMode = null;
            adapter.notifyDataSetChanged();
        }
    };

    private void toggle(File f) {
        if (!selected.remove(f)) selected.add(f);
        if (selected.isEmpty()) {
            if (actionMode != null) actionMode.finish();
        } else if (actionMode != null) {
            actionMode.setTitle(selected.size() + " selecionado(s)");
            actionMode.invalidate();
        }
        adapter.notifyDataSetChanged();
    }

    private void selectAll() {
        for (int i = 0; i < adapter.getCount(); i++) {
            File f = adapter.getItem(i);
            if (f != null && f != upItem) selected.add(f);
        }
        if (actionMode != null) {
            actionMode.setTitle(selected.size() + " selecionado(s)");
            actionMode.invalidate();
        }
        adapter.notifyDataSetChanged();
    }

    private void finishMode() {
        if (actionMode != null) actionMode.finish();
        selected.clear();
    }

    // ---------------------------------------------------------------- ZIP: menu, ver, extrair

    private static List<File> listOf(File f) {
        List<File> l = new ArrayList<>();
        l.add(f);
        return l;
    }

    private static boolean isArchiveFile(File f) {
        return isZip(f) || isSevenZ(f) || tarCodec(f) >= 0 || singleCodec(f) >= 0;
    }

    /** Toque num arquivo compactado (igual ao ZArchiver). */
    private void showArchiveSheet(final File f) {
        final String base = archiveBase(f);
        List<Act> acts = new ArrayList<>();
        acts.add(new Act("◉", "Exibir", () -> viewArchive(f)));
        acts.add(new Act("\u2B06", "Extrair aqui", () -> startExtract(f, current)));
        acts.add(new Act("\u2B06", "Extrair para ./" + base + "/",
                () -> startExtract(f, uniqueFile(current, base, ""))));
        acts.add(new Act("\u2B06", "Extrair...",
                () -> pickFolder("Extrair para…", current, dir -> startExtract(f, dir))));
        acts.add(new Act("\u2714", "Testar", () -> testArchive(f)));
        acts.add(new Act("\u2B07", "Compactar...", () -> showCompressDialog(listOf(f))));
        addCommonActs(acts, f);
        acts.add(new Act("\u2197", "Abrir com...", () -> openWith(f)));
        showSheet(f.getName(), acts);
    }

    /** Toque longo num item (igual ao ZArchiver). */
    private void showItemSheet(final File f) {
        List<Act> acts = new ArrayList<>();
        acts.add(new Act("\u2B07", "Compactar...", () -> showCompressDialog(listOf(f))));
        if (discExt(f) != null) {
            acts.add(new Act("◈", "Converter imagem de disco...", () -> showDiscDialog(f)));
        }
        if (f.isDirectory()) {
            acts.add(new Act("◈", "Criar imagem ISO da pasta", () -> makeIsoFromFolder(f)));
        }
        addCommonActs(acts, f);
        if (f.isDirectory()) {
            acts.add(new Act("", "Personalizar pasta", () -> showFolderAppearanceDialog(f)));
        }
        showSheet(f.getName(), acts);
    }

    /** Menu de ações do grupo selecionado (abre ao segurar num item já selecionado). */
    private void showSelectionSheet(final List<File> items) {
        if (items.isEmpty()) return;
        List<Act> acts = new ArrayList<>();
        acts.add(new Act("\u2B07", "Compactar...", () -> showCompressDialog(items)));
        if (items.size() == 1) {
            final File f = items.get(0);
            acts.add(new Act("\u2139", "Informações", () -> showInfo(f)));
        }
        acts.add(new Act("\uD83D\uDCCB", "Copiar", () -> setClip(items, false)));
        acts.add(new Act("\u2702", "Recortar", () -> setClip(items, true)));
        acts.add(new Act("\uD83D\uDDD1", "Excluir", () -> confirmDelete(items)));
        if (items.size() == 1) {
            final File f = items.get(0);
            acts.add(new Act("\u270F", "Renomear", () -> promptRename(f)));
        }
        boolean anyFile = false;
        for (File f : items) if (f.isFile()) anyFile = true;
        if (anyFile) acts.add(new Act("\u27A4", "Compartilhar", () -> shareFiles(items)));
        acts.add(new Act("☑", "Selecionar tudo", this::selectAll));
        showSheet(items.size() == 1 ? items.get(0).getName() : items.size() + " selecionados", acts);
    }

    private void addCommonActs(List<Act> acts, final File f) {
        final List<File> one = listOf(f);
        acts.add(new Act("\u2139", "Informações", () -> showInfo(f)));
        acts.add(new Act("□", "Copiar", () -> setClip(one, false)));
        acts.add(new Act("\u2702", "Recortar", () -> setClip(one, true)));
        acts.add(new Act("×", "Excluir", () -> confirmDelete(one)));
        acts.add(new Act("\u270F", "Renomear", () -> promptRename(f)));
        if (f.isFile()) acts.add(new Act("\u27A4", "Compartilhar", () -> shareFiles(one)));
    }

    private void viewArchive(File f) {
        Intent i = new Intent(this, ArchiveBrowserActivity.class);
        i.putExtra("path", f.getAbsolutePath());
        startActivity(i);
    }

    private void viewZip(final File zip) {
        executor.execute(() -> {
            final List<String> lines = new ArrayList<>();
            int totalEntries = 0;
            String error = null;
            try (ZipFile zf = new ZipFile(zip, Prefs.zipCharset(this))) {
                totalEntries = zf.size();
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements() && lines.size() < MAX_LIST) {
                    ZipEntry e = en.nextElement();
                    if (e.isDirectory()) {
                        lines.add(e.getName());
                    } else {
                        lines.add(e.getName() + "  (" + formatSize(Math.max(0, e.getSize())) + ")");
                    }
                }
                if (totalEntries > lines.size()) {
                    lines.add("… e mais " + (totalEntries - lines.size()) + " itens");
                }
            } catch (Exception e) {
                error = e.getClass().getSimpleName() + ": " + e.getMessage();
            }
            final int fTotal = totalEntries;
            final String fError = error;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                if (fError != null) {
                    toast("Não foi possível ler o ZIP: " + fError);
                    return;
                }
                new AlertDialog.Builder(this)
                        .setTitle(zip.getName() + " — " + fTotal + " itens")
                        .setItems(lines.toArray(new String[0]), null)
                        .setPositiveButton("Fechar", null)
                        .show();
            });
        });
    }

    private void startExtract(final File archive, final File dest) {
        if (!dest.exists() && !dest.mkdirs()) {
            toast("Não foi possível criar a pasta de destino");
            return;
        }
        runJob("Extraindo " + archive.getName(), p -> runArchiveExtract(archive, dest, p));
    }

    /** Extração pelo ArchiveManager: checagens de caminho, limites, CRC e política de sobrescrita. */
    private String runArchiveExtract(File archive, File dest, Progress p) throws IOException {
        com.example.arcfm.archive.ArchiveOptions o = archiveOptions(3);
        o.conflicts = this::conflict;
        com.example.arcfm.archive.ArchiveManager m = new com.example.arcfm.archive.ArchiveManager(o);
        long t0 = System.currentTimeMillis();
        try {
            m.extract(archive, dest, listenerFor(p));
            if (p.cancelled.get()) return null;
            logArchive("extrair", formatIndexOf(archive), 0, archive.getName(), dest.getName(),
                    archive.length(), 0, t0, null, -1);
            return o.stats.summary();
        } catch (IOException e) {
            logArchive("extrair", formatIndexOf(archive), 0, archive.getName(), dest.getName(),
                    archive.length(), 0, t0, e, o.stats.partialOut);
            throw e;
        }
    }

    private int formatIndexOf(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (n.endsWith(".7z")) return 1;
        if (n.endsWith(".tar.lz4") || n.endsWith(".tlz4") || n.endsWith(".lz4")) return 3;
        if (n.endsWith(".tar.gz") || n.endsWith(".tgz") || n.endsWith(".gz")) return 4;
        if (n.endsWith(".tar.xz") || n.endsWith(".txz") || n.endsWith(".xz")) return 5;
        if (n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".tbz") || n.endsWith(".bz2")) return 6;
        if (n.endsWith(".tar")) return 2;
        return 0;
    }

    private String extractZip(File zip, File destDir, Progress p) throws IOException {
        ZipFile zf = new ZipFile(zip, Prefs.zipCharset(this));
        try {
            long total = 0;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (!e.isDirectory() && e.getSize() > 0) total += e.getSize();
            }

            if (!destDir.exists() && !destDir.mkdirs()) {
                throw new IOException("Não foi possível criar a pasta de destino");
            }
            String destCanon = destDir.getCanonicalPath();
            String destPrefix = destCanon + File.separator;

            long done = 0;
            int files = 0;
            int skipped = 0;
            byte[] buf = new byte[64 * 1024];

            en = zf.entries();
            while (en.hasMoreElements()) {
                if (p.cancelled.get()) break;
                ZipEntry e = en.nextElement();
                File out = new File(destDir, e.getName());
                String outCanon = out.getCanonicalPath();
                if (!outCanon.equals(destCanon) && !outCanon.startsWith(destPrefix)) {
                    throw new IOException("Entrada inválida no ZIP: " + e.getName());
                }

                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }

                File parent = out.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();

                int act = conflict(out);
                if (act == 1) {
                    skipped++;
                    if (e.getSize() > 0) done += e.getSize();
                    continue;
                } else if (act == 2) {
                    out = targetFor(out.getParentFile(), out);
                } else if (out.exists()) {
                    out.delete();
                }

                InputStream in = zf.getInputStream(e);
                try {
                    OutputStream os = new FileOutputStream(out);
                    try {
                        int n;
                        while ((n = in.read(buf)) != -1) {
                            os.write(buf, 0, n);
                            done += n;
                            p.update(e.getName(), done, total);
                            if (p.cancelled.get()) break;
                        }
                    } finally {
                        os.close();
                    }
                } finally {
                    in.close();
                }

                if (p.cancelled.get()) {
                    out.delete();
                    break;
                }
                if (e.getTime() > 0) out.setLastModified(e.getTime());
                files++;
            }

            String msg = files + " arquivo(s) extraído(s)";
            if (skipped > 0) msg += ", " + skipped + " já existiam e foram ignorados";
            return msg;
        } finally {
            zf.close();
        }
    }

    // ---------------------------------------------------------------- ZIP: compactar

    /** Diálogo único de compactação: nome, formato e nível (como no ZArchiver). */
    private void showCompressDialog(final List<File> items) {
        if (items.isEmpty() || current == null) return;
        final File dir = outDir();
        final boolean force = prefs.getBoolean("forceLevels", false);

        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(items.size() == 1 ? baseName(items.get(0)) : "Arquivos");
        et.selectAll();

        final String[] lvlAll = LEVELS;
        final String[] lvl7 = force ? LEVELS : Arrays.copyOf(LEVELS, LEVELS.length - 1);
        final String[] lvlLz4 = Arrays.copyOfRange(LEVELS, 1, LEVELS.length);
        final String[] lvlNone = {"—"};
        final String[] lvlXz = force ? lvlLz4 : Arrays.copyOf(lvlLz4, lvlLz4.length - 1);
        final int defZip = Math.min(Prefs.num(this, "lvlZip", 3), lvlAll.length - 1);
        final int def7z = Math.min(Prefs.num(this, "lvl7z", 3), lvl7.length - 1);

        final Spinner fmt = new Spinner(this);
        fmt.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, FORMATS));
        final Spinner lvl = new Spinner(this);
        lvl.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, lvlAll));
        lvl.setSelection(defZip);
        fmt.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String[] opts = pos == 1 ? lvl7 : (pos == 5 ? lvlXz : (pos == 3 || pos == 6 || pos == 7 ? lvlLz4 : (pos == 2 ? lvlNone : lvlAll)));
                lvl.setAdapter(new ArrayAdapter<>(MainActivity.this,
                        android.R.layout.simple_spinner_dropdown_item, opts));
                lvl.setEnabled(pos != 2);
                lvl.setSelection(pos == 0 || pos == 4 ? defZip : (pos == 1 ? def7z : (pos >= 5 ? 2 : 0)));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(label("Nome do arquivo"));
        box.addView(et, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(label("Formato"));
        box.addView(fmt, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(label("Nível de compressão"));
        box.addView(lvl, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(label("Dividir em volumes de (MB) — vazio = não dividir"));
        final EditText volEt = new EditText(this);
        volEt.setSingleLine(true);
        volEt.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        volEt.setHint("ex.: 700");
        box.addView(volEt, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final CheckBox delCb = new CheckBox(this);
        delCb.setText("Excluir os arquivos originais depois de compactar");
        box.addView(delCb, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        new AlertDialog.Builder(this)
                .setTitle("Compactar")
                .setView(box)
                .setPositiveButton("OK", (d, w) -> {
                    int fi = fmt.getSelectedItemPosition();
                    int lp = Math.max(0, lvl.getSelectedItemPosition());
                    String name = cleanName(et.getText().toString());
                    if (name.isEmpty() || fi < 0) return;
                    String ext = FORMAT_EXT[fi];
                    String base = name;
                    if (name.toLowerCase(Locale.ROOT).endsWith(ext)) {
                        base = name.substring(0, name.length() - ext.length());
                    }
                    if (base.isEmpty()) return;
                    final int level = (fi == 3 || fi >= 5) ? lp + 1 : (fi == 2 ? 0 : lp);
                    final File out = uniqueFile(dir, base, ext);
                    finishMode();
                    long volTmp = 0;
                    String vt = volEt.getText().toString().trim();
                    if (!vt.isEmpty()) {
                        try {
                            volTmp = Long.parseLong(vt) * 1024L * 1024L;
                        } catch (NumberFormatException e) {
                            toast("Tamanho de volume inválido");
                            return;
                        }
                        if (volTmp <= 0) {
                            toast("Tamanho de volume inválido");
                            return;
                        }
                    }
                    final long volFinal = volTmp;
                    final boolean delOriginals = delCb.isChecked();
                    runJob("Compactando…", p -> {
                        String r = runArchive(items, out, fi, level, volFinal, p);
                        if (r != null && delOriginals) {
                            for (File f : items) com.example.arcfm.filesystem.FileScanner.deleteTree(f);
                            r += " · originais apagados";
                        }
                        return r;
                    }, () -> afterCompress(items));
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setTextAppearance(android.R.style.TextAppearance_Material_Caption);
        t.setText(text);
        t.setPadding(0, dp(12), 0, 0);
        return t;
    }

    private class ZipCtx {
        final ZipOutputStream zos;
        final File out;
        final Progress p;
        final long total;
        final byte[] buf = new byte[64 * 1024];
        long done;
        int skipped;

        ZipCtx(ZipOutputStream zos, File out, Progress p, long total) {
            this.zos = zos;
            this.out = out;
            this.p = p;
            this.total = total;
        }
    }

    private String zipFiles(List<File> items, File outZip, Progress p, int level) throws IOException {
        long total = 0;
        for (File f : items) total += sizeOf(f);

        ZipOutputStream zos = new ZipOutputStream(
                new BufferedOutputStream(new FileOutputStream(outZip), 64 * 1024));
        zos.setLevel(ZIP_LEVELS[level]);
        ZipCtx ctx = new ZipCtx(zos, outZip, p, total);
        boolean finished = false;
        try {
            for (File f : items) {
                if (p.cancelled.get()) break;
                addToZip(ctx, f, f.getName());
            }
            zos.close();
            finished = !p.cancelled.get();
        } finally {
            if (!finished) {
                try {
                    zos.close();
                } catch (IOException ignored) {
                }
                outZip.delete();
            }
        }

        String msg = "Criado " + outZip.getName() + " (" + formatSize(outZip.length()) + ")";
        if (ctx.skipped > 0) msg += ", " + ctx.skipped + " arquivo(s) ignorado(s)";
        return msg;
    }

    private void addToZip(ZipCtx c, File f, String name) throws IOException {
        if (c.p.cancelled.get()) return;
        if (f.getAbsolutePath().equals(c.out.getAbsolutePath())) return;

        if (f.isDirectory()) {
            ZipEntry de = new ZipEntry(name + "/");
            de.setTime(f.lastModified());
            c.zos.putNextEntry(de);
            c.zos.closeEntry();
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) addToZip(c, k, name + "/" + k.getName());
            }
            return;
        }
        if (!f.isFile()) return;

        FileInputStream in;
        try {
            in = new FileInputStream(f);
        } catch (FileNotFoundException e) {
            c.skipped++;
            return;
        }
        try {
            ZipEntry ze = new ZipEntry(name);
            ze.setTime(f.lastModified());
            c.zos.putNextEntry(ze);
            int n;
            while ((n = in.read(c.buf)) != -1) {
                c.zos.write(c.buf, 0, n);
                c.done += n;
                c.p.update(name, c.done, c.total);
                if (c.p.cancelled.get()) break;
            }
            c.zos.closeEntry();
        } finally {
            in.close();
        }
    }

    private static long sizeOf(File f) {
        if (f.isFile()) return f.length();
        long s = 0;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) s += sizeOf(k);
        }
        return s;
    }

    // ---------------------------------------------------------------- TAR, LZ4, ZSTD e 7Z

    private static InputStream wrapIn(InputStream in, int codec) throws IOException {
        if (codec == C_LZ4) return new LZ4FrameInputStream(in);
        if (codec == C_GZ) return new GZIPInputStream(in, 64 * 1024);
        if (codec == C_XZ) return new XZInputStream(in);
        if (codec == C_BZ2) return new BZip2CompressorInputStream(in);
        return in;
    }

    private static OutputStream wrapOut(OutputStream out, int codec, int level) throws IOException {
        if (codec == C_LZ4) return newLz4Out(out, level);
        if (codec == C_GZ) {
            final int lv = ZIP_LEVELS[Math.min(level, 5)];
            return new GZIPOutputStream(out, 64 * 1024) {
                {
                    def.setLevel(lv);
                }
            };
        }
        if (codec == C_XZ) return new XZOutputStream(out, new LZMA2Options(SEVENZ_PRESETS[Math.min(level, 5)]));
        if (codec == C_BZ2) return new BZip2CompressorOutputStream(out, BZ2_BLOCKS[Math.min(level, 5)]);
        return out;
    }

    /** nível 1 = rápido (equivale ao lz4 -1); 2 a 5 = HC (mais lento, arquivo menor). */
    private static OutputStream newLz4Out(OutputStream fos, int level) throws IOException {
        LZ4Factory f = LZ4Factory.fastestInstance();
        LZ4Compressor c;
        switch (level) {
            case 1:
                c = f.fastCompressor();
                break;
            case 2:
                c = f.highCompressor(3);
                break;
            case 3:
                c = f.highCompressor(6);
                break;
            case 4:
                c = f.highCompressor(9);
                break;
            default:
                c = f.highCompressor(12);
                break;
        }
        return new LZ4FrameOutputStream(fos, LZ4FrameOutputStream.BLOCKSIZE.SIZE_4MB, -1L, c,
                XXHashFactory.fastestInstance().hash32(),
                LZ4FrameOutputStream.FLG.Bits.BLOCK_INDEPENDENCE);
    }

    private static void showClose(InputStream src, InputStream cin) throws IOException {
        if (src != null) src.close();
        else cin.close();
    }

    private void showList(String title, List<String> lines, boolean truncated) {
        int n = lines.size();
        if (truncated) lines.add("… lista limitada aos primeiros " + MAX_LIST + " itens");
        new AlertDialog.Builder(this)
                .setTitle(title + " — " + n + (truncated ? "+" : "") + " itens")
                .setItems(lines.toArray(new String[0]), null)
                .setPositiveButton("Fechar", null)
                .show();
    }

    private void viewTar(final File f, final int codec) {
        final List<String> lines = new ArrayList<>();
        final boolean[] truncated = {false};
        runJob("Lendo " + f.getName(), p -> {
            long total = f.length();
            TarIO.Counting cin = new TarIO.Counting(
                    new BufferedInputStream(new FileInputStream(f), 64 * 1024));
            InputStream src = null;
            try {
                src = wrapIn(cin, codec);
                TarIO.Reader tar = new TarIO.Reader(src);
                TarIO.Entry e;
                while ((e = tar.next()) != null) {
                    if (p.cancelled.get()) break;
                    if (lines.size() >= MAX_LIST) {
                        truncated[0] = true;
                        break;
                    }
                    lines.add(e.isRegular() ? e.name + "  (" + formatSize(e.size) + ")" : e.name);
                    p.update(e.name, cin.count, total);
                }
            } finally {
                showClose(src, cin);
            }
            return null;
        }, () -> showList(f.getName(), lines, truncated[0]));
    }

    private String extractTar(File archive, File destDir, Progress p, int codec) throws IOException {
        long total = archive.length();
        TarIO.Counting cin = new TarIO.Counting(
                new BufferedInputStream(new FileInputStream(archive), 64 * 1024));
        InputStream src = null;
        try {
            src = wrapIn(cin, codec);
            TarIO.Reader tar = new TarIO.Reader(src);

            if (!destDir.exists() && !destDir.mkdirs()) {
                throw new IOException("Não foi possível criar a pasta de destino");
            }
            String destCanon = destDir.getCanonicalPath();
            String destPrefix = destCanon + File.separator;

            byte[] buf = new byte[64 * 1024];
            int files = 0;
            int skipped = 0;
            int ignored = 0;
            TarIO.Entry e;
            while ((e = tar.next()) != null) {
                if (p.cancelled.get()) break;
                File out = new File(destDir, e.name);
                String outCanon = out.getCanonicalPath();
                if (!outCanon.equals(destCanon) && !outCanon.startsWith(destPrefix)) {
                    throw new IOException("Entrada inválida no TAR: " + e.name);
                }
                if (e.isDir()) {
                    out.mkdirs();
                    continue;
                }
                if (!e.isRegular()) {
                    ignored++; // links, dispositivos etc.
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                int act = conflict(out);
                if (act == 1) {
                    skipped++;
                    continue;
                } else if (act == 2) {
                    out = targetFor(out.getParentFile(), out);
                } else if (out.exists()) {
                    out.delete();
                }

                OutputStream os = new FileOutputStream(out);
                try {
                    int n;
                    while ((n = tar.read(buf, 0, buf.length)) != -1) {
                        os.write(buf, 0, n);
                        p.update(e.name, cin.count, total);
                        if (p.cancelled.get()) break;
                    }
                } finally {
                    os.close();
                }
                if (p.cancelled.get()) {
                    out.delete();
                    break;
                }
                if (e.mtimeMs > 0) out.setLastModified(e.mtimeMs);
                files++;
            }

            String msg = files + " arquivo(s) extraído(s)";
            if (skipped > 0) msg += ", " + skipped + " já existiam e foram ignorados";
            if (ignored > 0) msg += ", " + ignored + " link(s)/item(ns) especial(is) não suportado(s)";
            return msg;
        } finally {
            showClose(src, cin);
        }
    }

    /** .lz4 de um arquivo só (sem TAR). */
    private String singleDecompress(File srcFile, File out, Progress p, int codec) throws IOException {
        long total = srcFile.length();
        TarIO.Counting cin = new TarIO.Counting(
                new BufferedInputStream(new FileInputStream(srcFile), 64 * 1024));
        InputStream src = null;
        boolean ok = false;
        try {
            src = wrapIn(cin, codec);
            OutputStream os = new FileOutputStream(out);
            try {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = src.read(buf)) != -1) {
                    os.write(buf, 0, n);
                    p.update(out.getName(), cin.count, total);
                    if (p.cancelled.get()) break;
                }
            } finally {
                os.close();
            }
            ok = !p.cancelled.get();
            return "Criado " + out.getName() + " (" + formatSize(out.length()) + ")";
        } finally {
            showClose(src, cin);
            if (!ok) out.delete();
        }
    }

    private class TarCtx {
        final TarIO.Writer tar;
        final File out;
        final Progress p;
        final long total;
        final byte[] buf = new byte[64 * 1024];
        long done;
        int skipped;

        TarCtx(TarIO.Writer tar, File out, Progress p, long total) {
            this.tar = tar;
            this.out = out;
            this.p = p;
            this.total = total;
        }
    }

    private String tarFiles(List<File> items, File outFile, Progress p, int codec, int level)
            throws IOException {
        long total = 0;
        for (File f : items) total += sizeOf(f);

        OutputStream fos = new BufferedOutputStream(new FileOutputStream(outFile), 64 * 1024);
        OutputStream sink = fos;
        TarCtx ctx = null;
        boolean finished = false;
        try {
            if (level > 0) {
                int th = cores();
                if (codec == C_LZ4 && th >= 2) sink = new com.example.arcfm.archive.ParallelLz4Out(fos, level, th);
                else sink = wrapOut(fos, codec, level);
            }
            ctx = new TarCtx(new TarIO.Writer(sink), outFile, p, total);
            for (File f : items) {
                if (p.cancelled.get()) break;
                addToTar(ctx, f, f.getName());
            }
            if (!p.cancelled.get()) {
                ctx.tar.finish();
                sink.close();
                finished = true;
            }
        } finally {
            if (!finished) {
                try {
                    sink.close();
                } catch (IOException ignored) {
                }
                outFile.delete();
            }
        }

        String msg = "Criado " + outFile.getName() + " (" + formatSize(outFile.length()) + ")";
        if (ctx != null && ctx.skipped > 0) msg += ", " + ctx.skipped + " arquivo(s) ignorado(s)";
        return msg;
    }

    private void addToTar(TarCtx c, File f, String name) throws IOException {
        if (c.p.cancelled.get()) return;
        if (f.getAbsolutePath().equals(c.out.getAbsolutePath())) return;

        if (f.isDirectory()) {
            c.tar.putEntry(name, true, 0, f.lastModified(), 0755);
            c.tar.closeEntry();
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) addToTar(c, k, name + "/" + k.getName());
            }
            return;
        }
        if (!f.isFile()) return;

        FileInputStream in;
        try {
            in = new FileInputStream(f);
        } catch (FileNotFoundException e) {
            c.skipped++;
            return;
        }
        try {
            c.tar.putEntry(name, false, f.length(), f.lastModified(), f.canExecute() ? 0755 : 0644);
            int n;
            while ((n = in.read(c.buf)) != -1) {
                c.tar.write(c.buf, 0, n);
                c.done += n;
                c.p.update(name, c.done, c.total);
                if (c.p.cancelled.get()) return;
            }
            c.tar.closeEntry();
        } finally {
            in.close();
        }
    }

    // ---- 7z (Apache Commons Compress + XZ)

    private void view7z(final File f) {
        final List<String> lines = new ArrayList<>();
        final boolean[] truncated = {false};
        runJob("Lendo " + f.getName(), p -> {
            SevenZFile sz = SevenZFile.builder().setFile(f).get();
            try {
                for (SevenZArchiveEntry e : sz.getEntries()) {
                    if (lines.size() >= MAX_LIST) {
                        truncated[0] = true;
                        break;
                    }
                    lines.add(e.isDirectory() ? e.getName()
                            : e.getName() + "  (" + formatSize(Math.max(0, e.getSize())) + ")");
                }
            } finally {
                sz.close();
            }
            return null;
        }, () -> showList(f.getName(), lines, truncated[0]));
    }

    private String extract7z(File archive, File destDir, Progress p) throws IOException {
        SevenZFile sz = SevenZFile.builder().setFile(archive).get();
        try {
            long total = 0;
            for (SevenZArchiveEntry e : sz.getEntries()) {
                if (!e.isDirectory() && e.getSize() > 0) total += e.getSize();
            }
            if (!destDir.exists() && !destDir.mkdirs()) {
                throw new IOException("Não foi possível criar a pasta de destino");
            }
            String destCanon = destDir.getCanonicalPath();
            String destPrefix = destCanon + File.separator;

            byte[] buf = new byte[64 * 1024];
            long done = 0;
            int files = 0;
            int skipped = 0;
            SevenZArchiveEntry e;
            while ((e = sz.getNextEntry()) != null) {
                if (p.cancelled.get()) break;
                File out = new File(destDir, e.getName());
                String outCanon = out.getCanonicalPath();
                if (!outCanon.equals(destCanon) && !outCanon.startsWith(destPrefix)) {
                    throw new IOException("Entrada inválida no 7z: " + e.getName());
                }
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                if (e.isAntiItem()) continue;
                File parent = out.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                int act = conflict(out);
                if (act == 1) {
                    skipped++;
                    if (e.getSize() > 0) done += e.getSize();
                    continue;
                } else if (act == 2) {
                    out = targetFor(out.getParentFile(), out);
                } else if (out.exists()) {
                    out.delete();
                }

                OutputStream os = new FileOutputStream(out);
                try {
                    int n;
                    while ((n = sz.read(buf)) != -1) {
                        os.write(buf, 0, n);
                        done += n;
                        p.update(e.getName(), done, total);
                        if (p.cancelled.get()) break;
                    }
                } finally {
                    os.close();
                }
                if (p.cancelled.get()) {
                    out.delete();
                    break;
                }
                if (e.getHasLastModifiedDate()) {
                    long t = e.getLastModifiedDate().getTime();
                    if (t > 0) out.setLastModified(t);
                }
                files++;
            }
            String msg = files + " arquivo(s) extraído(s)";
            if (skipped > 0) msg += ", " + skipped + " já existiam e foram ignorados";
            return msg;
        } finally {
            sz.close();
        }
    }

    private class SzCtx {
        final SevenZOutputFile out7;
        final File out;
        final Progress p;
        final long total;
        final byte[] buf = new byte[64 * 1024];
        long done;
        int skipped;

        SzCtx(SevenZOutputFile out7, File out, Progress p, long total) {
            this.out7 = out7;
            this.out = out;
            this.p = p;
            this.total = total;
        }
    }

    private String sevenZFiles(List<File> items, File outFile, Progress p, int level) throws IOException {
        long total = 0;
        for (File f : items) total += sizeOf(f);

        SevenZOutputFile o = new SevenZOutputFile(outFile);
        SzCtx ctx = new SzCtx(o, outFile, p, total);
        boolean finished = false;
        try {
            if (level == 0) {
                o.setContentCompression(SevenZMethod.COPY);
            } else {
                String m = prefs.getString("method7z", "LZMA2");
                SevenZMethodConfiguration cfg;
                if ("BZIP2".equals(m)) {
                    cfg = new SevenZMethodConfiguration(SevenZMethod.BZIP2);
                } else if ("DEFLATE".equals(m)) {
                    cfg = new SevenZMethodConfiguration(SevenZMethod.DEFLATE, ZIP_LEVELS[level]);
                } else {
                    cfg = new SevenZMethodConfiguration("LZMA".equals(m) ? SevenZMethod.LZMA : SevenZMethod.LZMA2,
                            new LZMA2Options(SEVENZ_PRESETS[level]));
                }
                o.setContentMethods(Collections.singletonList(cfg));
            }
            for (File f : items) {
                if (p.cancelled.get()) break;
                addTo7z(ctx, f, f.getName());
            }
            if (!p.cancelled.get()) {
                o.finish();
                o.close();
                finished = true;
            }
        } finally {
            if (!finished) {
                try {
                    o.close();
                } catch (IOException ignored) {
                }
                outFile.delete();
            }
        }

        String msg = "Criado " + outFile.getName() + " (" + formatSize(outFile.length()) + ")";
        if (ctx.skipped > 0) msg += ", " + ctx.skipped + " arquivo(s) ignorado(s)";
        return msg;
    }

    private void addTo7z(SzCtx c, File f, String name) throws IOException {
        if (c.p.cancelled.get()) return;
        if (f.getAbsolutePath().equals(c.out.getAbsolutePath())) return;

        boolean dir = f.isDirectory();
        if (!dir && !f.isFile()) return;

        SevenZArchiveEntry e = new SevenZArchiveEntry();
        e.setName(name);
        e.setDirectory(dir);
        e.setLastModifiedDate(new Date(f.lastModified()));

        if (dir) {
            c.out7.putArchiveEntry(e);
            c.out7.closeArchiveEntry();
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) addTo7z(c, k, name + "/" + k.getName());
            }
            return;
        }

        FileInputStream in;
        try {
            in = new FileInputStream(f);
        } catch (FileNotFoundException ex) {
            c.skipped++;
            return;
        }
        try {
            c.out7.putArchiveEntry(e);
            int n;
            while ((n = in.read(c.buf)) != -1) {
                c.out7.write(c.buf, 0, n);
                c.done += n;
                c.p.update(name, c.done, c.total);
                if (c.p.cancelled.get()) return;
            }
            c.out7.closeArchiveEntry();
        } finally {
            in.close();
        }
    }

    // ---------------------------------------------------------------- apagar, renomear, nova pasta

    private void confirmDelete(final List<File> items) {
        if (!prefs.getBoolean("confirmDelete", true)) {
            finishMode();
            runJob("Apagando…", p -> deleteAll(items, p));
            return;
        }
        String msg = items.size() == 1
                ? "Apagar \"" + items.get(0).getName() + "\"?"
                : "Apagar " + items.size() + " itens?";
        new AlertDialog.Builder(this)
                .setTitle("Apagar")
                .setMessage(msg + "\nIsso não pode ser desfeito.")
                .setPositiveButton("Apagar", (d, w) -> {
                    finishMode();
                    runJob("Apagando…", p -> deleteAll(items, p));
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private String deleteAll(List<File> items, Progress p) {
        int[] counts = new int[2]; // [0] apagados, [1] falhas
        for (File f : items) {
            if (p.cancelled.get()) break;
            deleteRec(f, p, counts);
        }
        String msg = counts[0] + " item(ns) apagado(s)";
        if (counts[1] > 0) msg += ", " + counts[1] + " não puderam ser apagados";
        return msg;
    }

    private void deleteRec(File f, Progress p, int[] counts) {
        if (p.cancelled.get()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) deleteRec(k, p, counts);
            }
        }
        p.update(f.getName(), 0, 0);
        if (f.delete()) counts[0]++;
        else counts[1]++;
    }

    private void promptRename(final File f) {
        promptText("Renomear", f.getName(), "Renomear", text -> {
            String name = cleanName(text);
            if (name.isEmpty() || name.equals(f.getName())) return;
            File to = new File(f.getParentFile(), name);
            if (to.exists()) {
                toast("Já existe: " + name);
                return;
            }
            if (f.renameTo(to)) {
                finishMode();
                reload();
            } else {
                toast("Não foi possível renomear");
            }
        });
    }

    private void promptNewFolder() {
        if (current == null) return;
        final File dir = current;
        promptText("Nova pasta", "", "Criar", text -> {
            String name = cleanName(text);
            if (name.isEmpty()) return;
            File f = new File(dir, name);
            if (f.exists()) {
                toast("Já existe: " + name);
                return;
            }
            if (f.mkdir()) reload();
            else toast("Não foi possível criar a pasta");
        });
    }

    // ---------------------------------------------------------------- jobs com progresso

    private interface Job {
        String run(Progress p) throws Exception;
    }

    private interface TextCallback {
        void onText(String text);
    }

    private class Progress {
        final AtomicBoolean cancelled = new AtomicBoolean(false);
        private final TextView status;
        private final ProgressBar bar;
        private long lastUi;

        Progress(TextView status, ProgressBar bar) {
            this.status = status;
            this.bar = bar;
        }

        void update(final String text, final long done, final long total) {
            long now = SystemClock.uptimeMillis();
            if (now - lastUi < 100) return;
            lastUi = now;
            runOnUiThread(() -> {
                status.setText(text);
                if (total > 0) {
                    bar.setIndeterminate(false);
                    bar.setMax(1000);
                    bar.setProgress((int) Math.min(1000, done * 1000 / total));
                }
            });
        }
    }

    private void runJob(String title, final Job job) {
        runJob(title, job, null);
    }

    private void runJob(String title, final Job job, final Runnable onSuccess) {
        overwriteAll = -1;
        int pad = dp(20);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, dp(8));

        TextView status = new TextView(this);
        status.setSingleLine(true);
        status.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        status.setText("Preparando…");

        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);

        box.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        barLp.topMargin = dp(12);
        box.addView(bar, barLp);

        final CheckBox keepCb = new CheckBox(this);
        keepCb.setText("Manter tela ligada durante a operação");
        keepCb.setChecked(prefs.getBoolean("keepOn", true));
        keepCb.setOnCheckedChangeListener((v, c) -> {
            prefs.edit().putBoolean("keepOn", c).apply();
            applyKeepOn(c);
        });
        LinearLayout.LayoutParams keepLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        keepLp.topMargin = dp(8);
        box.addView(keepCb, keepLp);

        final Progress p = new Progress(status, bar);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Cancelar operação", null)
                .create();
        dialog.show();
        final Button cancel = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        cancel.setOnClickListener(v -> {
            final Runnable doCancel = () -> {
                p.cancelled.set(true);
                cancel.setEnabled(false);
                cancel.setText("Cancelando…");
            };
            if (prefs.getBoolean("confirmCancel", true)) {
                new AlertDialog.Builder(this)
                        .setTitle("Interromper?")
                        .setMessage("Deseja interromper a operação?")
                        .setPositiveButton("Sim", (d, w) -> doCancel.run())
                        .setNegativeButton("Não", null)
                        .show();
            } else {
                doCancel.run();
            }
        });

        jobStarted();
        executor.execute(() -> {
            String msg = null;
            String err = null;
            try {
                msg = job.run(p);
            } catch (Throwable t) {
                err = t.getClass().getSimpleName() + ": " + t.getMessage();
            }
            final String fMsg = msg;
            final String fErr = err;
            jobEnded();
            runOnUiThread(() -> {
                try {
                    dialog.dismiss();
                } catch (Exception ignored) {
                }
                boolean ok = false;
                if (p.cancelled.get()) {
                    toast("Cancelado");
                } else if (fErr != null) {
                    toast("Erro: " + fErr);
                } else {
                    ok = true;
                    if (fMsg != null) toast(fMsg);
                }
                if (!isFinishing()) {
                    reload();
                    if (ok && onSuccess != null) onSuccess.run();
                }
            });
        });
    }

    private void promptText(String title, String initial, String okLabel, final TextCallback cb) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(initial);
        int dot = initial.lastIndexOf('.');
        et.setSelection(0, dot > 0 ? dot : initial.length());

        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(et, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton(okLabel, (dlg, w) -> cb.onText(et.getText().toString()))
                .setNegativeButton("Cancelar", null)
                .create();
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }

    // ---------------------------------------------------------------- menus em folha (bottom sheet)

    private static class Act {
        final String icon;
        final String label;
        final Runnable run;

        Act(String icon, String label, Runnable run) {
            this.icon = icon;
            this.label = label;
            this.run = run;
        }
    }

    private void showSheet(String title, List<Act> acts) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        TextView t = new TextView(this);
        t.setTextAppearance(android.R.style.TextAppearance_Material_Title);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        t.setPadding(dp(20), dp(16), dp(20), dp(12));
        t.setText(title);
        root.addView(t, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View div = new View(this);
        div.setBackgroundColor(0x33808080);
        root.addView(div, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final AlertDialog dlg = new AlertDialog.Builder(this).setView(root).create();
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true);

        for (final Act a : acts) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(20), dp(14), dp(20), dp(14));
            row.setBackgroundResource(tv.resourceId);

            TextView ic = new TextView(this);
            ic.setText(a.icon);
            ic.setTextSize(20);
            ic.setGravity(Gravity.CENTER);
            row.addView(ic, new LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView lb = new TextView(this);
            lb.setTextAppearance(android.R.style.TextAppearance_Material_Subhead);
            lb.setText(a.label);
            row.addView(lb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            row.setOnClickListener(v -> {
                dlg.dismiss();
                a.run.run();
            });
            list.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(isDark() ? 0xFF1E1F24 : 0xFFFAFAFA);
        float r = dp(18);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(bg);
            w.setGravity(Gravity.BOTTOM);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (!prefs.getBoolean("animations", true)) w.setWindowAnimations(0);
        }
        dlg.show();
    }

    // ---------------------------------------------------------------- copiar / recortar / colar

    private void setClip(List<File> items, boolean cut) {
        clip.clear();
        clip.addAll(items);
        clipCut = cut;
        finishMode();
        updatePasteBar();
        toast((cut ? "Recortado: " : "Copiado: ") + items.size() + " item(ns). Abra a pasta de destino e toque em ✓ para colar.");
    }

    /** Com algo copiado/recortado, o "+" vira ✓ (colar). A barra de colar fica oculta; voltar cancela. */
    private void updatePasteBar() {
        pasteBar.setVisibility(View.GONE);
        if (clip.isEmpty()) {
            fab.setText("+");
            fab.setTranslationY(0);
            applyFabStyle();
        } else {
            fab.setText("\u2713");
            fab.setVisibility(View.VISIBLE);
            fab.animate().scaleX(1.2f).scaleY(1.2f).setDuration(120).withEndAction(
                    () -> fab.animate().scaleX(1f).scaleY(1f).setDuration(120).start()).start();
        }
    }

    private static boolean isInside(File child, File parent) {
        try {
            String c = child.getCanonicalPath() + File.separator;
            String p = parent.getCanonicalPath() + File.separator;
            return c.startsWith(p);
        } catch (IOException e) {
            return false;
        }
    }

    private void pasteHere() {
        if (clip.isEmpty() || current == null) return;
        final File dest = current;
        final List<File> items = new ArrayList<>(clip);
        final boolean cut = clipCut;
        for (File f : items) {
            if (f.isDirectory() && isInside(dest, f)) {
                toast("Não dá pra colar uma pasta dentro dela mesma");
                return;
            }
        }
        clip.clear();
        updatePasteBar();
        runJob(cut ? "Movendo…" : "Copiando…", p -> pasteAll(items, dest, cut, p));
    }

    private static File targetFor(File dest, File f) {
        String n = f.getName();
        if (f.isDirectory()) return uniqueFile(dest, n, "");
        int dot = n.lastIndexOf('.');
        if (dot > 0) return uniqueFile(dest, n.substring(0, dot), n.substring(dot));
        return uniqueFile(dest, n, "");
    }

    private String pasteAll(List<File> items, File dest, boolean cut, Progress p) throws IOException {
        long total = 0;
        for (File f : items) total += sizeOf(f);
        long[] done = {0};
        byte[] buf = new byte[64 * 1024];
        int count = 0;
        for (File f : items) {
            if (p.cancelled.get()) break;
            if (cut && dest.equals(f.getParentFile())) continue; // já está nesta pasta
            File target = new File(dest, f.getName());
            if (target.exists()) {
                int act = conflict(target);
                if (act == 1) continue;
                if (act == 2) target = targetFor(dest, f);
                else deleteTree(target);
            }
            if (cut && f.renameTo(target)) {
                count++;
                continue;
            }
            copyRec(f, target, p, buf, done, total);
            if (p.cancelled.get()) break;
            if (cut) deleteTree(f);
            count++;
        }
        return (cut ? "Movido(s): " : "Copiado(s): ") + count + " item(ns)";
    }

    private void copyRec(File src, File dst, Progress p, byte[] buf, long[] done, long total)
            throws IOException {
        if (p.cancelled.get()) return;
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) {
                throw new IOException("Não foi possível criar " + dst.getName());
            }
            File[] kids = src.listFiles();
            if (kids != null) {
                for (File k : kids) copyRec(k, new File(dst, k.getName()), p, buf, done, total);
            }
            dst.setLastModified(src.lastModified());
            return;
        }
        if (!src.isFile()) return;
        InputStream in = new FileInputStream(src);
        try {
            OutputStream os = new FileOutputStream(dst);
            try {
                int n;
                while ((n = in.read(buf)) != -1) {
                    os.write(buf, 0, n);
                    done[0] += n;
                    p.update(src.getName(), done[0], total);
                    if (p.cancelled.get()) break;
                }
            } finally {
                os.close();
            }
        } finally {
            in.close();
        }
        if (p.cancelled.get()) {
            dst.delete();
            return;
        }
        dst.setLastModified(src.lastModified());
    }

    private static void deleteTree(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) deleteTree(k);
            }
        }
        f.delete();
    }

    // ---------------------------------------------------------------- informações

    private static class InfoData {
        long size;
        int files;
        int dirs;
        String md5;
        boolean hasArc;
        String arcType = "";
        int arcFiles;
        long arcSize;
    }

    private void showInfo(final File f) {
        final InfoData d = new InfoData();
        runJob("Calculando…", p -> {
            long[] size = {0};
            int[] counts = {0, 0};
            measure(f, size, counts, p);
            d.size = size[0];
            d.files = counts[0];
            d.dirs = counts[1];
            if (f.isFile() && !p.cancelled.get()) d.md5 = md5(f, p);
            if (f.isFile() && isArchiveFile(f) && !p.cancelled.get()) {
                try {
                    List<AEntry> idx = indexArchive(f, p);
                    d.hasArc = true;
                    d.arcType = archiveTypeName(f);
                    for (AEntry e : idx) {
                        if (!e.dir) {
                            d.arcFiles++;
                            d.arcSize += Math.max(0, e.size);
                        }
                    }
                } catch (Exception ignored) {
                    // sem as informações do conteúdo
                }
            }
            return null;
        }, () -> showInfoDialog(f, d));
    }

    private void measure(File f, long[] size, int[] counts, Progress p) {
        if (p.cancelled.get()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) {
                    if (k.isDirectory()) counts[1]++;
                    else counts[0]++;
                    measure(k, size, counts, p);
                }
            }
        } else {
            size[0] += f.length();
        }
        p.update(f.getName(), 0, 0);
    }

    private static String md5(File f, Progress p) throws IOException {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new IOException(e.getMessage());
        }
        long total = f.length();
        long done = 0;
        byte[] buf = new byte[128 * 1024];
        try (InputStream in = new FileInputStream(f)) {
            int n;
            while ((n = in.read(buf)) != -1) {
                md.update(buf, 0, n);
                done += n;
                p.update("MD5: " + f.getName(), done, total);
                if (p.cancelled.get()) return null;
            }
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }

    private static String archiveTypeName(File f) {
        String[] tn = {"tar", "tar.lz4", "tar.gz", "tar.xz", "tar.bz2"};
        String[] sn = {"", "lz4", "gz", "xz", "bz2"};
        if (tarCodec(f) >= 0) return tn[tarCodec(f)];
        if (singleCodec(f) >= 0) return sn[singleCodec(f)];
        if (isSevenZ(f)) return "7z";
        return "zip";
    }

    private static String permString(File f) {
        try {
            int m = Os.stat(f.getAbsolutePath()).st_mode & 0777;
            StringBuilder sb = new StringBuilder();
            for (int shift = 6; shift >= 0; shift -= 3) {
                sb.append((m >> shift & 4) != 0 ? 'r' : '-')
                        .append((m >> shift & 2) != 0 ? 'w' : '-')
                        .append((m >> shift & 1) != 0 ? 'x' : '-')
                        .append(' ');
            }
            return sb.toString().trim() + " (" + Integer.toOctalString(m) + ")";
        } catch (Exception e) {
            return (f.canRead() ? "r" : "-") + (f.canWrite() ? "w" : "-") + (f.canExecute() ? "x" : "-");
        }
    }

    private static String fsType(File f) {
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/mounts"))) {
            String path = f.getCanonicalPath();
            String best = "";
            String type = "—";
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(" ");
                if (a.length < 3) continue;
                String mp = a[1];
                boolean match = path.equals(mp) || path.startsWith(mp.endsWith("/") ? mp : mp + "/");
                if (match && mp.length() >= best.length()) {
                    best = mp;
                    type = a[2];
                }
            }
            return type;
        } catch (Exception e) {
            return "—";
        }
    }

    private void infoRow(LinearLayout box, StringBuilder copy, String k, String v) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView tk = new TextView(this);
        tk.setTextAppearance(android.R.style.TextAppearance_Material_Body1);
        tk.setText(k + ":");
        TextView tv = new TextView(this);
        tv.setTextAppearance(android.R.style.TextAppearance_Material_Body1);
        tv.setText(v);
        tv.setTextIsSelectable(true);
        row.addView(tk, new LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(row);
        copy.append(k).append(": ").append(v).append('\n');
    }

    private TextView infoHeader(String text) {
        TextView t = new TextView(this);
        t.setTextAppearance(android.R.style.TextAppearance_Material_Subhead);
        t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setText(text);
        t.setPadding(0, dp(12), 0, dp(4));
        return t;
    }

    private void showInfoDialog(File f, InfoData d) {
        final StringBuilder copy = new StringBuilder();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(8));

        TextView name = new TextView(this);
        name.setTextAppearance(android.R.style.TextAppearance_Material_Title);
        name.setText(f.getName());
        box.addView(name);
        copy.append(f.getName()).append('\n');

        box.addView(infoHeader("Informações Gerais"));
        infoRow(box, copy, "Tipo", f.isDirectory() ? "Pasta" : mimeOf(f));
        infoRow(box, copy, "Tamanho", formatSize(d.size) + " (" + d.size + "B)");
        infoRow(box, copy, "Última modificação",
                new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new Date(f.lastModified())));
        infoRow(box, copy, "Permissões", permString(f));
        infoRow(box, copy, "Caminho", String.valueOf(f.getParent()));
        infoRow(box, copy, "Sistema de arquivos", fsType(f));
        if (f.isDirectory()) {
            infoRow(box, copy, "Conteúdo", d.files + " arquivo(s), " + d.dirs + " pasta(s)");
        } else if (d.md5 != null) {
            infoRow(box, copy, "MD5", d.md5);
        }
        if (d.hasArc) {
            box.addView(infoHeader("Informações do arquivo"));
            infoRow(box, copy, "Tipo", d.arcType);
            infoRow(box, copy, "Contagem de arquivo", String.valueOf(d.arcFiles));
            infoRow(box, copy, "Tamanho do conteúdo", formatSize(d.arcSize) + " (" + d.arcSize + "B)");
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this)
                .setTitle("Informações do arquivo")
                .setView(sv)
                .setNeutralButton("COPIAR", (dlg, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("info", copy.toString().trim()));
                    toast("Copiado");
                })
                .setPositiveButton("OK", null)
                .show();
    }

    // ---------------------------------------------------------------- compartilhar e abrir com

    private static String mimeOf(File f) {
        String n = f.getName();
        int dot = n.lastIndexOf('.');
        if (dot > 0 && dot < n.length() - 1) {
            String m = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(n.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    private void shareFiles(List<File> items) {
        ArrayList<Uri> uris = new ArrayList<>();
        for (File f : items) {
            if (f.isFile()) uris.add(FileShareProvider.uriFor(f));
        }
        if (uris.isEmpty()) {
            toast("Pastas não podem ser compartilhadas. Compacte a pasta primeiro.");
            return;
        }
        try {
            Intent i;
            if (uris.size() == 1) {
                i = new Intent(Intent.ACTION_SEND);
                i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                i.setType(mimeOf(items.get(0)));
            } else {
                i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                i.setType("*/*");
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Compartilhar"));
        } catch (Exception e) {
            toast("Não foi possível compartilhar: " + e.getMessage());
        }
    }

    private void openImage(File f) {
        Intent i = new Intent(this, ImageViewActivity.class);
        i.putExtra("path", f.getAbsolutePath());
        startActivity(i);
    }

    private static boolean isTextFile(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        return hasExt(n, ".txt", ".md", ".log", ".json", ".xml", ".html", ".css", ".js",
                ".java", ".kt", ".ini", ".cfg", ".csv", ".sh");
    }

    private void openTextEditor(File f) {
        Intent i = new Intent(this, TextEditorActivity.class);
        i.putExtra("path", f.getAbsolutePath());
        startActivity(i);
    }

    private void openWith(File f) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(FileShareProvider.uriFor(f), mimeOf(f));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Abrir com"));
        } catch (Exception e) {
            toast("Nenhum app encontrado para abrir este arquivo");
        }
    }

    // ---------------------------------------------------------------- escolher pasta (Extrair...)

    private interface FolderCallback {
        void onFolder(File dir);
    }

    private void pickFolder(String title, File start, final FolderCallback cb) {
        final File[] cur = {start};
        final TextView pathTv = new TextView(this);
        pathTv.setPadding(dp(20), dp(8), dp(20), dp(8));
        pathTv.setSingleLine(true);
        pathTv.setEllipsize(TextUtils.TruncateAt.START);

        final List<File> dirs = new ArrayList<>();
        final ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        final ListView lv = new ListView(this);
        lv.setAdapter(ad);

        final Runnable refresh = () -> {
            dirs.clear();
            ad.clear();
            ad.add("..");
            dirs.add(cur[0].getParentFile());
            File[] kids = cur[0].listFiles((FileFilter) k -> k.isDirectory());
            if (kids != null) {
                Arrays.sort(kids, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
                for (File k : kids) {
                    ad.add("▰ " + k.getName());
                    dirs.add(k);
                }
            }
            pathTv.setText(cur[0].getAbsolutePath());
        };
        lv.setOnItemClickListener((parent, view, pos, id) -> {
            File target = dirs.get(pos);
            if (target != null) {
                cur[0] = target;
                refresh.run();
            }
        });

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(pathTv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320)));
        refresh.run();

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("Selecionar", (d, w) -> cb.onFolder(cur[0]))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ---------------------------------------------------------------- testar integridade

    private void testArchive(final File f) {
        runJob("Testando " + f.getName(), p -> {
            int n;
            if (tarCodec(f) >= 0) n = testTar(f, tarCodec(f), p);
            else if (isSevenZ(f)) n = test7z(f, p);
            else if (singleCodec(f) >= 0) n = testSingle(f, singleCodec(f), p);
            else n = testZip(f, p);
            return "Nenhum erro encontrado (" + n + " item(ns) verificado(s))";
        });
    }

    private int testZip(File f, Progress p) throws IOException {
        ZipFile zf = new ZipFile(f, Prefs.zipCharset(this));
        try {
            long total = 0;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) total += Math.max(0, en.nextElement().getSize());
            long done = 0;
            int count = 0;
            byte[] buf = new byte[64 * 1024];
            en = zf.entries();
            while (en.hasMoreElements()) {
                if (p.cancelled.get()) break;
                ZipEntry e = en.nextElement();
                count++;
                if (e.isDirectory()) continue;
                CRC32 crc = new CRC32();
                InputStream in = zf.getInputStream(e);
                try {
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        crc.update(buf, 0, n);
                        done += n;
                        p.update(e.getName(), done, total);
                        if (p.cancelled.get()) break;
                    }
                } finally {
                    in.close();
                }
                if (!p.cancelled.get() && e.getCrc() != -1 && crc.getValue() != e.getCrc()) {
                    throw new IOException("CRC inválido em " + e.getName());
                }
            }
            return count;
        } finally {
            zf.close();
        }
    }

    private int testTar(File f, int codec, Progress p) throws IOException {
        long total = f.length();
        TarIO.Counting cin = new TarIO.Counting(new BufferedInputStream(new FileInputStream(f), 64 * 1024));
        InputStream src = null;
        int count = 0;
        try {
            src = wrapIn(cin, codec);
            TarIO.Reader tar = new TarIO.Reader(src);
            byte[] buf = new byte[64 * 1024];
            TarIO.Entry e;
            while ((e = tar.next()) != null) {
                if (p.cancelled.get()) break;
                count++;
                if (!e.isRegular()) continue;
                while (tar.read(buf, 0, buf.length) != -1) {
                    p.update(e.name, cin.count, total);
                    if (p.cancelled.get()) break;
                }
            }
        } finally {
            showClose(src, cin);
        }
        return count;
    }

    private int test7z(File f, Progress p) throws IOException {
        SevenZFile sz = SevenZFile.builder().setFile(f).get();
        try {
            long total = 0;
            for (SevenZArchiveEntry e : sz.getEntries()) {
                if (!e.isDirectory()) total += Math.max(0, e.getSize());
            }
            long done = 0;
            int count = 0;
            byte[] buf = new byte[64 * 1024];
            SevenZArchiveEntry e;
            while ((e = sz.getNextEntry()) != null) {
                if (p.cancelled.get()) break;
                count++;
                if (e.isDirectory()) continue;
                int n;
                while ((n = sz.read(buf)) != -1) {
                    done += n;
                    p.update(e.getName(), done, total);
                    if (p.cancelled.get()) break;
                }
            }
            return count;
        } finally {
            sz.close();
        }
    }

    private int testSingle(File f, int codec, Progress p) throws IOException {
        long total = f.length();
        TarIO.Counting cin = new TarIO.Counting(new BufferedInputStream(new FileInputStream(f), 64 * 1024));
        InputStream src = null;
        try {
            src = wrapIn(cin, codec);
            byte[] buf = new byte[64 * 1024];
            while (src.read(buf) != -1) {
                p.update(f.getName(), cin.count, total);
                if (p.cancelled.get()) break;
            }
        } finally {
            showClose(src, cin);
        }
        return 1;
    }

    // ---------------------------------------------------------------- aparência e visualização

    private boolean isDark() {
        return Prefs.isDark(this);
    }

    private int viewMode() {
        return Prefs.num(this, "viewMode", 0);
    }

    private void applyViewMode() {
        boolean grid = viewMode() == 2;
        boolean fast = prefs.getBoolean("fastScroll", true);
        for (Pane pn : new Pane[]{pane1, pane2}) {
            if (pn == null) continue;
            pn.list.setVisibility(grid ? View.GONE : View.VISIBLE);
            pn.grid.setVisibility(grid ? View.VISIBLE : View.GONE);
            pn.list.setFastScrollEnabled(fast);
            pn.grid.setFastScrollEnabled(fast);
            if (pn.adapter != null) pn.adapter.notifyDataSetChanged();
        }
    }

    private void applyBackground() {
        if (Prefs.num(this, "bgType", 1) == 2) { // cor sólida do fundo
            bgStamp = -2;
            bgImage.setImageDrawable(new ColorDrawable(Prefs.parseHex(prefs.getString("bgHex", ""), 0xFF1E1F24)));
            bgImage.setVisibility(View.VISIBLE);
            bgScrim.setVisibility(View.GONE);
            return;
        }
        File f = Prefs.bgFile(this);
        if (Prefs.num(this, "bgType", 1) == 0) f = new File(f.getParentFile(), "bg-off.jpg");
        int pct = Prefs.num(this, "scrimPct", 55);
        long stamp = (f.exists() ? f.lastModified() : 0) + pct * 31L + (isDark() ? 1 : 0);
        if (stamp == bgStamp) return;
        bgStamp = stamp;
        Bitmap b = f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
        if (b != null) {
            bgImage.setImageBitmap(b);
            bgImage.setVisibility(View.VISIBLE);
            bgScrim.setVisibility(View.VISIBLE);
            int a = pct * 255 / 100;
            bgScrim.setBackgroundColor(isDark() ? Color.argb(a, 0, 0, 0) : Color.argb(a, 255, 255, 255));
        } else {
            bgImage.setImageDrawable(null);
            bgImage.setVisibility(View.GONE);
            bgScrim.setVisibility(View.GONE);
        }
    }

    private void setupList(AdapterView<?> v) {
        v.setOnItemClickListener((parent, view, position, id) -> {
            activate((Pane) parent.getTag());
            File f = adapter.getItem(position);
            if (f == null) return;
            if (f == upItem) {
                if (current != null && current.getParentFile() != null) openDir(current.getParentFile());
                return;
            }
            if (actionMode != null) {
                toggle(f);
            } else if (f.isDirectory()) {
                openDir(f);
            } else if (isArchiveFile(f)) {
                int act = Prefs.num(this, "tapArchive", 0);
                if (act == 1) viewArchive(f);
                else if (act == 2) startExtract(f, current);
                else showArchiveSheet(f);
            } else if (Prefs.num(this, "tapFile", 0) == 1) {
                showItemSheet(f);
            } else if (isImage(f)) {
                openImage(f);
            } else if (isTextFile(f)) {
                openTextEditor(f);
            } else {
                openWith(f);
            }
        });
        v.setOnItemLongClickListener((parent, view, position, id) -> {
            activate((Pane) parent.getTag());
            File f = adapter.getItem(position);
            if (f == null || f == upItem) return true;
            if (actionMode != null) {
                if (selected.contains(f)) showSelectionSheet(new ArrayList<>(selected));
                else toggle(f);
            } else showItemSheet(f);
            return true;
        });
    }

    private void startMultiSelect() {
        if (actionMode == null) {
            actionMode = startActionMode(modeCallback);
            if (actionMode != null) actionMode.setTitle("Selecione os itens");
        }
    }

    private LinearLayout optButton(String icon, String label, boolean on, final Runnable action) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        b.setPadding(dp(4), dp(6), dp(4), dp(0));
        TextView ic = new TextView(this);
        ic.setText(icon);
        ic.setTextSize(22);
        ic.setGravity(Gravity.CENTER);
        TextView lb = new TextView(this);
        lb.setText(label);
        lb.setTextSize(11);
        lb.setGravity(Gravity.CENTER);
        View bar = new View(this);
        bar.setBackgroundColor(on ? 0xFF8FB3C7 : Color.TRANSPARENT);
        b.addView(ic, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        b.addView(lb, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(40), dp(3));
        bl.topMargin = dp(4);
        b.addView(bar, bl);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView sectionTitle(String text) {
        TextView t = new TextView(this);
        t.setTextAppearance(android.R.style.TextAppearance_Material_Subhead);
        t.setText(text);
        t.setPadding(dp(4), dp(10), 0, dp(2));
        return t;
    }

    /** Menu "Visualizar / Ordenar" (as 3 barrinhas do ZArchiver). */
    private void showViewPopup() {
        final AlertDialog[] dlg = new AlertDialog[1];
        final int vm = viewMode();
        final int sort = Prefs.num(this, "sortBy", 0);
        final boolean hid = prefs.getBoolean("showHidden", false);
        final boolean desc = prefs.getBoolean("sortDesc", false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(4), dp(12), dp(14));

        root.addView(sectionTitle("Visualizar"));
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        final String[] modeNames = {"Detalhado", "Compacto", "Grade"};
        final String[] modeIcons = {"\u2630", "\u2261", "\u25A6"};
        for (int i = 0; i < 3; i++) {
            final int mi = i;
            r1.addView(optButton(modeIcons[i], modeNames[i], vm == i, () -> {
                Prefs.putNum(this, "viewMode", mi);
                applyViewMode();
                dlg[0].dismiss();
            }), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        r1.addView(optButton("◉", "Oculto", hid, () -> {
            prefs.edit().putBoolean("showHidden", !hid).apply();
            reload();
            dlg[0].dismiss();
        }), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(r1);

        root.addView(sectionTitle("Ordenar"));
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        final String[] sortNames = {"Nome", "Tamanho", "Data", "Tipo"};
        final String[] sortIcons = {"AZ", "\u2194", "□", "□"};
        for (int i = 0; i < 4; i++) {
            final int si = i;
            r2.addView(optButton(sortIcons[i], sortNames[i], sort == i, () -> {
                Prefs.putNum(this, "sortBy", si);
                reload();
                dlg[0].dismiss();
            }), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        r2.addView(optButton("\u21C5", "Decrescente", desc, () -> {
            prefs.edit().putBoolean("sortDesc", !desc).apply();
            reload();
            dlg[0].dismiss();
        }), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(r2);

        dlg[0] = new AlertDialog.Builder(this).setView(root).create();
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(isDark() ? 0xFF2A2B30 : 0xFFF2F2F2);
        bg.setCornerRadius(dp(12));
        Window w = dlg[0].getWindow();
        if (w != null) {
            w.setBackgroundDrawable(bg);
            w.setGravity(Gravity.TOP | Gravity.END);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.y = dp(48);
            lp.x = dp(8);
            w.setAttributes(lp);
        }
        dlg[0].show();
    }

    // ---------------------------------------------------------------- novo (pasta, arquivo, arquivo compactado), sobre

    private void showNewSheet() {
        List<Act> acts = new ArrayList<>();
        acts.add(new Act("▣", "Criar arquivo compactado", this::promptNewArchive));
        acts.add(new Act("▰", "Criar pasta", this::promptNewFolder));
        acts.add(new Act("≡", "Criar arquivo txt", this::promptNewFile));
        showSheet("Novo", acts);
    }

    private void promptNewFile() {
        if (current == null) return;
        final File dir = current;
        promptText("Novo arquivo", "novo.txt", "Criar", text -> {
            String name = cleanName(text);
            if (name.isEmpty()) return;
            File f = new File(dir, name);
            if (f.exists()) {
                toast("Já existe: " + name);
                return;
            }
            try {
                if (f.createNewFile()) reload();
                else toast("Não foi possível criar o arquivo");
            } catch (IOException e) {
                toast("Erro: " + e.getMessage());
            }
        });
    }

    private void promptNewArchive() {
        if (current == null) return;
        final File dir = current;
        new AlertDialog.Builder(this)
                .setTitle("Novo arquivo compactado")
                .setItems(FORMATS, (d, which) -> promptText("Nome do arquivo", "novo", "Criar", text -> {
                    String name = cleanName(text);
                    if (name.isEmpty()) return;
                    final File out = uniqueFile(dir, name, FORMAT_EXT[which]);
                    runJob("Criando…", p -> {
                        createEmptyArchive(out, which);
                        return "Criado: " + out.getName();
                    });
                }))
                .show();
    }

    private void createEmptyArchive(File out, int fi) throws IOException {
        try (OutputStream os = new FileOutputStream(out)) {
            if (fi == 0) {
                byte[] z = new byte[22];
                z[0] = 0x50;
                z[1] = 0x4B;
                z[2] = 5;
                z[3] = 6;
                os.write(z);
            } else if (fi == 1) {
                byte[] tail = new byte[20];
                CRC32 crc = new CRC32();
                crc.update(tail);
                long c = crc.getValue();
                byte[] h = {'7', 'z', (byte) 0xBC, (byte) 0xAF, 0x27, 0x1C, 0, 4};
                os.write(h);
                os.write(new byte[]{(byte) c, (byte) (c >> 8), (byte) (c >> 16), (byte) (c >> 24)});
                os.write(tail);
            } else if (fi == 2) {
                os.write(new byte[1024]);
            } else {
                int codec = fi == 3 ? C_LZ4 : (fi == 4 ? C_GZ : (fi == 5 ? C_XZ : C_BZ2));
                OutputStream sink = wrapOut(os, codec, 1);
                new TarIO.Writer(sink).finish();
                sink.close();
            }
        }
    }

    private void showDiagnostics() {
        final boolean on = com.example.arcfm.diagnostics.DiagnosticLog.isEnabled();
        new AlertDialog.Builder(this)
                .setTitle("Diagnóstico")
                .setMessage(on ? "Registro ligado (desligado por padrão, limite de 512 KB com rotação)."
                        : "Registro desligado. Ligue só se precisar investigar um erro.")
                .setPositiveButton(on ? "Desligar" : "Ligar", (d, w) -> {
                    prefs.edit().putBoolean("diagOn", !on).apply();
                    com.example.arcfm.diagnostics.DiagnosticLog.setEnabled(!on);
                    toast(on ? "Diagnóstico desligado" : "Diagnóstico ligado");
                })
                .setNeutralButton("Visualizar", (d, w) -> showTextDialog("Registro",
                        com.example.arcfm.diagnostics.DiagnosticLog.read()))
                .setNegativeButton("Limpar", (d, w) -> com.example.arcfm.diagnostics.DiagnosticLog.clear())
                .show();
    }

    private void showTextDialog(String title, String text) {
        TextView tv = new TextView(this);
        tv.setTextIsSelectable(true);
        tv.setTextSize(11);
        tv.setPadding(dp(16), dp(8), dp(16), dp(8));
        tv.setText(text);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(sv)
                .setPositiveButton("Copiar", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("log", text));
                    toast("Copiado");
                })
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void showAbout() {
        String v = "?";
        try {
            v = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
            // sem versão
        }
        new AlertDialog.Builder(this)
                .setTitle("Sobre")
                .setMessage("ArcFM " + v + "\nGerenciador de arquivos e compactador pessoal.\n\n"
                        + "Formatos: ZIP, 7z, TAR, TAR.LZ4 e LZ4.")
                .setPositiveButton("OK", null)
                .show();
    }

    private String extractTarTwoStep(File archive, File dest, Progress p, int codec) throws IOException {
        File tmp = new File(getCacheDir(), "pipe-" + System.nanoTime() + ".tar");
        try {
            singleDecompress(archive, tmp, p, codec);
            if (p.cancelled.get()) return null;
            return extractTar(tmp, dest, p, C_NONE);
        } finally {
            tmp.delete();
        }
    }

    // ---------------------------------------------------------------- navegar dentro de um arquivo compactado

    private static class AEntry {
        final String raw;
        final String name;
        final boolean dir;
        final long size;
        final long mtime;

        AEntry(String raw, boolean dir, long size, long mtime) {
            this.raw = raw;
            String n = raw.replace('\\', '/');
            while (n.startsWith("./")) n = n.substring(2);
            while (n.startsWith("/")) n = n.substring(1);
            while (n.endsWith("/")) n = n.substring(0, n.length() - 1);
            this.name = n;
            this.dir = dir;
            this.size = size;
            this.mtime = mtime;
        }
    }

    private List<AEntry> indexArchive(File f, Progress p) throws IOException {
        List<AEntry> out = new ArrayList<>();
        if (tarCodec(f) >= 0) {
            long total = f.length();
            TarIO.Counting cin = new TarIO.Counting(
                    new BufferedInputStream(new FileInputStream(f), 64 * 1024));
            InputStream src = null;
            try {
                src = wrapIn(cin, tarCodec(f));
                TarIO.Reader tar = new TarIO.Reader(src);
                TarIO.Entry e;
                while ((e = tar.next()) != null) {
                    if (p.cancelled.get()) break;
                    out.add(new AEntry(e.name, e.isDir(), e.isRegular() ? e.size : 0, e.mtimeMs));
                    p.update(e.name, cin.count, total);
                }
            } finally {
                showClose(src, cin);
            }
        } else if (isSevenZ(f)) {
            SevenZFile sz = SevenZFile.builder().setFile(f).get();
            try {
                for (SevenZArchiveEntry e : sz.getEntries()) {
                    long t = e.getHasLastModifiedDate() ? e.getLastModifiedDate().getTime() : 0;
                    out.add(new AEntry(e.getName(), e.isDirectory(), Math.max(0, e.getSize()), t));
                }
            } finally {
                sz.close();
            }
        } else if (singleCodec(f) >= 0) {
            out.add(new AEntry(stripExt(f.getName()), false, 0, f.lastModified()));
        } else {
            ZipFile zf = new ZipFile(f, Prefs.zipCharset(this));
            try {
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    out.add(new AEntry(e.getName(), e.isDirectory(), Math.max(0, e.getSize()), e.getTime()));
                }
            } finally {
                zf.close();
            }
        }
        return out;
    }

    private void browseArchive(final File f) {
        final List<AEntry> all = new ArrayList<>();
        runJob("Lendo " + f.getName(), p -> {
            all.addAll(indexArchive(f, p));
            return null;
        }, () -> showArchiveBrowser(f, all));
    }

    private void showArchiveBrowser(final File archive, final List<AEntry> all) {
        final String[] prefix = {""};
        final List<AEntry> rows = new ArrayList<>();
        final ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        final ListView lv = new ListView(this);
        lv.setAdapter(ad);
        final AlertDialog[] dlg = new AlertDialog[1];

        final Runnable refresh = () -> {
            rows.clear();
            ad.clear();
            if (!prefix[0].isEmpty()) ad.add("..");
            Map<String, AEntry> kids = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            for (AEntry e : all) {
                if (!e.name.startsWith(prefix[0]) || e.name.length() == prefix[0].length()) continue;
                String rest = e.name.substring(prefix[0].length());
                int slash = rest.indexOf('/');
                if (slash >= 0) {
                    String child = rest.substring(0, slash);
                    if (!kids.containsKey(child)) {
                        kids.put(child, new AEntry(prefix[0] + child, true, 0, e.mtime));
                    }
                } else {
                    kids.put(rest, e);
                }
            }
            for (int pass = 0; pass < 2; pass++) {
                for (Map.Entry<String, AEntry> me : kids.entrySet()) {
                    AEntry e = me.getValue();
                    if (e.dir != (pass == 0)) continue;
                    rows.add(e);
                    ad.add(e.dir ? "▰ " + me.getKey()
                            : "□ " + me.getKey() + "  (" + formatSize(e.size) + ")");
                }
            }
            if (dlg[0] != null) {
                dlg[0].setTitle(archive.getName() + (prefix[0].isEmpty() ? "" : "  /" + prefix[0]));
            }
        };

        lv.setOnItemClickListener((parent, view, pos, id) -> {
            boolean up = !prefix[0].isEmpty();
            if (up && pos == 0) {
                String q = prefix[0].substring(0, prefix[0].length() - 1);
                int i = q.lastIndexOf('/');
                prefix[0] = i < 0 ? "" : q.substring(0, i + 1);
                refresh.run();
                return;
            }
            AEntry e = rows.get(up ? pos - 1 : pos);
            if (e.dir) {
                prefix[0] = e.name + "/";
                refresh.run();
            } else {
                openFromArchive(archive, e);
            }
        });

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(420)));
        dlg[0] = new AlertDialog.Builder(this)
                .setTitle(archive.getName())
                .setView(box)
                .setPositiveButton("Fechar", null)
                .create();
        refresh.run();
        dlg[0].show();
    }

    private void openFromArchive(final File archive, final AEntry e) {
        final String leaf = e.name.substring(e.name.lastIndexOf('/') + 1);
        final long limit = 50L << 20;
        if (prefs.getBoolean("openDirect", true) && e.size <= limit) {
            File dir = new File(getCacheDir(), "open");
            dir.mkdirs();
            final File out = new File(dir, leaf.isEmpty() ? "arquivo" : leaf);
            runJob("Abrindo " + leaf, p -> {
                extractEntry(archive, e.raw, out, p);
                return null;
            }, () -> openWith(out));
        } else {
            new AlertDialog.Builder(this)
                    .setTitle(leaf)
                    .setMessage("Extrair este arquivo (" + formatSize(e.size) + ") para a pasta atual?")
                    .setPositiveButton("Extrair", (d, w) -> {
                        String n = leaf.isEmpty() ? "arquivo" : leaf;
                        int dot = n.lastIndexOf('.');
                        final File out = dot > 0
                                ? uniqueFile(current, n.substring(0, dot), n.substring(dot))
                                : uniqueFile(current, n, "");
                        runJob("Extraindo " + leaf, p -> {
                            extractEntry(archive, e.raw, out, p);
                            return "Extraído: " + out.getName();
                        });
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        }
    }

    private void copyOut(InputStream in, File out, Progress p, String label, long total) throws IOException {
        try (OutputStream os = new FileOutputStream(out)) {
            byte[] buf = new byte[64 * 1024];
            long done = 0;
            int n;
            while ((n = in.read(buf)) != -1) {
                os.write(buf, 0, n);
                done += n;
                p.update(label, done, total);
                if (p.cancelled.get()) break;
            }
        }
        if (p.cancelled.get()) out.delete();
    }

    private void extractEntry(File archive, String raw, File out, Progress p) throws IOException {
        out.delete();
        if (tarCodec(archive) >= 0) {
            long total = archive.length();
            TarIO.Counting cin = new TarIO.Counting(
                    new BufferedInputStream(new FileInputStream(archive), 64 * 1024));
            InputStream src = null;
            try {
                src = wrapIn(cin, tarCodec(archive));
                final TarIO.Reader tar = new TarIO.Reader(src);
                TarIO.Entry e;
                while ((e = tar.next()) != null) {
                    if (p.cancelled.get()) return;
                    if (e.isRegular() && e.name.equals(raw)) {
                        InputStream entryIn = new InputStream() {
                            @Override
                            public int read() throws IOException {
                                byte[] one = new byte[1];
                                int n = tar.read(one, 0, 1);
                                return n < 0 ? -1 : one[0] & 0xFF;
                            }

                            @Override
                            public int read(byte[] b, int off, int len) throws IOException {
                                return tar.read(b, off, len);
                            }
                        };
                        copyOut(entryIn, out, p, e.name, e.size);
                        return;
                    }
                }
            } finally {
                showClose(src, cin);
            }
            throw new IOException("Entrada não encontrada no arquivo");
        } else if (isSevenZ(archive)) {
            SevenZFile sz = SevenZFile.builder().setFile(archive).get();
            try {
                SevenZArchiveEntry e;
                while ((e = sz.getNextEntry()) != null) {
                    if (p.cancelled.get()) return;
                    if (!e.isDirectory() && e.getName().equals(raw)) {
                        final SevenZFile fsz = sz;
                        InputStream entryIn = new InputStream() {
                            @Override
                            public int read() throws IOException {
                                byte[] one = new byte[1];
                                int n = fsz.read(one, 0, 1);
                                return n < 0 ? -1 : one[0] & 0xFF;
                            }

                            @Override
                            public int read(byte[] b, int off, int len) throws IOException {
                                return fsz.read(b, off, len);
                            }
                        };
                        copyOut(entryIn, out, p, e.getName(), Math.max(0, e.getSize()));
                        return;
                    }
                }
            } finally {
                sz.close();
            }
            throw new IOException("Entrada não encontrada no arquivo");
        } else if (singleCodec(archive) >= 0) {
            singleDecompress(archive, out, p, singleCodec(archive));
        } else {
            ZipFile zf = new ZipFile(archive, Prefs.zipCharset(this));
            try {
                ZipEntry ze = zf.getEntry(raw);
                if (ze == null) throw new IOException("Entrada não encontrada no arquivo");
                try (InputStream in = zf.getInputStream(ze)) {
                    copyOut(in, out, p, raw, Math.max(0, ze.getSize()));
                }
            } finally {
                zf.close();
            }
        }
    }

    // ---------------------------------------------------------------- vários núcleos, conflitos, pastas

    /** Quantidade de threads usada ao compactar (configuração "Número de núcleos"). */
    private int cores() {
        int n = Prefs.num(this, "cores", 0);
        int max = Runtime.getRuntime().availableProcessors();
        return n <= 0 ? max : Math.min(n, max * 2);
    }

    private static LZ4Compressor lz4Compressor(int level) {
        LZ4Factory f = LZ4Factory.fastestInstance();
        switch (level) {
            case 1:
                return f.fastCompressor();
            case 2:
                return f.highCompressor(3);
            case 3:
                return f.highCompressor(6);
            case 4:
                return f.highCompressor(9);
            default:
                return f.highCompressor(12);
        }
    }

    private File outDir() {
        if (prefs.getBoolean("useCustomDir", false)) {
            String c = prefs.getString("customDir", "");
            if (c != null && !c.trim().isEmpty()) {
                File d = new File(c.trim());
                if (d.isDirectory() || d.mkdirs()) return d;
            }
        }
        return current;
    }

    private void afterCompress(List<File> items) {
        if (prefs.getBoolean("deleteAfter", false)) confirmDelete(items);
    }

    /** 0 = substituir, 1 = ignorar, 2 = manter os dois. Chamado de dentro de uma operação. */
    private int conflict(final File out) {
        if (!out.exists()) return 0;
        if (!prefs.getBoolean("confirmOverwrite", true)) return 0;
        if (overwriteAll >= 0) return overwriteAll;
        final int[] res = {1};
        final boolean[] all = {false};
        final CountDownLatch latch = new CountDownLatch(1);
        runOnUiThread(() -> {
            final CheckBox cb = new CheckBox(this);
            cb.setText("Aplicar a todos");
            new AlertDialog.Builder(this)
                    .setTitle("O arquivo já existe")
                    .setMessage(out.getName())
                    .setView(cb)
                    .setCancelable(false)
                    .setPositiveButton("Substituir", (d, w) -> {
                        res[0] = 0;
                        all[0] = cb.isChecked();
                        latch.countDown();
                    })
                    .setNeutralButton("Manter os dois", (d, w) -> {
                        res[0] = 2;
                        all[0] = cb.isChecked();
                        latch.countDown();
                    })
                    .setNegativeButton("Ignorar", (d, w) -> {
                        res[0] = 1;
                        all[0] = cb.isChecked();
                        latch.countDown();
                    })
                    .show();
        });
        try {
            latch.await();
        } catch (InterruptedException e) {
            return 1;
        }
        if (all[0]) overwriteAll = res[0];
        return res[0];
    }

    private String zipAny(List<File> items, File out, Progress p, int level) throws IOException {
        int th = cores();
        return th >= 2 ? zipParallel(items, out, p, ZIP_LEVELS[level], th) : zipFiles(items, out, p, level);
    }

    private class CountIn extends FilterInputStream {
        private final String name;
        private final Progress p;
        private final AtomicLong done;
        private final long total;

        CountIn(InputStream in, String name, Progress p, AtomicLong done, long total) {
            super(in);
            this.name = name;
            this.p = p;
            this.done = done;
            this.total = total;
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n < 0 ? -1 : one[0] & 0xFF;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (p.cancelled.get()) throw new IOException("cancelado");
            int n = super.read(b, off, len);
            if (n > 0) p.update(name, done.addAndGet(n), total);
            return n;
        }
    }

    /** ZIP com várias threads (commons-compress ParallelScatterZipCreator). */
    private String zipParallel(List<File> items, File outFile, Progress p, int deflateLevel, int threads)
            throws IOException {
        long total = 0;
        for (File f : items) total += sizeOf(f);
        final AtomicLong done = new AtomicLong();
        final ExecutorService pool = Executors.newFixedThreadPool(threads);
        final File tmpDir = getCacheDir();
        ParallelScatterZipCreator creator = new ParallelScatterZipCreator(pool,
                () -> new FileBasedScatterGatherBackingStore(File.createTempFile("scatter", ".tmp", tmpDir)),
                deflateLevel);
        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(
                new BufferedOutputStream(new FileOutputStream(outFile), 64 * 1024));
        boolean ok = false;
        try {
            zos.setUseZip64(Zip64Mode.AsNeeded);
            for (File f : items) addZipEntries(creator, f, f.getName(), outFile, p, done, total);
            creator.writeTo(zos);
            zos.close();
            ok = !p.cancelled.get();
        } catch (ExecutionException | InterruptedException e) {
            if (!p.cancelled.get()) {
                Throwable c = e.getCause() != null ? e.getCause() : e;
                throw new IOException(String.valueOf(c));
            }
        } finally {
            if (!ok) {
                pool.shutdownNow();
                try {
                    zos.close();
                } catch (Exception ignored) {
                    // arquivo incompleto: será apagado
                }
                outFile.delete();
            }
        }
        return ok ? "Criado " + outFile.getName() + " (" + formatSize(outFile.length()) + "), "
                + threads + " threads" : null;
    }

    private void addZipEntries(ParallelScatterZipCreator c, final File f, final String name, File outFile,
                               final Progress p, final AtomicLong done, final long total) throws IOException {
        if (f.getAbsolutePath().equals(outFile.getAbsolutePath())) return;
        if (f.isDirectory()) {
            ZipArchiveEntry de = new ZipArchiveEntry(name + "/");
            de.setTime(f.lastModified());
            de.setMethod(ZipEntry.STORED);
            de.setSize(0);
            de.setCrc(0);
            c.addArchiveEntry(de, () -> new ByteArrayInputStream(new byte[0]));
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) addZipEntries(c, k, name + "/" + k.getName(), outFile, p, done, total);
            }
            return;
        }
        if (!f.isFile()) return;
        ZipArchiveEntry ze = new ZipArchiveEntry(name);
        ze.setTime(f.lastModified());
        ze.setMethod(ZipEntry.DEFLATED);
        ze.setSize(f.length());
        c.addArchiveEntry(ze, () -> {
            try {
                return new CountIn(new FileInputStream(f), name, p, done, total);
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        });
    }

    // ---------------------------------------------------------------- barra, locais, puxar para atualizar

    private TextView barTitle;
    private TextView barSub;
    private View infoPanel;
    private TextView infoFolder;
    private TextView infoStorage;
    private TextView infoShizuku;
    private ProgressBar infoBar;
    private long toolbarStamp = -1;
    private int infoToken;

    private void setupBar() {
        android.app.ActionBar ab = getActionBar();
        if (ab == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        barTitle = new TextView(this);
        barTitle.setTextAppearance(android.R.style.TextAppearance_Material_Widget_ActionBar_Title);
        barTitle.setSingleLine(true);
        barTitle.setEllipsize(TextUtils.TruncateAt.END);
        barSub = new TextView(this);
        barSub.setTextAppearance(android.R.style.TextAppearance_Material_Widget_ActionBar_Subtitle);
        barSub.setSingleLine(true);
        barSub.setEllipsize(TextUtils.TruncateAt.START);
        box.addView(barTitle);
        box.addView(barSub);
        box.setOnClickListener(v -> showPlacesPanel());
        ab.setDisplayShowTitleEnabled(false);
        ab.setDisplayHomeAsUpEnabled(true);
        ab.setDisplayShowCustomEnabled(true);
        ab.setCustomView(box, new android.app.ActionBar.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Continuação da barra: preserva a imagem no topo e a dissolve sobre o wallpaper. */
    private static class ToolbarFadeDrawable extends Drawable {
        private final Bitmap bitmap;
        private final Paint image = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint mask = new Paint(Paint.ANTI_ALIAS_FLAG);

        ToolbarFadeDrawable(Bitmap bitmap) { this.bitmap = bitmap; }

        @Override public void draw(Canvas canvas) {
            if (bitmap == null || bitmap.isRecycled()) return;
            Rect b = getBounds();
            int save = canvas.saveLayer(b.left, b.top, b.right, b.bottom, null);
            canvas.drawBitmap(bitmap, null, b, image);
            mask.setShader(new LinearGradient(0, b.top, 0, b.bottom,
                    0xFFFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            canvas.drawRect(b, mask);
            mask.setXfermode(null);
            mask.setShader(null);
            canvas.restoreToCount(save);
        }

        @Override public void setAlpha(int alpha) { image.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter filter) { image.setColorFilter(filter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    /** Cabeçalho de 68 dp atrás da barra: foto ou cor, com degradê que se mescla ao wallpaper. */
    private void applyHeader(boolean imageMode, Bitmap toolbarBitmap, int solid) {
        if (toolbarBg == null) return;
        toolbarBg.setVisibility(View.VISIBLE);
        toolbarBg.setBackground(imageMode && toolbarBitmap != null
                ? new ToolbarFadeDrawable(toolbarBitmap)
                : new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{solid, Color.TRANSPARENT}));
    }

    private void applyPathBar(boolean imageMode, Bitmap toolbarBitmap, int solid) {
        if (pathView == null) return;
        pathView.setVisibility(View.GONE); // o caminho já aparece no subtítulo do título
        pathView.setBackground(imageMode && toolbarBitmap != null
                ? new ToolbarFadeDrawable(toolbarBitmap)
                : new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{solid, Color.TRANSPARENT}));
        pathView.setElevation(0);
    }

    /** Cor sólida ou foto na barra de ferramentas. */
    private void applyToolbar() {
        android.app.ActionBar ab = getActionBar();
        if (ab == null) return;
        File f = Prefs.toolbarFile(this);
        boolean img = Prefs.num(this, "toolbarMode", 0) == 1 && f.exists();
        String hex = prefs.getString("toolbarHex", "");
        String col = hex != null && !hex.trim().isEmpty() ? hex.trim() : prefs.getString("toolbarColor", "#546E7A");
        long stamp = img ? f.lastModified() : col.hashCode() * 31L + 7;
        if (stamp == toolbarStamp && pathView != null && pathView.getBackground() != null) return;
        toolbarStamp = stamp;
        int solid;
        try { solid = Color.parseColor(col.startsWith("#") ? col : "#" + col); }
        catch (Exception e) { solid = 0xFF546E7A; }
        if (img) {
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) {
                ab.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                applyHeader(true, b, solid);
                applyPathBar(true, b, solid);
                return;
            }
        }
        ab.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        applyHeader(false, null, solid);
        applyPathBar(false, null, solid);
    }

    /** Botão no canto inferior esquerdo: sólido ou transparente com borda fina na cor do tema. */
    private void applyFabStyle() {
        fab.setVisibility(prefs.getBoolean("showFab", true) ? View.VISIBLE : View.GONE);
        FrameLayout.LayoutParams flp = (FrameLayout.LayoutParams) fab.getLayoutParams();
        int grav = Gravity.BOTTOM | (prefs.getBoolean("leftHanded", false) ? Gravity.START : Gravity.END);
        if (flp.gravity != grav) {
            flp.gravity = grav;
            fab.setLayoutParams(flp);
        }
        boolean outline = prefs.getBoolean("fabOutline", false);
        int line = isDark() ? 0xFFEEEEEE : 0xFF333333;
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        if (outline) {
            g.setColor(Color.TRANSPARENT);
            g.setStroke(Math.max(2, dp(1)), line);
            fab.setTextColor(line);
            fab.setElevation(0);
        } else {
            g.setColor(0xFF4A6572);
            fab.setTextColor(0xFFFFFFFF);
            fab.setElevation(dp(6));
        }
        fab.setBackground(g);
        fab.setAlpha(1f);
    }

    // ---- puxar para baixo no topo: atualiza e mostra o painel de armazenamento

    private boolean panelShown;

    private final View.OnTouchListener pullListener = new View.OnTouchListener() {
        private float startY = Float.NaN;

        @Override
        public boolean onTouch(View v, MotionEvent ev) {
            int action = ev.getAction();
            if (action == MotionEvent.ACTION_DOWN && v.getTag() instanceof Pane) activate((Pane) v.getTag());
            AbsListView lv = (AbsListView) v;
            boolean top = lv.getChildCount() == 0
                    || (lv.getFirstVisiblePosition() == 0 && lv.getChildAt(0).getTop() >= 0);
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    startY = top ? ev.getY() : Float.NaN;
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (!top) {
                        startY = Float.NaN;
                        hidePullPanel();
                    } else if (Float.isNaN(startY)) {
                        startY = ev.getY();
                    } else if (ev.getY() - startY > dp(110)) {
                        if (!panelShown) showPullPanel();
                    } else if (panelShown && ev.getY() - startY < dp(60)) {
                        hidePullPanel();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    if (panelShown) {
                        hidePullPanel();
                        reload();
                    }
                    startY = Float.NaN;
                    break;
                case MotionEvent.ACTION_CANCEL:
                    hidePullPanel();
                    startY = Float.NaN;
                    break;
                default:
                    break;
            }
            return false;
        }
    };

    private void hidePullPanel() {
        if (!panelShown) return;
        panelShown = false;
        infoToken++;
        infoPanel.setVisibility(View.GONE);
    }

    /** Aparece enquanto o dedo segura a aba puxada; some quando solta. */
    private void showPullPanel() {
        final File dir = current;
        if (dir == null) return;
        panelShown = true;
        final int token = ++infoToken;
        infoFolder.setText("Esta pasta: calculando…");
        try {
            StatFs sf = new StatFs(dir.getAbsolutePath());
            long total = sf.getTotalBytes();
            long free = sf.getAvailableBytes();
            long used = total - free;
            infoStorage.setText("Armazenamento: " + formatSize(used) + " usados de " + formatSize(total)
                    + " (" + formatSize(free) + " livres)");
            infoBar.setProgress(total > 0 ? (int) (used * 100 / total) : 0);
        } catch (Exception e) {
            infoStorage.setText("Armazenamento: indisponível");
            infoBar.setProgress(0);
        }
        infoShizuku.setText("Shizuku: " + shizukuStatus());
        infoPanel.setVisibility(View.VISIBLE);
        new Thread(() -> {
            final long sz = sizeOf(dir);
            runOnUiThread(() -> {
                if (token == infoToken) {
                    infoFolder.setText("Esta pasta (" + dir.getName() + "): " + formatSize(sz));
                }
            });
        }).start();
    }

    private String shizukuStatus() {
        boolean installed = false;
        try {
            getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            installed = true;
        } catch (Exception ignored) {
            // não instalado
        }
        try {
            Class<?> c = Class.forName("rikka.shizuku.Shizuku");
            boolean alive = (Boolean) c.getMethod("pingBinder").invoke(null);
            if (alive) return "ativo";
            return installed ? "inativo (instalado, mas o serviço não está rodando)" : "inativo (app não instalado)";
        } catch (ClassNotFoundException e) {
            return installed ? "app instalado, mas a biblioteca não foi incluída (não dá pra saber se está ativo)"
                    : "app não instalado";
        } catch (Throwable t) {
            return "indeterminado";
        }
    }

    /** O provider do Shizuku vem desligado no manifest; só liga se a biblioteca estiver no app. */
    private void enableShizukuProvider() {
        try {
            Class.forName("rikka.shizuku.ShizukuProvider");
            ComponentName cn = new ComponentName(this, "rikka.shizuku.ShizukuProvider");
            PackageManager pm = getPackageManager();
            if (pm.getComponentEnabledSetting(cn) != PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                        PackageManager.DONT_KILL_APP);
            }
        } catch (Throwable ignored) {
            // sem a biblioteca do Shizuku
        }
    }

    // ---- locais (pastas principais e favoritas)

    private static final String PLACES_KEY = "places";

    private List<String[]> loadPlaces() {
        List<String[]> out = new ArrayList<>();
        String raw = prefs.getString(PLACES_KEY, null);
        if (raw == null) {
            String ext = root.getAbsolutePath();
            out.add(new String[]{"ROOT", "/"});
            out.add(new String[]{"Memória interna", ext});
            out.add(new String[]{"Downloads", ext + "/Download"});
            out.add(new String[]{"Documentos", ext + "/Documents"});
            out.add(new String[]{"Músicas", ext + "/Music"});
            return out;
        }
        for (String line : raw.split("\n")) {
            int t = line.indexOf('\t');
            if (t > 0) out.add(new String[]{line.substring(0, t), line.substring(t + 1)});
        }
        return out;
    }

    private void savePlaces(List<String[]> list) {
        StringBuilder sb = new StringBuilder();
        for (String[] p : list) {
            sb.append(p[0].replace('\t', ' ').replace('\n', ' ')).append('\t').append(p[1]).append('\n');
        }
        prefs.edit().putString(PLACES_KEY, sb.toString()).apply();
    }

    private boolean isPlace(String path) {
        for (String[] p : loadPlaces()) {
            if (p[1].equals(path)) return true;
        }
        return false;
    }

    private void addPlace(String name, String path) {
        List<String[]> list = loadPlaces();
        for (String[] p : list) {
            if (p[1].equals(path)) return;
        }
        list.add(new String[]{name.isEmpty() ? "ROOT" : name, path});
        savePlaces(list);
    }

    private void togglePlace(File f) {
        List<String[]> list = loadPlaces();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i)[1].equals(f.getAbsolutePath())) {
                list.remove(i);
                savePlaces(list);
                toast("Removida dos favoritos");
                return;
            }
        }
        addPlace(f.getName(), f.getAbsolutePath());
        toast("Pasta adicionada aos favoritos");
    }

    private void goTo(File dir) {
        if (dir.isDirectory()) openDir(dir);
        else toast("Pasta não encontrada: " + dir.getAbsolutePath());
    }

    private AlertDialog bottomDialog(View content) {
        AlertDialog d = new AlertDialog.Builder(this).setView(content).create();
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(isDark() ? 0xFF1E1F24 : 0xFFFAFAFA);
        float r = dp(18);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(bg);
            w.setGravity(Gravity.BOTTOM);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (!prefs.getBoolean("animations", true)) w.setWindowAnimations(0);
        }
        return d;
    }

    private View placeRow(String icon, String title, String caption, int indentDp,
                          View.OnClickListener click, View.OnLongClickListener lc) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(20 + indentDp), dp(10), dp(20), dp(10));
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true);
        row.setBackgroundResource(tv.resourceId);
        TextView ic = new TextView(this);
        ic.setText(icon);
        ic.setTextSize(18);
        ic.setGravity(Gravity.CENTER);
        row.addView(ic, new LinearLayout.LayoutParams(dp(36), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setTextAppearance(android.R.style.TextAppearance_Material_Subhead);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setText(title);
        col.addView(t);
        if (caption != null) {
            TextView c = new TextView(this);
            c.setTextAppearance(android.R.style.TextAppearance_Material_Caption);
            c.setSingleLine(true);
            c.setEllipsize(TextUtils.TruncateAt.START);
            c.setText(caption);
            col.addView(c);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.setOnClickListener(click);
        if (lc != null) row.setOnLongClickListener(lc);
        return row;
    }

    private TextView placeSection(String text) {
        TextView t = new TextView(this);
        t.setTextAppearance(android.R.style.TextAppearance_Material_Caption);
        t.setText(text.toUpperCase(Locale.ROOT));
        t.setPadding(dp(20), dp(14), dp(20), dp(2));
        return t;
    }

    /** Toque na barra do topo: caminho detalhado + pastas principais (editáveis). */
    private void showPlacesPanel() {
        if (current == null) return;
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        box.addView(placeSection("Caminho atual"));
        List<File> chain = new ArrayList<>();
        for (File f = current; f != null; f = f.getParentFile()) chain.add(0, f);
        int depth = 0;
        for (final File a : chain) {
            String nm = a.getParentFile() == null ? "/  (ROOT)" : a.getName();
            box.addView(placeRow("▰", nm, null, Math.min(depth, 8) * 12, v -> {
                dlg[0].dismiss();
                goTo(a);
            }, null));
            depth++;
        }

        box.addView(placeSection("Pastas principais"));
        final List<String[]> places = loadPlaces();
        for (int i = 0; i < places.size(); i++) {
            final int idx = i;
            final String[] pl = places.get(i);
            box.addView(placeRow("\u2B50", pl[0], pl[1], 0, v -> {
                dlg[0].dismiss();
                goTo(new File(pl[1]));
            }, v -> {
                dlg[0].dismiss();
                editPlaceMenu(idx);
                return true;
            }));
        }
        box.addView(placeRow("\u2795", "Adicionar a pasta atual", current.getAbsolutePath(), 0, v -> {
            dlg[0].dismiss();
            addPlace(current.getName(), current.getAbsolutePath());
            toast("Pasta adicionada");
        }, null));
        box.addView(placeRow("\u270F", "Adicionar caminho…", null, 0, v -> {
            dlg[0].dismiss();
            promptAddPlace();
        }, null));
        box.addView(placeRow("\u21BA", "Restaurar a lista padrão", null, 0, v -> {
            dlg[0].dismiss();
            prefs.edit().remove(PLACES_KEY).apply();
            toast("Lista restaurada");
        }, null));
        TextView hint = new TextView(this);
        hint.setTextAppearance(android.R.style.TextAppearance_Material_Caption);
        hint.setText("Segure uma pasta da lista para renomear, mudar o caminho ou remover.");
        hint.setPadding(dp(20), dp(8), dp(20), dp(16));
        box.addView(hint);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        dlg[0] = bottomDialog(sv);
        dlg[0].show();
    }

    private void editPlaceMenu(final int idx) {
        final List<String[]> list = loadPlaces();
        if (idx >= list.size()) return;
        final String[] p = list.get(idx);
        new AlertDialog.Builder(this)
                .setTitle(p[0])
                .setItems(new String[]{"Renomear", "Alterar caminho", "Remover"}, (d, which) -> {
                    if (which == 0) {
                        promptText("Renomear", p[0], "OK", t -> {
                            String n = cleanName(t);
                            if (n.isEmpty()) return;
                            p[0] = n;
                            savePlaces(list);
                        });
                    } else if (which == 1) {
                        promptText("Caminho", p[1], "OK", t -> {
                            if (t.trim().isEmpty()) return;
                            p[1] = t.trim();
                            savePlaces(list);
                        });
                    } else {
                        list.remove(idx);
                        savePlaces(list);
                    }
                })
                .show();
    }

    private void promptAddPlace() {
        promptText("Nome da pasta favorita", "Nova pasta", "Próximo", name -> {
            final String n = cleanName(name);
            if (n.isEmpty()) return;
            promptText("Caminho da pasta", current != null ? current.getAbsolutePath() : "/", "Adicionar", path -> {
                if (path.trim().isEmpty()) return;
                addPlace(n, path.trim());
                toast("Pasta adicionada");
            });
        });
    }

    // ---------------------------------------------------------------- dois painéis

    private class Pane {
        File current;
        File upItem;
        final Set<File> selected = new LinkedHashSet<>();
        ListView list;
        GridView grid;
        TextView header;
        FileAdapter adapter;
    }

    private Pane pane1;
    private Pane pane2;
    private Pane active;
    private LinearLayout panes;
    private View paneBox1;
    private View paneBox2;
    private View paneDivider;
    private View toolbarBg;
    private static final int TOOLBAR_DP = 68;

    private boolean dualOn() {
        return prefs.getBoolean("dualPane", false);
    }

    private Pane otherPane() {
        return active == pane1 ? pane2 : pane1;
    }

    private void activate(Pane p) {
        if (p == null || p == active) return;
        if (actionMode != null) actionMode.finish();
        active = p;
        current = p.current;
        upItem = p.upItem;
        selected = p.selected;
        adapter = p.adapter;
        listView = p.list;
        gridView = p.grid;
        if (current != null) updateBarText(current);
        updatePaneHeaders();
    }

    private void updateBarText(File dir) {
        if (barTitle != null) {
            barTitle.setText(dir.equals(root) ? "Armazenamento"
                    : (dir.getParentFile() == null ? "ROOT" : dir.getName()));
            barSub.setText(dir.getAbsolutePath());
            if (pathView != null) {
                pathView.setText(dir.getAbsolutePath());
                pathView.setVisibility(View.GONE);
            }
        }
        updatePaneHeaders();
    }

    private void updatePaneHeaders() {
        if (pane1 == null || pane2 == null) return;
        for (Pane p : new Pane[]{pane1, pane2}) {
            File c = p == active ? current : p.current;
            p.header.setText(c == null ? "…" : c.getAbsolutePath());
            p.header.setVisibility(View.GONE);
        }
    }

    private void reloadAll() {
        if (!dualOn()) {
            if (current != null) loadDir(current);
            return;
        }
        Pane keep = active;
        for (Pane p : new Pane[]{pane1, pane2}) {
            if (p.current == null) continue;
            activate(p);
            loadDir(p.current);
        }
        activate(keep);
    }

    /** Liga/desliga o segundo painel (configuração) e ajusta a posição (em pé: um sobre o outro). */
    // ---------------------------------------------------------------- modo livro (páginas deslizantes)

    private int bookPage;
    private GestureDetector bookDetector;
    private TextView pageIndicator;

    private boolean isBook() {
        return dualOn() && Prefs.num(this, "dualLayout", 0) == 3;
    }

    private float bookDownX;
    private float bookDownY;
    private boolean bookSwiping;

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (bookDetector != null && isBook()) {
            bookDetector.onTouchEvent(ev);
            int action = ev.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                bookDownX = ev.getX();
                bookDownY = ev.getY();
                bookSwiping = false;
            } else if (action == MotionEvent.ACTION_MOVE && !bookSwiping) {
                float dx = Math.abs(ev.getX() - bookDownX);
                float dy = Math.abs(ev.getY() - bookDownY);
                if (dx > dp(12) && dx > dy * 1.5f) {
                    // arrasto horizontal: cancela o toque que a lista já recebeu, para não virar clique
                    bookSwiping = true;
                    MotionEvent cancel = MotionEvent.obtain(ev);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);
                    cancel.recycle();
                }
            }
            if (bookSwiping) {
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) bookSwiping = false;
                return true; // não repassa o resto do gesto para a lista
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    /** Vira a página: 1 = próxima (entra pela direita), -1 = anterior. */
    private void turnPage(int dir) {
        int target = bookPage + dir;
        if (target < 0 || target > 1) return;
        final View out = bookPage == 0 ? paneBox1 : paneBox2;
        final View in = target == 0 ? paneBox1 : paneBox2;
        int w = panes.getWidth();
        bookPage = target;
        in.setVisibility(View.VISIBLE);
        in.setTranslationX(dir * w);
        in.animate().translationX(0).setDuration(220).start();
        out.animate().translationX(-dir * w).setDuration(220).withEndAction(() -> {
            out.setVisibility(View.GONE);
            out.setTranslationX(0);
        }).start();
        activate(target == 0 ? pane1 : pane2);
        updateBookIndicator();
    }

    private void applyBookLayout(boolean dual) {
        if (!dual || Prefs.num(this, "dualLayout", 0) != 3) {
            pageIndicator.setVisibility(View.GONE);
            paneBox1.setTranslationX(0);
            paneBox2.setTranslationX(0);
            return;
        }
        panes.setOrientation(LinearLayout.VERTICAL);
        paneDivider.setVisibility(View.GONE);
        paneBox1.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        paneBox2.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        paneBox1.setVisibility(bookPage == 0 ? View.VISIBLE : View.GONE);
        paneBox2.setVisibility(bookPage == 1 ? View.VISIBLE : View.GONE);
        paneBox1.setTranslationX(0);
        paneBox2.setTranslationX(0);
        pageIndicator.setVisibility(View.VISIBLE);
        updateBookIndicator();
    }

    private void updateBookIndicator() {
        if (pageIndicator == null) return;
        pageIndicator.setText(bookPage == 0 ? "\u25CF  \u25E6   pág. 1 de 2" : "\u25E6  \u25CF   pág. 2 de 2");
    }

    private void applyDual() {
        boolean dual = prefs.getBoolean("dualPane", false);
        int layoutMode = Prefs.num(this, "dualLayout", 0);
        boolean land = layoutMode == 2 || (layoutMode == 0
                && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE);
        panes.setOrientation(land ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        LinearLayout.LayoutParams a = land
                ? new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        LinearLayout.LayoutParams b = land
                ? new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        LinearLayout.LayoutParams d = land
                ? new LinearLayout.LayoutParams(dp(2), ViewGroup.LayoutParams.MATCH_PARENT)
                : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2));
        paneBox1.setLayoutParams(a);
        paneBox2.setLayoutParams(b);
        paneDivider.setLayoutParams(d);
        pane1.header.setVisibility(View.GONE);
        pane2.header.setVisibility(View.GONE);
        paneBox2.setVisibility(dual ? View.VISIBLE : View.GONE);
        paneDivider.setVisibility(View.GONE);
        if (dual && pane2.current == null && hasAccess()) {
            Pane keep = active;
            activate(pane2);
            File start = new File(root, "Download");
            openDir(start.isDirectory() ? start : root);
            activate(keep);
        }
        if (!dual && active == pane2) activate(pane1);
        applyBookLayout(dual);
        updatePaneHeaders();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (panes != null) applyDual();
    }

    private void sendToOther(final List<File> items, final boolean move) {
        Pane o = otherPane();
        if (o.current == null) {
            toast("Abra uma pasta no outro painel");
            return;
        }
        final File dest = o.current;
        for (File f : items) {
            if (f.isDirectory() && isInside(dest, f)) {
                toast("Não dá pra colocar uma pasta dentro dela mesma");
                return;
            }
        }
        finishMode();
        runJob(move ? "Movendo…" : "Copiando…", p -> pasteAll(items, dest, move, p), () -> reloadAll());
    }

    // ---------------------------------------------------------------- imagens de disco (ISO, BIN/CUE, CSO, ZSO)

    private static String discExt(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        String[] exts = {".iso", ".cso", ".zso", ".bin", ".cue", ".chd"};
        for (String e : exts) {
            if (n.endsWith(e)) return e.substring(1);
        }
        return null;
    }

    private DiscTools.Cb discCb(final Progress p, final String label) {
        return new DiscTools.Cb() {
            @Override
            public void update(long done, long total) {
                p.update(label, done, total);
            }

            @Override
            public boolean cancelled() {
                return p.cancelled.get();
            }
        };
    }

    private void showDiscDialog(final File f) {
        final String ext = discExt(f);
        if (ext == null) return;
        if (ext.equals("chd")) {
            toast("CHD ainda não é suportado (precisa da biblioteca nativa libchdr)");
            return;
        }
        final List<String> opts = new ArrayList<>();
        if (!ext.equals("iso")) opts.add("ISO");
        if (!ext.equals("cso")) opts.add("CSO");
        if (!ext.equals("zso")) opts.add("ZSO");
        if (!ext.equals("bin") && !ext.equals("cue")) opts.add("BIN/CUE");
        if (ext.equals("iso")) opts.add("Desfragmentar (reescrever contíguo)");
        new AlertDialog.Builder(this)
                .setTitle("Converter " + f.getName())
                .setItems(opts.toArray(new String[0]), (d, which) -> {
                    final String t = opts.get(which);
                    if (t.startsWith("Desfrag")) {
                        runJob("Desfragmentando…", p -> {
                            DiscTools.defragment(f, discCb(p, f.getName()));
                            return "Arquivo reescrito de forma contígua";
                        });
                    } else if (t.equals("CSO") || t.equals("ZSO")) {
                        final int[] choice = {t.equals("CSO") ? 3 : 2};
                        new AlertDialog.Builder(this)
                                .setTitle(t + " — nível de compressão")
                                .setSingleChoiceItems(LEVELS, choice[0], (dd, w) -> choice[0] = w)
                                .setPositiveButton("Converter", (dd, w) ->
                                        runJob("Convertendo…", p -> convertDisc(f, t, choice[0], p)))
                                .setNegativeButton("Cancelar", null)
                                .show();
                    } else {
                        runJob("Convertendo…", p -> convertDisc(f, t, 0, p));
                    }
                })
                .show();
    }

    private String convertDisc(File src, String target, int level, Progress p) throws IOException {
        File dir = outDir();
        String n = src.getName();
        int dot = n.lastIndexOf('.');
        String base = dot > 0 ? n.substring(0, dot) : n;
        DiscTools.Cb cb = discCb(p, n);
        DiscTools.Src in = DiscTools.open(src);
        File out = null;
        File cue = null;
        try {
            if (target.equals("ISO")) {
                out = uniqueFile(dir, base, ".iso");
                DiscTools.writeIso(in.in, in.size, out, cb);
            } else if (target.equals("CSO")) {
                out = uniqueFile(dir, base, ".cso");
                DiscTools.writeCiso(in.in, in.size, out, false, level == 0 ? 0 : ZIP_LEVELS[level], cb);
            } else if (target.equals("ZSO")) {
                out = uniqueFile(dir, base, ".zso");
                DiscTools.writeCiso(in.in, in.size, out, true, level, cb);
            } else {
                out = uniqueFile(dir, base, ".bin");
                String bn = out.getName();
                cue = new File(dir, bn.substring(0, bn.length() - 4) + ".cue");
                DiscTools.writeBinCue(in.in, in.size, out, cue, cb);
            }
            if (p.cancelled.get()) {
                out.delete();
                if (cue != null) cue.delete();
                return null;
            }
            return "Criado " + out.getName() + " (" + formatSize(out.length()) + ")";
        } catch (IOException e) {
            if (out != null) out.delete();
            if (cue != null) cue.delete();
            throw e;
        } finally {
            in.in.close();
        }
    }

    // ---------------------------------------------------------------- compactação pelos handlers (v0.12)

    private com.example.arcfm.archive.ProgressListener listenerFor(final Progress p) {
        return new com.example.arcfm.archive.ProgressListener() {
            @Override
            public void onProgress(String label, long done, long total) {
                p.update(label, done, total);
            }

            @Override
            public boolean isCancelled() {
                return p.cancelled.get();
            }
        };
    }

    private com.example.arcfm.archive.ArchiveOptions archiveOptions(int level) {
        com.example.arcfm.archive.ArchiveOptions o = new com.example.arcfm.archive.ArchiveOptions();
        o.level = level;
        o.threads = cores();
        o.method7z = prefs.getString("method7z", "LZMA2");
        o.compat = prefs.getBoolean("compatMode", false);
        o.zipCharset = Prefs.zipCharset(this);
        o.pipe = prefs.getBoolean("pipe", true);
        return o;
    }

    /**
     * Compacta pelo ArchiveManager: grava num temporário, testa e só então publica.
     * format usa a mesma ordem de FORMATS (zip, 7z, tar, tar.lz4, tar.gz, tar.xz, tar.bz2).
     */
    private String runArchive(List<File> items, File out, int format, int level, long volBytes, Progress p)
            throws IOException {
        com.example.arcfm.archive.ArchiveOptions o = archiveOptions(level);
        o.volumeBytes = volBytes;
        com.example.arcfm.archive.ArchiveManager m = new com.example.arcfm.archive.ArchiveManager(o);
        com.example.arcfm.archive.ArchiveHandler h = m.forFormat(format);
        long t0 = System.currentTimeMillis();
        long inBytes = com.example.arcfm.filesystem.FileScanner.sizeOf(items);
        String inNames = items.size() == 1 ? items.get(0).getName() : items.size() + " itens";
        try {
            List<File> made = m.compressSafely(h, items, out, listenerFor(p));
            if (p.cancelled.get()) return null;
            logArchive("compactar", format, level, inNames, out.getName(), inBytes,
                    made.isEmpty() ? 0 : sizeOfAll(made), t0, null, -1);
            if (made.size() == 1) {
                return "Criado " + made.get(0).getName() + " (" + formatSize(made.get(0).length()) + ")";
            }
            return "Criados " + made.size() + " volumes";
        } catch (IOException e) {
            logArchive("compactar", format, level, inNames, out.getName(), inBytes, 0, t0, e,
                    o.stats.partialOut);
            throw e;
        }
    }

    /** Pasta → ISO 9660: grava num temporário, confere a assinatura e só então publica. */
    private void makeIsoFromFolder(final File dir) {
        final File parent = dir.getParentFile();
        if (parent == null) {
            toast("Não é possível criar ISO da raiz");
            return;
        }
        final File out = uniqueFile(parent, dir.getName(), ".iso");
        runJob("Criando ISO…", p -> {
            long t0 = System.currentTimeMillis();
            File tmp = com.example.arcfm.filesystem.TemporaryFileManager.create(parent, ".iso");
            boolean ok = false;
            try {
                com.example.arcfm.archive.Iso9660Writer.write(dir, tmp, dir.getName(), listenerFor(p));
                if (p.cancelled.get()) return null;
                if (!com.example.arcfm.archive.Iso9660Writer.isIso(tmp)) {
                    throw new IOException("A imagem gerada não tem a assinatura ISO 9660");
                }
                com.example.arcfm.filesystem.TemporaryFileManager.publish(tmp, out);
                ok = true;
                logArchive("criar ISO", 0, 0, dir.getName(), out.getName(),
                        com.example.arcfm.filesystem.FileScanner.sizeOf(dir), out.length(), t0, null, -1);
                return "ISO criada: " + out.getName() + " (" + formatSize(out.length()) + ")";
            } catch (IOException e) {
                logArchive("criar ISO", 0, 0, dir.getName(), out.getName(),
                        com.example.arcfm.filesystem.FileScanner.sizeOf(dir), 0, t0, e, tmp.exists() ? tmp.length() : 0);
                throw e;
            } finally {
                if (!ok) tmp.delete();
            }
        });
    }

    private static long sizeOfAll(List<File> fs) {
        long s = 0;
        for (File f : fs) s += f.length();
        return s;
    }

    private void logArchive(String op, int format, int level, String input, String output, long inBytes,
                            long outBytes, long t0, Throwable err, long partial) {
        com.example.arcfm.diagnostics.DiagnosticLog.Record r = new com.example.arcfm.diagnostics.DiagnosticLog.Record();
        r.id = t0;
        r.format = op.contains("ISO") ? "iso" : FORMATS[Math.max(0, Math.min(format, FORMATS.length - 1))];
        r.algorithm = op;
        r.level = LEVELS[Math.max(0, Math.min(level, LEVELS.length - 1))];
        r.input = input;
        r.output = output;
        r.inputBytes = inBytes;
        r.outputBytes = outBytes;
        r.partialOutputBytes = partial;
        r.durationMs = System.currentTimeMillis() - t0;
        r.result = err == null ? "ok" : "erro";
        r.stage = op;
        r.error = err;
        com.example.arcfm.diagnostics.DiagnosticLog.log(r);
    }

    // ---------------------------------------------------------------- utilidades

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private static boolean isZip(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        for (String e : ZIP_EXT) {
            if (n.endsWith(e)) return true;
        }
        return false;
    }

    /** -1 = não é TAR; senão o codec do TAR (C_NONE ou C_LZ4). */
    private static int tarCodec(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (n.endsWith(".tar.lz4") || n.endsWith(".tlz4")) return C_LZ4;
        if (n.endsWith(".tar.zst") || n.endsWith(".tzst")) return com.example.arcfm.archive.Codecs.ZST;
        if (n.endsWith(".tar.gz") || n.endsWith(".tgz")) return C_GZ;
        if (n.endsWith(".tar.xz") || n.endsWith(".txz")) return C_XZ;
        if (n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".tbz")) return C_BZ2;
        if (n.endsWith(".tar")) return C_NONE;
        return -1;
    }

    /** .lz4 de um arquivo só (não TAR); -1 se não for. */
    private static int singleCodec(File f) {
        if (tarCodec(f) >= 0) return -1;
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (n.endsWith(".lz4")) return C_LZ4;
        if (n.endsWith(".zst")) return com.example.arcfm.archive.Codecs.ZST;
        if (n.endsWith(".gz")) return C_GZ;
        if (n.endsWith(".xz")) return C_XZ;
        if (n.endsWith(".bz2")) return C_BZ2;
        return -1;
    }

    private static boolean isSevenZ(File f) {
        return f.getName().toLowerCase(Locale.ROOT).endsWith(".7z");
    }

    private static String archiveBase(File f) {
        String n = f.getName();
        String l = n.toLowerCase(Locale.ROOT);
        String[] suffixes = {".tar.lz4", ".tar.gz", ".tar.xz", ".tar.bz2", ".tlz4", ".tgz", ".txz", ".tbz2", ".tbz"};
        for (String sfx : suffixes) {
            if (l.endsWith(sfx)) return n.substring(0, n.length() - sfx.length());
        }
        return stripExt(n);
    }

    private static String stripExt(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static String baseName(File f) {
        return f.isDirectory() ? f.getName() : stripExt(f.getName());
    }

    private static String cleanName(String s) {
        String n = s.trim().replace('/', '_');
        if (n.equals(".") || n.equals("..")) return "";
        return n;
    }

    private static File uniqueFile(File dir, String base, String ext) {
        File f = new File(dir, base + ext);
        for (int i = 2; f.exists(); i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
        }
        return f;
    }

    private static String formatSize(long bytes) {
        if (bytes < 1024) return bytes + "B";
        double v = bytes / 1024.0;
        String[] units = {"KB", "MB", "GB", "TB"};
        int i = 0;
        while (v >= 1024 && i < units.length - 1) {
            v /= 1024;
            i++;
        }
        return String.format(Locale.US, "%.2f%s", v, units[i]);
    }

    private static boolean isImage(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg")
                || n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".bmp");
    }

    private static boolean hasExt(String n, String... exts) {
        for (String e : exts) {
            if (n.endsWith(e)) return true;
        }
        return false;
    }

    private static final int[] FOLDER_COLORS = {
            0xFFF4B740, 0xFF4DA3FF, 0xFF7C6FF2, 0xFF36B37E,
            0xFFE85D75, 0xFF00A6A6, 0xFFB86BFF, 0xFF8D6E63
    };

    private int universalIconColor() {
        String raw = prefs.getString("iconColor", "#546E7A");
        try { return Color.parseColor(raw); } catch (Exception ignored) { return 0xFF546E7A; }
    }

    private int folderColor(File f) {
        if (f == null || !f.isDirectory()) return universalIconColor();
        String raw = prefs.getString("folderColor:" + f.getAbsolutePath(), null);
        if (raw != null) {
            try { return Color.parseColor(raw); } catch (Exception ignored) { }
        }
        return universalIconColor();
    }

    private void showFolderAppearanceDialog(final File folder) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(4));
        TextView hint = new TextView(this);
        hint.setText("Escolha uma cor para reconhecer esta pasta rapidamente.");
        hint.setPadding(0, 0, 0, dp(12));
        box.addView(hint);
        LinearLayout palette = new LinearLayout(this);
        palette.setGravity(Gravity.CENTER);
        for (final int color : FOLDER_COLORS) {
            TextView swatch = new TextView(this);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(color);
            swatch.setBackground(bg);
            swatch.setContentDescription("Cor da pasta");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(38), dp(38));
            lp.setMargins(dp(5), 0, dp(5), 0);
            palette.addView(swatch, lp);
            swatch.setOnClickListener(v -> {
                prefs.edit().putString("folderColor:" + folder.getAbsolutePath(), String.format(Locale.US, "#%08X", color)).apply();
                reloadAll();
                toast("Cor da pasta atualizada");
            });
        }
        box.addView(palette);
        Button custom = new Button(this);
        custom.setText("Usar cor personalizada (HEX)");
        custom.setOnClickListener(v -> promptText("Cor personalizada", "#F4B740", "Aplicar", value -> {
            String hex = value.trim();
            if (!hex.startsWith("#")) hex = "#" + hex;
            try {
                Color.parseColor(hex);
                prefs.edit().putString("folderColor:" + folder.getAbsolutePath(), hex).apply();
                reloadAll();
                toast("Cor da pasta atualizada");
            } catch (Exception e) { toast("Cor inválida. Use, por exemplo, #4DA3FF"); }
        }));
        box.addView(custom);
        Button reset = new Button(this);
        reset.setText("Restaurar cor padrão");
        reset.setOnClickListener(v -> {
            prefs.edit().remove("folderColor:" + folder.getAbsolutePath()).apply();
            reloadAll();
            toast("Cor padrão restaurada");
        });
        box.addView(reset);
        new AlertDialog.Builder(this).setTitle("Aparência da pasta").setView(box).show();
    }

    private static String iconFor(File f) {
        if (f.isDirectory()) return "▰";
        if (isArchiveFile(f)) return "▣";
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (isImage(f)) return "▧";
        if (hasExt(n, ".mp3", ".ogg", ".flac", ".wav", ".m4a", ".opus", ".aac")) return "♪";
        if (hasExt(n, ".mp4", ".mkv", ".avi", ".webm", ".3gp", ".mov")) return "▶";
        if (hasExt(n, ".txt", ".md", ".log", ".json", ".xml", ".html", ".css", ".js", ".java", ".kt",
                ".ini", ".cfg", ".csv", ".sh")) {
            return "≡";
        }
        if (n.endsWith(".pdf")) return "▤";
        return "□";
    }

    private int thumbKind(File f) {
        if (!prefs.getBoolean("thumbs", true)) return 0;
        if (isImage(f)) return 1;
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (n.endsWith(".pdf")) return prefs.getBoolean("thumbsPdf", false) ? 2 : 0;
        if (hasExt(n, ".mp4", ".mkv", ".avi", ".webm", ".3gp", ".mov")) {
            return prefs.getBoolean("thumbsVideo", false) ? 3 : 0;
        }
        if (hasExt(n, ".mp3", ".flac", ".m4a", ".ogg", ".opus", ".aac", ".wav")) {
            return prefs.getBoolean("thumbsAlbum", true) ? 4 : 0;
        }
        if (n.endsWith(".apk")) return prefs.getBoolean("thumbsApk", true) ? 5 : 0;
        return 0;
    }

    private static Bitmap scaleTo(Bitmap b, int max) {
        int w = b.getWidth();
        int h = b.getHeight();
        if (Math.max(w, h) <= max) return b;
        float k = max / (float) Math.max(w, h);
        return Bitmap.createScaledBitmap(b, Math.max(1, (int) (w * k)), Math.max(1, (int) (h * k)), true);
    }

    private Bitmap decodeThumb(File f, int kind, String key) throws Exception {
        String path = f.getAbsolutePath();
        if (kind == 1) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            if (o.outWidth > 0) dimCache.put(key, o.outWidth + "x" + o.outHeight);
            int sample = 1;
            while (Math.min(o.outWidth, o.outHeight) / (sample * 2) >= 160) sample *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            return BitmapFactory.decodeFile(path, o);
        }
        if (kind == 2) {
            try (ParcelFileDescriptor fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer r = new PdfRenderer(fd)) {
                if (r.getPageCount() == 0) return null;
                PdfRenderer.Page pg = r.openPage(0);
                try {
                    int w = 200;
                    int h = Math.max(1, 200 * pg.getHeight() / Math.max(1, pg.getWidth()));
                    Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    b.eraseColor(Color.WHITE);
                    pg.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    return b;
                } finally {
                    pg.close();
                }
            }
        }
        if (kind == 3 || kind == 4) {
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            try {
                mmr.setDataSource(path);
                if (kind == 3) {
                    Bitmap b = mmr.getFrameAtTime();
                    return b == null ? null : scaleTo(b, 240);
                }
                byte[] pic = mmr.getEmbeddedPicture();
                if (pic == null) return null;
                Bitmap b = BitmapFactory.decodeByteArray(pic, 0, pic.length);
                return b == null ? null : scaleTo(b, 240);
            } finally {
                mmr.release();
            }
        }
        if (kind == 5) {
            PackageInfo pi = getPackageManager().getPackageArchiveInfo(path, 0);
            if (pi == null || pi.applicationInfo == null) return null;
            pi.applicationInfo.sourceDir = path;
            pi.applicationInfo.publicSourceDir = path;
            Drawable d = pi.applicationInfo.loadIcon(getPackageManager());
            if (d instanceof BitmapDrawable && ((BitmapDrawable) d).getBitmap() != null) {
                return scaleTo(((BitmapDrawable) d).getBitmap(), 192);
            }
            Bitmap b = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            d.setBounds(0, 0, 96, 96);
            d.draw(c);
            return b;
        }
        return null;
    }

    private void loadThumb(final File f, final int kind) {
        final String key = f.getAbsolutePath() + "|" + f.lastModified();
        if (!thumbLoading.add(key)) return;
        thumbPool.execute(() -> {
            try {
                Bitmap b = decodeThumb(f, kind, key);
                if (b != null) thumbCache.put(key, b);
            } catch (Throwable ignored) {
                // sem miniatura
            }
            runOnUiThread(() -> {
                if (!isFinishing() && adapter != null) adapter.notifyDataSetChanged();
            });
        });
    }

    /** Ícones desenhados pelo app, sem emojis e consistentes em diferentes fontes do Android. */
    private static class FolderIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private String kind = "file";
        private int color = 0xFFF4B740;
        private String label = "";
        FolderIconView(android.content.Context c) { super(c); }
        void setIconScale(float s) { invalidate(); }
        void setUp() { kind = "up"; label = ""; invalidate(); }
        void setFile(File f, int iconColor) {
            if (f.isDirectory()) { kind = "folder"; label = ""; }
            else if (isArchiveFile(f)) { kind = "archive"; label = "ZIP"; }
            else if (isImage(f)) { kind = "image"; label = "IMG"; }
            else if (hasExt(f.getName().toLowerCase(Locale.ROOT), ".mp3", ".ogg", ".flac", ".wav", ".m4a", ".opus", ".aac")) { kind = "music"; label = "♪"; }
            else if (hasExt(f.getName().toLowerCase(Locale.ROOT), ".mp4", ".mkv", ".avi", ".webm", ".3gp", ".mov")) { kind = "video"; label = "▶"; }
            else if (f.getName().toLowerCase(Locale.ROOT).endsWith(".pdf")) { kind = "pdf"; label = "PDF"; }
            else { kind = "file"; label = extLabel(f.getName()); }
            color = iconColor;
            invalidate();
        }
        private static String extLabel(String name) {
            int dot = name.lastIndexOf('.');
            if (dot < 0 || dot == name.length() - 1) return "";
            String e = name.substring(dot + 1).toUpperCase(Locale.ROOT);
            return e.length() > 4 ? e.substring(0, 4) : e;
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight(), pad = Math.max(2, w * .12f);
            paint.setStyle(Paint.Style.FILL); paint.setColor(color);
            if (kind.equals("up")) {
                paint.setStrokeWidth(Math.max(3, w * .10f)); paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(w*.5f,h*.78f,w*.5f,h*.25f,paint); path.reset(); path.moveTo(w*.27f,h*.45f); path.lineTo(w*.5f,h*.22f); path.lineTo(w*.73f,h*.45f); c.drawPath(path,paint); return;
            }
            if (kind.equals("folder")) {
                c.drawRoundRect(new RectF(pad*1.3f,h*.20f,w*.52f,h*.42f),w*.08f,w*.08f,paint);
                c.drawRoundRect(new RectF(pad,h*.32f,w-pad,h*.82f),w*.09f,w*.09f,paint); paint.setColor(0x22FFFFFF);
                c.drawRoundRect(new RectF(pad,h*.35f,w-pad,h*.48f),w*.08f,w*.08f,paint); return;
            }
            paint.setColor(0xFFE9EDF2); c.drawRoundRect(new RectF(pad,h*.12f,w-pad,h*.88f),w*.08f,w*.08f,paint);
            paint.setColor(color); c.drawRoundRect(new RectF(pad,h*.12f,w*.36f,h*.24f),w*.05f,w*.05f,paint);
            paint.setColor(0xFFB7C0CB); paint.setStrokeWidth(Math.max(1,w*.035f));
            for (int i=0;i<2;i++) c.drawLine(w*.30f,h*(.58f+i*.12f),w*.70f,h*(.58f+i*.12f),paint);
            if (!label.isEmpty()) { paint.setColor(color); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(Math.max(7,w*.18f)); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); c.drawText(label,w*.5f,h*.47f,paint); }
        }
    }

    private static class Holder {
        LinearLayout root;
        FrameLayout iconBox;
        FolderIconView icon;
        ImageView thumb;
        LinearLayout textBox;
        TextView name;
        LinearLayout detail;
        TextView left;
        TextView right;
    }

    private class FileAdapter extends ArrayAdapter<File> {
        private final SimpleDateFormat dfBoth = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        private final SimpleDateFormat dfDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        private final SimpleDateFormat dfTime = new SimpleDateFormat("HH:mm", Locale.getDefault());
        private final Map<String, Integer> counts = new HashMap<>();

        private final Pane pane;

        FileAdapter(Pane pane) {
            super(MainActivity.this, 0);
            this.pane = pane;
        }

        void resetCounts() {
            counts.clear();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            if (convertView == null) {
                h = new Holder();
                h.root = new LinearLayout(MainActivity.this);
                h.iconBox = new FrameLayout(MainActivity.this);
                h.icon = new FolderIconView(MainActivity.this);
                h.thumb = new ImageView(MainActivity.this);
                h.thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                h.iconBox.addView(h.icon, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                h.iconBox.addView(h.thumb, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                h.textBox = new LinearLayout(MainActivity.this);
                h.textBox.setOrientation(LinearLayout.VERTICAL);
                h.name = new TextView(MainActivity.this);
                h.name.setTextAppearance(android.R.style.TextAppearance_Material_Subhead);
                h.name.setEllipsize(TextUtils.TruncateAt.END);
                h.detail = new LinearLayout(MainActivity.this);
                h.detail.setOrientation(LinearLayout.HORIZONTAL);
                h.left = new TextView(MainActivity.this);
                h.left.setTextAppearance(android.R.style.TextAppearance_Material_Caption);
                h.right = new TextView(MainActivity.this);
                h.right.setTextAppearance(android.R.style.TextAppearance_Material_Caption);
                h.detail.addView(h.left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                h.detail.addView(h.right, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                h.textBox.addView(h.name);
                h.textBox.addView(h.detail);
                h.root.addView(h.iconBox);
                h.root.addView(h.textBox);
                h.root.setTag(h);
                convertView = h.root;
            } else {
                h = (Holder) convertView.getTag();
            }

            File f = getItem(position);
            if (f == null) return convertView;
            int mode = viewMode();
            float fs = Prefs.num(MainActivity.this, "fontScale", 100) / 100f;
            float is = Prefs.num(MainActivity.this, "itemScale", 100) / 100f;
            h.left.setTextSize(12 * fs);
            h.right.setTextSize(12 * fs);
            boolean dir = f.isDirectory();
            String path = f.getAbsolutePath();
            String key = path + "|" + f.lastModified();

            h.name.setText(f.getName());
            if (mode == 2) {
                h.root.setOrientation(LinearLayout.VERTICAL);
                h.root.setGravity(Gravity.CENTER_HORIZONTAL);
                h.root.setPadding(dp(4), dp(10), dp(4), dp(10));
                h.iconBox.setLayoutParams(new LinearLayout.LayoutParams((int) (dp(64) * is), (int) (dp(64) * is)));
                h.icon.setIconScale(is);
                h.textBox.setLayoutParams(new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                h.name.setSingleLine(false);
                h.name.setMaxLines(2);
                h.name.setGravity(Gravity.CENTER_HORIZONTAL);
                h.name.setTextSize(13 * fs);
                h.detail.setVisibility(View.GONE);
            } else {
                boolean compact = mode == 1;
                int box = (int) ((compact ? dp(32) : dp(48)) * is);
                h.root.setOrientation(LinearLayout.HORIZONTAL);
                h.root.setGravity(Gravity.CENTER_VERTICAL);
                h.root.setPadding(dp(10), compact ? dp(6) : dp(8), dp(10), compact ? dp(6) : dp(8));
                h.iconBox.setLayoutParams(new LinearLayout.LayoutParams(box, box));
                h.icon.setIconScale(is);
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                tl.leftMargin = dp(12);
                h.textBox.setLayoutParams(tl);
                h.name.setSingleLine(true);
                h.name.setGravity(Gravity.START);
                h.name.setTextSize((compact ? 15 : 17) * fs);
                h.detail.setVisibility(compact ? View.GONE : View.VISIBLE);
            }

            int kind = dir ? 0 : thumbKind(f);
            Bitmap tb = kind != 0 ? thumbCache.get(key) : null;
            if (kind != 0 && tb == null) loadThumb(f, kind);
            h.thumb.setScaleType(prefs.getBoolean("thumbSquare", false)
                    ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
            if (tb != null) {
                h.thumb.setImageBitmap(tb);
                h.thumb.setVisibility(View.VISIBLE);
                h.icon.setVisibility(View.GONE);
            } else {
                h.thumb.setImageDrawable(null);
                h.thumb.setVisibility(View.GONE);
                h.icon.setVisibility(View.VISIBLE);
                h.icon.setFile(f, dir ? folderColor(f) : 0);
            }

            if (mode == 0) {
                boolean sz = prefs.getBoolean("showSize", true);
                boolean sd = prefs.getBoolean("showDate", true);
                boolean st = prefs.getBoolean("showTime", true);
                String left = "";
                if (sz) {
                    if (dir) {
                        Integer c = counts.get(path);
                        if (c == null) {
                            String[] l = f.list();
                            c = l == null ? 0 : l.length;
                            counts.put(path, c);
                        }
                        left = c + (c == 1 ? " item" : " itens");
                    } else {
                        String dim = dimCache.get(key);
                        left = formatSize(f.length()) + (dim != null ? "  \u2022  " + dim : "");
                    }
                }
                h.left.setText(left);
                Date dt = new Date(f.lastModified());
                h.right.setText(sd && st ? dfBoth.format(dt) : (sd ? dfDate.format(dt) : (st ? dfTime.format(dt) : "")));
            }
            if (f == pane.upItem) {
                h.name.setText("..");
                h.icon.setUp();
                h.icon.setVisibility(View.VISIBLE);
                h.thumb.setVisibility(View.GONE);
                h.left.setText("");
                h.right.setText("");
            }
            h.iconBox.setOnClickListener(v -> {
                activate(pane);
                if (f == pane.upItem) {
                    if (current != null && current.getParentFile() != null) openDir(current.getParentFile());
                    return;
                }
                activate(pane);
                if (actionMode == null) startMultiSelect();
                toggle(f);
            });
            h.iconBox.setOnLongClickListener(v -> {
                activate(pane);
                if (f == pane.upItem) return true;
                if (actionMode != null) {
                    if (pane.selected.contains(f)) showSelectionSheet(new ArrayList<>(pane.selected));
                    else toggle(f);
                } else showItemSheet(f);
                return true;
            });
            h.root.setBackgroundColor(pane.selected.contains(f) ? 0x33009688 : Color.TRANSPARENT);
            return convertView;
        }
    }
}
