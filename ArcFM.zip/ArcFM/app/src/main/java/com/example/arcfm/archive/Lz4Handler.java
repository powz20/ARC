package com.example.arcfm.archive;

public final class Lz4Handler extends TarCodecHandler {
    public Lz4Handler(ArchiveOptions o) {
        super(o, Codecs.LZ4, new String[]{".tar.lz4", ".tlz4"}, new String[]{".lz4"});
    }
}
