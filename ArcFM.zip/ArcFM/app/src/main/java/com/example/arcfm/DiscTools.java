package com.example.arcfm;

import net.jpountz.lz4.LZ4Compressor;
import net.jpountz.lz4.LZ4Factory;
import net.jpountz.lz4.LZ4FastDecompressor;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/** Conversões entre ISO, BIN/CUE, CSO e ZSO (sem dependências além do lz4-java). */
final class DiscTools {
    private DiscTools() {
    }

    interface Cb {
        void update(long done, long total);

        boolean cancelled();
    }

    /** Conteúdo do disco como ISO (setores de 2048 bytes). */
    static final class Src {
        InputStream in;
        long size;
    }

    static int forceAlign = -1; // só para testes

    // ------------------------------------------------------------------ leitura

    static Src open(File f) throws IOException {
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (n.endsWith(".cso") || n.endsWith(".zso")) {
            CisoIn c = new CisoIn(f);
            Src s = new Src();
            s.in = c;
            s.size = c.total;
            return s;
        }
        if (n.endsWith(".cue")) return openCue(f);
        if (n.endsWith(".bin")) {
            return openBin(f, "MODE1", f.length() % 2352 == 0 ? 2352 : 2048);
        }
        Src s = new Src();
        s.in = new BufferedInputStream(new FileInputStream(f), 1 << 16);
        s.size = f.length();
        return s;
    }

    private static Src openCue(File cue) throws IOException {
        byte[] raw = new byte[(int) Math.min(cue.length(), 1 << 20)];
        try (InputStream in = new FileInputStream(cue)) {
            int got = 0;
            while (got < raw.length) {
                int k = in.read(raw, got, raw.length - got);
                if (k < 0) break;
                got += k;
            }
            raw = Arrays.copyOf(raw, got);
        }
        String text = new String(raw, StandardCharsets.ISO_8859_1);
        Matcher m = Pattern.compile("FILE\\s+\"?([^\"\\r\\n]+?)\"?\\s+BINARY", Pattern.CASE_INSENSITIVE).matcher(text);
        if (!m.find()) throw new IOException("O CUE não tem uma linha FILE ... BINARY");
        File bin = new File(cue.getParentFile(), m.group(1).trim());
        if (!bin.isFile()) throw new IOException("BIN não encontrado: " + bin.getName());
        Matcher t = Pattern.compile("TRACK\\s+\\d+\\s+(MODE\\d)/(\\d+)", Pattern.CASE_INSENSITIVE).matcher(text);
        if (!t.find()) throw new IOException("O CUE não tem uma trilha de dados (MODE1/MODE2)");
        return openBin(bin, t.group(1).toUpperCase(Locale.ROOT), Integer.parseInt(t.group(2)));
    }

    private static Src openBin(File bin, String mode, int secSize) throws IOException {
        int dataOff;
        if (secSize == 2352) dataOff = mode.equals("MODE2") ? 24 : 16;
        else if (secSize == 2336) dataOff = 8;
        else if (secSize == 2048) dataOff = 0;
        else throw new IOException("Tamanho de setor não suportado: " + secSize);
        long sectors = bin.length() / secSize;
        Src s = new Src();
        s.in = new SectorIn(new BufferedInputStream(new FileInputStream(bin), 1 << 16), secSize, dataOff, sectors);
        s.size = sectors * 2048L;
        return s;
    }

    private static final class SectorIn extends InputStream {
        private final InputStream in;
        private final int secSize;
        private final int dataOff;
        private final long sectors;
        private final byte[] sec;
        private long done;
        private int pos = 2048;

        SectorIn(InputStream in, int secSize, int dataOff, long sectors) {
            this.in = in;
            this.secSize = secSize;
            this.dataOff = dataOff;
            this.sectors = sectors;
            this.sec = new byte[secSize];
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n < 0 ? -1 : one[0] & 0xFF;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (pos >= 2048) {
                if (done >= sectors) return -1;
                readFully(in, sec, secSize);
                done++;
                pos = 0;
            }
            int k = Math.min(len, 2048 - pos);
            System.arraycopy(sec, dataOff + pos, b, off, k);
            pos += k;
            return k;
        }

        @Override
        public void close() throws IOException {
            in.close();
        }
    }

    private static final class CisoIn extends InputStream {
        private final RandomAccessFile raf;
        private final boolean zso;
        private final int bs;
        private final int align;
        final long total;
        private final int[] idx;
        private final int n;
        private int block;
        private byte[] raw;
        private final byte[] cur;
        private int curLen;
        private int curPos;
        private final Inflater inf = new Inflater(true);
        private final LZ4FastDecompressor dec = LZ4Factory.fastestInstance().fastDecompressor();

        CisoIn(File f) throws IOException {
            raf = new RandomAccessFile(f, "r");
            byte[] h = new byte[24];
            raf.readFully(h);
            String magic = new String(h, 0, 4, StandardCharsets.US_ASCII);
            zso = magic.equals("ZISO");
            if (!zso && !magic.equals("CISO")) throw new IOException("Não é um arquivo CSO/ZSO");
            ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
            int headerSize = b.getInt(4);
            total = b.getLong(8);
            bs = b.getInt(16);
            align = h[21] & 0xFF;
            if (bs <= 0 || bs > (1 << 20) || total < 0) throw new IOException("Cabeçalho CSO/ZSO inválido");
            n = (int) ((total + bs - 1) / bs);
            idx = new int[n + 1];
            byte[] ib = new byte[(n + 1) * 4];
            raf.seek(headerSize);
            raf.readFully(ib);
            ByteBuffer.wrap(ib).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer().get(idx);
            raw = new byte[bs * 2 + 1024];
            cur = new byte[bs];
        }

        private boolean next() throws IOException {
            if (block >= n) return false;
            int v = idx[block];
            int w = idx[block + 1];
            long a = (v & 0x7FFFFFFFL) << align;
            long e = (w & 0x7FFFFFFFL) << align;
            int len = (int) (e - a);
            int exp = (int) Math.min(bs, total - (long) block * bs);
            if (len < 0 || len > (64 << 20)) throw new IOException("Índice CSO/ZSO inválido");
            if (len + 1 > raw.length) raw = new byte[len + 1];
            raf.seek(a);
            raf.readFully(raw, 0, len);
            if ((v & 0x80000000) != 0) {
                Arrays.fill(cur, 0, exp, (byte) 0);
                System.arraycopy(raw, 0, cur, 0, Math.min(exp, len));
            } else if (zso) {
                dec.decompress(raw, 0, cur, 0, exp);
            } else {
                inf.reset();
                raw[len] = 0;
                inf.setInput(raw, 0, len + 1);
                int got = 0;
                try {
                    while (got < exp) {
                        int r = inf.inflate(cur, got, exp - got);
                        if (r == 0 && (inf.finished() || inf.needsInput())) break;
                        got += r;
                    }
                } catch (DataFormatException ex) {
                    throw new IOException("Bloco CSO corrompido: " + ex.getMessage());
                }
                if (got < exp) Arrays.fill(cur, got, exp, (byte) 0);
            }
            curLen = exp;
            curPos = 0;
            block++;
            return true;
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];
            int k = read(one, 0, 1);
            return k < 0 ? -1 : one[0] & 0xFF;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (curPos >= curLen && !next()) return -1;
            int k = Math.min(len, curLen - curPos);
            System.arraycopy(cur, curPos, b, off, k);
            curPos += k;
            return k;
        }

        @Override
        public void close() throws IOException {
            inf.end();
            raf.close();
        }
    }

    static void readFully(InputStream in, byte[] b, int len) throws IOException {
        int got = 0;
        while (got < len) {
            int k = in.read(b, got, len - got);
            if (k < 0) throw new IOException("Arquivo menor do que o esperado");
            got += k;
        }
    }

    // ------------------------------------------------------------------ escrita

    static void writeIso(InputStream in, long total, File out, Cb cb) throws IOException {
        try (OutputStream os = new FileOutputStream(out)) {
            byte[] buf = new byte[1 << 16];
            long done = 0;
            int k;
            while ((k = in.read(buf)) != -1) {
                os.write(buf, 0, k);
                done += k;
                cb.update(done, total);
                if (cb.cancelled()) return;
            }
        }
    }

    /** level: para CSO é o nível do Deflate (0 = sem compressão); para ZSO é 0..5 (0 = sem compressão). */
    static void writeCiso(InputStream in, long total, File out, boolean zso, int level, Cb cb) throws IOException {
        final int bs = 2048;
        long nn = (total + bs - 1) / bs;
        int n = (int) nn;
        int align = forceAlign >= 0 ? forceAlign : (total > 1_900_000_000L ? 2 : 0);
        LZ4Compressor lz = zso && level > 0 ? lz4(level) : null;
        Deflater def = !zso && level > 0 ? new Deflater(level, true) : null;
        int[] idx = new int[n + 1];
        byte[] buf = new byte[bs];
        byte[] comp = new byte[bs * 2 + 64];
        try (RandomAccessFile raf = new RandomAccessFile(out, "rw")) {
            raf.setLength(0);
            long pos = 24 + (nn + 1) * 4;
            raf.seek(pos);
            long mask = (1L << align) - 1;
            for (int i = 0; i < n; i++) {
                int want = (int) Math.min(bs, total - (long) i * bs);
                readFully(in, buf, want);
                if (want < bs) Arrays.fill(buf, want, bs, (byte) 0);
                long pad = (-pos) & mask;
                if (pad > 0) {
                    raf.write(new byte[(int) pad]);
                    pos += pad;
                }
                idx[i] = (int) (pos >> align);
                int clen = bs;
                if (lz != null) {
                    clen = lz.compress(buf, 0, bs, comp, 0);
                } else if (def != null) {
                    def.reset();
                    def.setInput(buf, 0, bs);
                    def.finish();
                    clen = 0;
                    while (!def.finished()) clen += def.deflate(comp, clen, comp.length - clen);
                }
                if (clen >= bs - 12) {
                    idx[i] |= 0x80000000;
                    raf.write(buf, 0, bs);
                    pos += bs;
                } else {
                    raf.write(comp, 0, clen);
                    pos += clen;
                }
                if ((i & 0xFF) == 0) {
                    cb.update((long) i * bs, total);
                    if (cb.cancelled()) return;
                }
            }
            long pad = (-pos) & mask;
            if (pad > 0) raf.write(new byte[(int) pad]);
            pos += pad;
            idx[n] = (int) (pos >> align);

            ByteBuffer h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
            h.put((byte) (zso ? 'Z' : 'C')).put((byte) 'I').put((byte) 'S').put((byte) 'O');
            h.putInt(24).putLong(total).putInt(bs).put((byte) 1).put((byte) align).put((byte) 0).put((byte) 0);
            raf.seek(0);
            raf.write(h.array());
            ByteBuffer ib = ByteBuffer.allocate((n + 1) * 4).order(ByteOrder.LITTLE_ENDIAN);
            ib.asIntBuffer().put(idx);
            raf.write(ib.array());
        } finally {
            if (def != null) def.end();
        }
    }

    private static LZ4Compressor lz4(int level) {
        LZ4Factory f = LZ4Factory.fastestInstance();
        switch (level) {
            case 1:
                return f.fastCompressor();
            case 2:
                return f.highCompressor(3);
            case 3:
                return f.highCompressor(6);
            case 4:
                return f.highCompressor(9);
            default:
                return f.highCompressor(12);
        }
    }

    // ------------------------------------------------------------------ BIN/CUE

    private static final int[] EDC = new int[256];
    private static final byte[] ECC_F = new byte[256];
    private static final byte[] ECC_B = new byte[256];

    static {
        for (int i = 0; i < 256; i++) {
            int j = (i << 1) ^ ((i & 0x80) != 0 ? 0x11D : 0);
            ECC_F[i] = (byte) j;
            ECC_B[(i ^ j) & 0xFF] = (byte) i;
            int e = i;
            for (int k = 0; k < 8; k++) e = (e >>> 1) ^ ((e & 1) != 0 ? 0xD8018001 : 0);
            EDC[i] = e;
        }
    }

    private static void ecc(byte[] s, int srcOff, int majorCount, int minorCount, int majorMult,
                            int minorInc, int destOff) {
        int size = majorCount * minorCount;
        for (int major = 0; major < majorCount; major++) {
            int index = (major >> 1) * majorMult + (major & 1);
            int a = 0;
            int b = 0;
            for (int minor = 0; minor < minorCount; minor++) {
                int t = s[srcOff + index] & 0xFF;
                index += minorInc;
                if (index >= size) index -= size;
                a ^= t;
                b ^= t;
                a = ECC_F[a] & 0xFF;
            }
            a = ECC_B[(ECC_F[a] & 0xFF) ^ b] & 0xFF;
            s[destOff + major] = (byte) a;
            s[destOff + major + majorCount] = (byte) (a ^ b);
        }
    }

    private static int bcd(int v) {
        return ((v / 10) << 4) | (v % 10);
    }

    /** Monta um setor MODE1/2352 completo (sincronismo, cabeçalho, EDC e ECC). */
    private static void buildSector(byte[] s, byte[] data, long lba) {
        Arrays.fill(s, (byte) 0);
        s[0] = 0;
        for (int i = 1; i <= 10; i++) s[i] = (byte) 0xFF;
        s[11] = 0;
        long a = lba + 150;
        s[12] = (byte) bcd((int) (a / 75 / 60));
        s[13] = (byte) bcd((int) (a / 75 % 60));
        s[14] = (byte) bcd((int) (a % 75));
        s[15] = 1;
        System.arraycopy(data, 0, s, 16, 2048);
        int edc = 0;
        for (int i = 0; i < 0x810; i++) edc = (edc >>> 8) ^ EDC[(edc ^ (s[i] & 0xFF)) & 0xFF];
        s[0x810] = (byte) edc;
        s[0x811] = (byte) (edc >>> 8);
        s[0x812] = (byte) (edc >>> 16);
        s[0x813] = (byte) (edc >>> 24);
        ecc(s, 0x0C, 86, 24, 2, 86, 0x81C);
        ecc(s, 0x0C, 52, 43, 86, 88, 0x8C8);
    }

    /** Até ~900 MB gera MODE1/2352 de verdade (CD). Acima disso usa MODE1/2048 (cópia direta). */
    static boolean rawPossible(long total) {
        return total <= 900L * 1024 * 1024;
    }

    static void writeBinCue(InputStream in, long total, File bin, File cue, Cb cb) throws IOException {
        boolean raw = rawPossible(total);
        long sectors = (total + 2047) / 2048;
        try (OutputStream os = new java.io.BufferedOutputStream(new FileOutputStream(bin), 1 << 16)) {
            byte[] data = new byte[2048];
            byte[] sec = new byte[2352];
            for (long i = 0; i < sectors; i++) {
                int want = (int) Math.min(2048, total - i * 2048);
                readFully(in, data, want);
                if (want < 2048) Arrays.fill(data, want, 2048, (byte) 0);
                if (raw) {
                    buildSector(sec, data, i);
                    os.write(sec);
                } else {
                    os.write(data);
                }
                if ((i & 0x3FF) == 0) {
                    cb.update(i * 2048, total);
                    if (cb.cancelled()) return;
                }
            }
        }
        String text = "FILE \"" + bin.getName() + "\" BINARY\r\n  TRACK 01 "
                + (raw ? "MODE1/2352" : "MODE1/2048") + "\r\n    INDEX 01 00:00:00\r\n";
        try (OutputStream os = new FileOutputStream(cue)) {
            os.write(text.getBytes(StandardCharsets.UTF_8));
        }
    }

    // ------------------------------------------------------------------ desfragmentar

    /** Reescreve o arquivo de forma contínua (reserva o espaço inteiro antes de gravar). */
    static void defragment(File f, Cb cb) throws IOException {
        long len = f.length();
        File dir = f.getParentFile();
        File tmp = new File(dir, f.getName() + ".defrag.tmp");
        boolean ok = false;
        try {
            try (FileInputStream in = new FileInputStream(f); FileOutputStream os = new FileOutputStream(tmp)) {
                try {
                    android.system.Os.posix_fallocate(os.getFD(), 0, len);
                } catch (Throwable ignored) {
                    // sistema de arquivos sem fallocate: grava em sequência mesmo assim
                }
                byte[] buf = new byte[1 << 20];
                long done = 0;
                int k;
                while ((k = in.read(buf)) != -1) {
                    os.write(buf, 0, k);
                    done += k;
                    cb.update(done, len);
                    if (cb.cancelled()) return;
                }
                os.getFD().sync();
            }
            if (tmp.length() != len) throw new IOException("A cópia ficou com tamanho diferente");
            File bak = new File(dir, f.getName() + ".old.tmp");
            if (!f.renameTo(bak)) throw new IOException("Não foi possível substituir o original");
            if (!tmp.renameTo(f)) {
                bak.renameTo(f);
                throw new IOException("Não foi possível colocar a cópia no lugar");
            }
            bak.delete();
            ok = true;
        } finally {
            if (!ok) tmp.delete();
        }
    }
}
