package com.example.arcfm.archive;

public interface ProgressListener {
    ProgressListener NONE = new ProgressListener() {
        @Override
        public void onProgress(String label, long done, long total) {
        }

        @Override
        public boolean isCancelled() {
            return false;
        }
    };

    void onProgress(String label, long done, long total);

    boolean isCancelled();
}
