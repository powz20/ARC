package com.example.arcfm.task;

/** Retrato imutável de uma tarefa (seguro para entregar à interface). */
public final class TaskProgress {
    public final long id;
    public final TaskState state;
    public final String format;
    public final String input;
    public final String output;
    public final long total;
    public final long processed;
    public final int percent;
    public final long bytesPerSecond;
    public final long elapsedMs;
    public final String error;
    public final String cancelReason;

    public TaskProgress(long id, TaskState state, String format, String input, String output, long total,
                        long processed, long bytesPerSecond, long elapsedMs, String error, String cancelReason) {
        this.id = id;
        this.state = state;
        this.format = format;
        this.input = input;
        this.output = output;
        this.total = total;
        this.processed = processed;
        this.percent = total > 0 ? (int) Math.min(100, processed * 100 / total) : 0;
        this.bytesPerSecond = bytesPerSecond;
        this.elapsedMs = elapsedMs;
        this.error = error;
        this.cancelReason = cancelReason;
    }
}
