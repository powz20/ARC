package com.example.arcfm.archive;

import com.example.arcfm.filesystem.TemporaryFileManager;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ArchiveManager {
    public static final int F_ZIP = 0;
    public static final int F_7Z = 1;
    public static final int F_TAR = 2;
    public static final int F_LZ4 = 3;
    public static final int F_GZ = 4;
    public static final int F_XZ = 5;
    public static final int F_BZ2 = 6;
    public static final int F_ZST = 7;

    private final ArchiveOptions o;
    private final List<ArchiveHandler> all = new ArrayList<>();

    public ArchiveManager(ArchiveOptions o) {
        this.o = o;
        all.add(new ZipHandler(o));
        all.add(new SevenZipHandler(o));
        all.add(new TarHandler(o));
        all.add(new Lz4Handler(o));
        all.add(new GzipHandler(o));
        all.add(new XzHandler(o));
        all.add(new Bzip2Handler(o));
        all.add(new ZstdHandler(o));
    }

    /** Mesma ordem de F_ZIP .. F_BZ2. */
    public ArchiveHandler forFormat(int format) {
        return all.get(Math.max(0, Math.min(format, all.size() - 1)));
    }

    public ArchiveHandler find(File f) {
        File v = Volumes.isFirst(f) ? Volumes.virtualBase(f) : f;
        for (ArchiveHandler h : all) {
            if (h.canRead(v)) return h;
        }
        return null;
    }

    /** Arquivo compactado que o app sabe abrir (volumes: só o .001). */
    public boolean canOpen(File f) {
        if (Volumes.isVolume(f) && !Volumes.isFirst(f)) return false;
        return find(f) != null;
    }

    /**
     * Compacta num temporário aleatório, confere o resultado e só então publica.
     * Nada é publicado em caso de erro, cancelamento ou saída vazia.
     */
    public List<File> compressSafely(ArchiveHandler h, List<File> inputs, File finalOut, ProgressListener l)
            throws IOException {
        File dir = finalOut.getParentFile();
        File tmp = TemporaryFileManager.create(dir, ".tmp");
        List<File> made = new ArrayList<>();
        boolean ok = false;
        try {
            h.compress(inputs, tmp, l);
            if (l.isCancelled()) throw new ArchiveCancelledException();
            if (tmp.length() <= 0) throw new IOException("A saída ficou vazia");
            h.test(tmp, l);
            if (l.isCancelled()) throw new ArchiveCancelledException();
            if (o.volumeBytes > 0 && tmp.length() > o.volumeBytes) {
                made.addAll(Volumes.split(tmp, finalOut, o.volumeBytes, l));
            } else {
                TemporaryFileManager.publish(tmp, finalOut);
                made.add(finalOut);
            }
            ok = true;
        } finally {
            if (!ok) {
                o.stats.partialOut = tmp.exists() ? tmp.length() : 0;
                for (File f : made) f.delete();
            }
            if (tmp.exists()) tmp.delete();
        }
        return made;
    }

    public void extract(File in, File dest, ProgressListener l) throws IOException {
        ArchiveHandler h = find(in);
        if (h == null) throw new IOException("Formato não suportado: " + in.getName());
        if (!Volumes.isFirst(in)) {
            h.extract(in, dest, l);
            return;
        }
        File joined = joinToTemp(in, h, dest, l);
        try {
            h.extract(joined, dest, l);
        } finally {
            joined.delete();
        }
    }

    public void test(File in, ProgressListener l) throws IOException {
        ArchiveHandler h = find(in);
        if (h == null) throw new IOException("Formato não suportado: " + in.getName());
        if (!Volumes.isFirst(in)) {
            h.test(in, l);
            return;
        }
        File joined = joinToTemp(in, h, in.getParentFile(), l);
        try {
            h.test(joined, l);
        } finally {
            joined.delete();
        }
    }

    private File joinToTemp(File first, ArchiveHandler h, File dir, ProgressListener l) throws IOException {
        String n = Volumes.virtualBase(first).getName().toLowerCase(Locale.ROOT);
        String suffix = ".tmp";
        for (String e : h.getExtensions()) {
            if (n.endsWith(e) && e.length() > suffix.length()) suffix = e;
        }
        File tmp = File.createTempFile(".arcfm-join-", suffix, dir);
        boolean ok = false;
        try {
            Volumes.join(first, tmp, l);
            ok = true;
        } finally {
            if (!ok) tmp.delete();
        }
        return tmp;
    }
}
