package com.example.arcfm;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.view.MenuItem;
import android.widget.Toast;

public class SettingsActivity extends PreferenceActivity {
    private static final int REQ_BG = 7;
    private static final int REQ_TB = 8;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(Prefs.isDark(this) ? R.style.AppDarkSettings : R.style.AppLightSettings);
        super.onCreate(savedInstanceState);
        getPreferenceManager().setSharedPreferencesName("arcfm");
        addPreferencesFromResource(R.xml.settings);
        com.example.arcfm.diagnostics.DiagnosticLog.init(getFilesDir(), "0.13", "ajustes",
                Prefs.get(this).getBoolean("diagOn", false));
        setTitle("Configurações");
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);

        findPreference("pickBg").setOnPreferenceClickListener(p -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            try {
                startActivityForResult(i, REQ_BG);
            } catch (Exception e) {
                Toast.makeText(this, "Nenhum seletor de imagens encontrado", Toast.LENGTH_LONG).show();
            }
            return true;
        });
        findPreference("removeBg").setOnPreferenceClickListener(p -> {
            Prefs.bgFile(this).delete();
            Toast.makeText(this, "Imagem de fundo removida", Toast.LENGTH_SHORT).show();
            return true;
        });
        findPreference("pickToolbarImg").setOnPreferenceClickListener(p -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            try {
                startActivityForResult(i, REQ_TB);
            } catch (Exception e) {
                Toast.makeText(this, "Nenhum seletor de imagens encontrado", Toast.LENGTH_LONG).show();
            }
            return true;
        });
        findPreference("removeToolbarImg").setOnPreferenceClickListener(p -> {
            Prefs.toolbarFile(this).delete();
            Prefs.putNum(this, "toolbarMode", 0);
            Toast.makeText(this, "Imagem da barra removida", Toast.LENGTH_SHORT).show();
            return true;
        });
        findPreference("toolbarPalette").setOnPreferenceClickListener(pref -> {
            showPalette(true);
            return true;
        });
        findPreference("bgPalette").setOnPreferenceClickListener(pref -> {
            showPalette(false);
            return true;
        });
        findPreference("diagOn").setOnPreferenceChangeListener((pref, v) -> {
            com.example.arcfm.diagnostics.DiagnosticLog.setEnabled((Boolean) v);
            return true;
        });
        findPreference("diagView").setOnPreferenceClickListener(pref -> {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Registro de diagnóstico")
                    .setMessage(com.example.arcfm.diagnostics.DiagnosticLog.read())
                    .setPositiveButton("OK", null)
                    .show();
            return true;
        });
        findPreference("diagClear").setOnPreferenceClickListener(pref -> {
            com.example.arcfm.diagnostics.DiagnosticLog.clear();
            Toast.makeText(this, "Registro apagado", Toast.LENGTH_SHORT).show();
            return true;
        });
        findPreference("themeMode").setOnPreferenceChangeListener((Preference p, Object v) -> {
            getWindow().getDecorView().post(this::recreate);
            return true;
        });
    }

    /** Paleta de cores: barra de ferramentas (cor sólida) ou plano de fundo (cor sólida). */
    private void showPalette(final boolean toolbar) {
        final android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        float dens = getResources().getDisplayMetrics().density;
        int pad = Math.round(16 * dens);
        box.setPadding(pad, Math.round(12 * dens), pad, Math.round(8 * dens));
        android.widget.HorizontalScrollView sv = new android.widget.HorizontalScrollView(this);
        android.widget.LinearLayout row = new android.widget.LinearLayout(this);
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        sv.addView(row);
        for (final int c : Prefs.PALETTE) {
            android.view.View sw = new android.view.View(this);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(c);
            sw.setBackground(g);
            int m = Math.round(6 * dens);
            android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                    Math.round(44 * dens), Math.round(44 * dens));
            lp.setMargins(m, Math.round(10 * dens), m, Math.round(10 * dens));
            row.addView(sw, lp);
            sw.setOnClickListener(v -> {
                applyColor(toolbar, Prefs.hex(c));
                dlg[0].dismiss();
            });
        }
        box.addView(sv);
        android.widget.Button custom = new android.widget.Button(this);
        custom.setText("Usar cor personalizada (HEX)");
        custom.setAllCaps(false);
        custom.setOnClickListener(v -> {
            dlg[0].dismiss();
            askHex(toolbar);
        });
        box.addView(custom);
        android.widget.Button reset = new android.widget.Button(this);
        reset.setText("Restaurar cor padrão");
        reset.setAllCaps(false);
        reset.setOnClickListener(v -> {
            resetColor(toolbar);
            dlg[0].dismiss();
        });
        box.addView(reset);
        dlg[0] = new android.app.AlertDialog.Builder(this)
                .setTitle(toolbar ? "Cor da barra" : "Cor do plano de fundo")
                .setView(box)
                .setNegativeButton("Fechar", null)
                .create();
        dlg[0].show();
    }

    private void askHex(final boolean toolbar) {
        final android.widget.EditText et = new android.widget.EditText(this);
        et.setSingleLine(true);
        et.setHint("#1E88E5");
        new android.app.AlertDialog.Builder(this)
                .setTitle("Cor em HEX")
                .setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    String hex = Prefs.normalizeHex(et.getText().toString());
                    if (hex == null) {
                        Toast.makeText(this, "Use o formato #RRGGBB, por exemplo #1E88E5", Toast.LENGTH_LONG).show();
                        return;
                    }
                    applyColor(toolbar, hex);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void applyColor(boolean toolbar, String hex) {
        if (toolbar) {
            Prefs.get(this).edit().putString("toolbarHex", hex).apply();
        } else {
            Prefs.get(this).edit().putString("bgHex", hex).apply();
            Prefs.putNum(this, "bgType", 2);
        }
        Toast.makeText(this, "Cor aplicada: " + hex, Toast.LENGTH_SHORT).show();
    }

    private void resetColor(boolean toolbar) {
        if (toolbar) {
            Prefs.get(this).edit().remove("toolbarHex").apply();
        } else {
            Prefs.get(this).edit().remove("bgHex").apply();
            if (Prefs.num(this, "bgType", 1) == 2) Prefs.putNum(this, "bgType", 1);
        }
        Toast.makeText(this, "Cor padrão restaurada", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQ_BG || requestCode == REQ_TB) && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            final Uri uri = data.getData();
            if (requestCode == REQ_TB) {
                new Thread(() -> {
                    String err = null;
                    try {
                        Prefs.saveToolbarImage(this, uri);
                        Prefs.putNum(this, "toolbarMode", 1);
                    } catch (Throwable t) {
                        err = t.getClass().getSimpleName() + ": " + t.getMessage();
                    }
                    final String fErr = err;
                    runOnUiThread(() -> Toast.makeText(this,
                            fErr == null ? "Imagem da barra aplicada" : "Não foi possível usar a imagem: " + fErr,
                            Toast.LENGTH_LONG).show());
                }).start();
                return;
            }
            Intent crop = new Intent(this, ImageCropActivity.class);
            crop.setData(uri);
            crop.putExtra("mode", "background");
            crop.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(crop, requestCode + 100);
            return;
        }
        if ((requestCode == REQ_BG + 100 || requestCode == REQ_TB + 100) && resultCode == RESULT_OK) {
            if (requestCode == REQ_TB + 100) Prefs.putNum(this, "toolbarMode", 1);
            else Prefs.putNum(this, "bgType", 1);
            Toast.makeText(this, "Imagem aplicada", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
