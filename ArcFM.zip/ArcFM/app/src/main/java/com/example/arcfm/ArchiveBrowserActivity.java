package com.example.arcfm;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arcfm.archive.ArchiveLister;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Navega dentro de um arquivo compactado como se fosse uma pasta. Somente leitura. */
public class ArchiveBrowserActivity extends Activity {
    private File archive;
    private String prefix = "";
    private List<ArchiveLister.Entry> all = new ArrayList<>();
    private final List<Row> rows = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private TextView header;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private static final class Row {
        final String label;
        final String path;     // caminho normalizado
        final boolean dir;
        final ArchiveLister.Entry entry;

        Row(String label, String path, boolean dir, ArchiveLister.Entry entry) {
            this.label = label;
            this.path = path;
            this.dir = dir;
            this.entry = entry;
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        String p = getIntent().getStringExtra("path");
        archive = p == null ? null : new File(p);
        if (archive == null || !archive.isFile()) {
            Toast.makeText(this, "Arquivo não encontrado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        float dens = getResources().getDisplayMetrics().density;
        int pad = Math.round(10 * dens);
        android.widget.LinearLayout col = new android.widget.LinearLayout(this);
        col.setOrientation(android.widget.LinearLayout.VERTICAL);
        header = new TextView(this);
        header.setPadding(pad, pad, pad, pad);
        header.setTextSize(14);
        header.setSingleLine(true);
        header.setEllipsize(android.text.TextUtils.TruncateAt.START);
        col.addView(header, new android.widget.LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ListView lv = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((AdapterView<?> parent, View view, int pos, long id) -> onRowClick(pos));
        col.addView(lv, new android.widget.LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(col);
        setTitle(archive.getName() + " (somente leitura)");
        header.setText("Carregando…");

        new Thread(() -> {
            try {
                final List<ArchiveLister.Entry> list = ArchiveLister.list(archive, null);
                ui.post(() -> {
                    all = list;
                    refresh();
                });
            } catch (Exception e) {
                ui.post(() -> {
                    Toast.makeText(this, "Não foi possível abrir: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    finish();
                });
            }
        }).start();
    }

    /** Filhos imediatos de 'prefix': pastas primeiro, depois arquivos. */
    private void refresh() {
        rows.clear();
        adapter.clear();
        if (!prefix.isEmpty()) {
            rows.add(new Row("..", parentOf(prefix), true, null));
            adapter.add("⬆  ..");
        }
        Map<String, Row> dirs = new LinkedHashMap<>();
        Map<String, Row> files = new LinkedHashMap<>();
        for (ArchiveLister.Entry e : all) {
            if (e.path.isEmpty() || !e.path.startsWith(prefix) || e.path.equals(prefix)) continue;
            String rest = e.path.substring(prefix.length());
            int slash = rest.indexOf('/');
            if (slash >= 0) {
                String child = rest.substring(0, slash);
                if (!dirs.containsKey(child)) {
                    dirs.put(child, new Row(child, prefix + child, true, null));
                }
            } else if (e.dir) {
                if (!dirs.containsKey(rest)) dirs.put(rest, new Row(rest, prefix + rest, true, null));
            } else {
                files.put(rest, new Row(rest, prefix + rest, false, e));
            }
        }
        for (Row r : dirs.values()) {
            rows.add(r);
            adapter.add("\uD83D\uDCC1  " + r.label);
        }
        for (Row r : files.values()) {
            rows.add(r);
            adapter.add("\uD83D\uDCC4  " + r.label + "  (" + humanSize(r.entry.size) + ")");
        }
        header.setText(archive.getName() + " / " + (prefix.isEmpty() ? "" : prefix));
        if (adapter.getCount() == 0) adapter.add("(pasta vazia)");
        adapter.notifyDataSetChanged();
    }

    private void onRowClick(int pos) {
        if (pos < 0 || pos >= rows.size()) return;
        Row r = rows.get(pos);
        if (r.dir) {
            prefix = r.path.isEmpty() ? "" : r.path + "/";
            refresh();
        } else {
            openFile(r.entry);
        }
    }

    private static String parentOf(String prefix) {
        String p = prefix.endsWith("/") ? prefix.substring(0, prefix.length() - 1) : prefix;
        int i = p.lastIndexOf('/');
        return i < 0 ? "" : p.substring(0, i + 1);
    }

    /** Lê a entrada para o cache e abre com o visualizador de imagem ou outro app. */
    private void openFile(final ArchiveLister.Entry e) {
        Toast.makeText(this, "Abrindo " + e.path + "…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String leaf = e.path.substring(e.path.lastIndexOf('/') + 1);
                File dir = new File(getCacheDir(), "view");
                dir.mkdirs();
                File out = new File(dir, leaf.isEmpty() ? "arquivo" : leaf);
                ArchiveLister.readEntry(archive, e, out, null);
                ui.post(() -> showFile(out));
            } catch (Exception ex) {
                ui.post(() -> Toast.makeText(this, "Erro ao abrir: " + ex.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void showFile(File f) {
        String n = f.getName().toLowerCase(java.util.Locale.ROOT);
        if (n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp")
                || n.endsWith(".gif") || n.endsWith(".bmp")) {
            Intent i = new Intent(this, ImageViewActivity.class);
            i.putExtra("path", f.getAbsolutePath());
            startActivity(i);
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(FileShareProvider.uriFor(f), "*/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Abrir com"));
        } catch (Exception ex) {
            Toast.makeText(this, "Nenhum app encontrado para abrir este arquivo", Toast.LENGTH_LONG).show();
        }
    }

    private static String humanSize(long b) {
        if (b < 1024) return b + " B";
        double v = b / 1024.0;
        String[] u = {"KB", "MB", "GB", "TB"};
        int i = 0;
        while (v >= 1024 && i < u.length - 1) {
            v /= 1024;
            i++;
        }
        return String.format(java.util.Locale.US, "%.1f %s", v, u[i]);
    }

    @Override
    public void onBackPressed() {
        if (!prefix.isEmpty()) {
            prefix = parentOf(prefix);
            refresh();
        } else {
            super.onBackPressed();
        }
    }
}
