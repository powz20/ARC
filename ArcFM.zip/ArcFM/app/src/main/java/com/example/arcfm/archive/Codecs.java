package com.example.arcfm.archive;

import net.jpountz.lz4.LZ4Compressor;
import net.jpountz.lz4.LZ4Factory;
import net.jpountz.lz4.LZ4FrameInputStream;
import net.jpountz.lz4.LZ4FrameOutputStream;
import net.jpountz.xxhash.XXHashFactory;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.tukaani.xz.LZMA2Options;
import org.tukaani.xz.XZInputStream;
import org.tukaani.xz.XZOutputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public final class Codecs {
    private Codecs() {
    }

    public static final int NONE = 0;
    public static final int LZ4 = 1;
    public static final int GZ = 2;
    public static final int XZ = 3;
    public static final int BZ2 = 4;
    public static final int ZST = 5;

    public static final int[] ZIP_LEVELS = {0, 1, 3, 6, 8, 9};
    public static final int[] SEVENZ_PRESETS = {0, 1, 3, 5, 7, 8};
    public static final int[] BZ2_BLOCKS = {1, 1, 3, 5, 7, 9};
    /** Níveis 0..5 do zstd (0 e 1 = mais rápido). */
    public static final int[] ZST_LEVELS = {1, 1, 3, 6, 12, 19};

    public static InputStream wrapIn(InputStream in, int codec) throws IOException {
        if (codec == LZ4) return new LZ4FrameInputStream(in);
        if (codec == GZ) return new GZIPInputStream(in, 64 * 1024);
        if (codec == XZ) return new XZInputStream(in);
        if (codec == BZ2) return new BZip2CompressorInputStream(in);
        if (codec == ZST) return new com.example.arcfm.zstd.ZstdInputStream(in);
        return in;
    }

    /** Threads para o TAR.LZ4: só em arquivos grandes (>= 256 MB), no máximo 4 e nunca acima dos núcleos. */
    public static final long LZ4_PARALLEL_MIN_BYTES = 256L << 20;

    public static int lz4Threads(long totalBytes, int userLimit) {
        if (totalBytes < LZ4_PARALLEL_MIN_BYTES) return 1;
        int cores = Runtime.getRuntime().availableProcessors();
        int limit = userLimit <= 0 ? cores : Math.min(userLimit, cores);
        int th = Math.min(limit, 4);
        return th >= 2 ? th : 1;
    }

    /** Níveis 1..5 viram: 1 fastCompressor, 2 high(3), 3 high(6), 4 high(9), 5 high(12). */
    public static OutputStream wrapOut(OutputStream out, int codec, int level, int threads) throws IOException {
        int lv = Math.max(0, Math.min(level, 5));
        if (codec == LZ4) {
            int l = Math.max(1, lv);
            if (threads >= 2) return new ParallelLz4Out(out, l, threads);
            return newLz4Out(out, l);
        }
        if (codec == GZ) {
            final int z = ZIP_LEVELS[lv];
            return new GZIPOutputStream(out, 64 * 1024) {
                {
                    def.setLevel(z);
                }
            };
        }
        if (codec == XZ) return new XZOutputStream(out, new LZMA2Options(SEVENZ_PRESETS[lv]));
        if (codec == BZ2) return new BZip2CompressorOutputStream(out, BZ2_BLOCKS[lv]);
        if (codec == ZST) return new com.example.arcfm.zstd.ZstdOutputStream(out, ZST_LEVELS[lv]);
        return out;
    }

    public static LZ4Compressor lz4Compressor(int level) {
        LZ4Factory f = LZ4Factory.fastestInstance();
        switch (level) {
            case 1:
                return f.fastCompressor();
            case 2:
                return f.highCompressor(3);
            case 3:
                return f.highCompressor(6);
            case 4:
                return f.highCompressor(9);
            default:
                return f.highCompressor(12);
        }
    }

    private static OutputStream newLz4Out(OutputStream fos, int level) throws IOException {
        return new LZ4FrameOutputStream(fos, LZ4FrameOutputStream.BLOCKSIZE.SIZE_4MB, -1L, lz4Compressor(level),
                XXHashFactory.fastestInstance().hash32(), LZ4FrameOutputStream.FLG.Bits.BLOCK_INDEPENDENCE);
    }

    public static void closeAll(InputStream src, InputStream base) throws IOException {
        if (src != null) src.close();
        else base.close();
    }
}
