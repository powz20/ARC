package com.example.arcfm.task;

public enum TaskState {
    AGUARDANDO("Aguardando"), EXECUTANDO("Executando"), PAUSADO("Pausado"), CANCELANDO("Cancelando"),
    CONCLUIDO("Concluído"), FALHOU("Falhou"), CANCELADO("Cancelado");

    public final String label;

    TaskState(String label) {
        this.label = label;
    }

    public boolean finished() {
        return this == CONCLUIDO || this == FALHOU || this == CANCELADO;
    }
}
