package com.example.arcfm.archive;

import java.io.File;
import java.io.IOException;
import java.util.List;

public interface ArchiveHandler {
    boolean canRead(File file);

    String[] getExtensions();

    void compress(List<File> inputs, File output, ProgressListener listener) throws IOException;

    void extract(File input, File destination, ProgressListener listener) throws IOException;

    void test(File input) throws IOException;

    void test(File input, ProgressListener listener) throws IOException;
}
