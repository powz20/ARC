package com.example.arcfm.archive;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/**
 * Gera imagem ISO 9660 de uma pasta (nível 1: nomes 8.3 em maiúsculas, sem Joliet/Rock Ridge).
 * Limites do formato: 8 níveis de pastas e 4 GB por arquivo. Nomes longos são convertidos.
 */
public final class Iso9660Writer {
    private static final int SEC = 2048;
    private static final int MAX_DEPTH = 8;
    private static final long MAX_FILE = 0xFFFFFFFFL;

    private Iso9660Writer() {
    }

    private static final class Node {
        final File file;
        final boolean dir;
        final int depth;
        final long mtime;
        Node parent;
        final List<Node> kids = new ArrayList<>();
        String base = "";
        String ext = "";
        String isoName = "";
        int id;
        long lba;
        long size;
        int dirSectors;
        byte[] dirBytes;

        Node(File file, boolean dir, int depth) {
            this.file = file;
            this.dir = dir;
            this.depth = depth;
            this.mtime = file.lastModified();
        }
    }

    /** Escreve a pasta 'root' como ISO em 'out'. Quem chama deve gravar num temporário e publicar depois. */
    public static void write(File root, File out, String label, ProgressListener l) throws IOException {
        if (!root.isDirectory()) throw new IOException("Não é uma pasta: " + root.getName());
        Node top = new Node(root, true, 1);
        top.id = 1;
        fill(top, l);

        List<Node> dirs = new ArrayList<>();
        dirs.add(top);
        for (int i = 0; i < dirs.size(); i++) {
            Node d = dirs.get(i);
            for (Node k : d.kids) {
                if (k.dir) {
                    k.id = dirs.size() + 1;
                    dirs.add(k);
                }
            }
        }
        List<Node> files = new ArrayList<>();
        for (Node d : dirs) {
            for (Node k : d.kids) {
                if (!k.dir) files.add(k);
            }
        }

        // tamanhos (só dependem do comprimento dos registros)
        int pathLen = 0;
        for (Node d : dirs) pathLen += pathRecLen(pathName(d).length);
        int ptSectors = Math.max(1, sectorsFor(pathLen));
        for (Node d : dirs) {
            d.dirSectors = Math.max(1, sectorsFor(layoutLen(dirRecords(d, 0, 0))));
            d.size = (long) d.dirSectors * SEC;
        }

        // posições no disco: sistema (16 setores), PVD, terminador, tabelas, pastas, arquivos
        long lbaL = 18;
        long lbaM = lbaL + ptSectors;
        long cur = lbaM + ptSectors;
        for (Node d : dirs) {
            d.lba = cur;
            cur += d.dirSectors;
        }
        long totalFileBytes = 0;
        for (Node f : files) {
            f.lba = cur;
            cur += sectorsFor(f.size);
            totalFileBytes += f.size;
        }
        long totalSectors = cur;
        if (totalSectors > 0xFFFFFFFFL) throw new IOException("Imagem grande demais para ISO9660");

        for (Node d : dirs) d.dirBytes = buildDir(d);

        byte[] pvd = primaryDescriptor(label, top, totalSectors, pathLen, lbaL, lbaM);
        byte[] term = new byte[SEC];
        term[0] = (byte) 255;
        putAscii(term, 1, "CD001");
        term[6] = 1;

        byte[] buf = new byte[1 << 16];
        long[] done = {0};
        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
            os.write(new byte[16 * SEC]);
            os.write(pvd);
            os.write(term);
            os.write(pathTable(false, dirs, ptSectors));
            os.write(pathTable(true, dirs, ptSectors));
            for (Node d : dirs) os.write(d.dirBytes);
            for (Node f : files) copyFile(f, os, buf, l, done, totalFileBytes);
        }
        if (out.length() != totalSectors * SEC) {
            throw new IOException("ISO gerada com tamanho inesperado");
        }
    }

    /** Confere a assinatura ISO 9660 no setor 16. */
    public static boolean isIso(File f) throws IOException {
        if (f.length() < 17L * SEC) return false;
        byte[] b = new byte[6];
        try (InputStream in = new FileInputStream(f)) {
            long skip = 16L * SEC;
            long s = 0;
            while (s < skip) {
                long k = in.skip(skip - s);
                if (k <= 0) break;
                s += k;
            }
            int n = in.read(b);
            return n == 6 && b[0] == 1 && new String(b, 1, 5, StandardCharsets.US_ASCII).equals("CD001");
        }
    }

    // ------------------------------------------------------------------ árvore e nomes

    private static boolean isLink(File f) {
        try {
            return Files.isSymbolicLink(f.toPath());
        } catch (RuntimeException e) {
            return false; // nome que o sistema não consegue converter: trata como arquivo comum
        }
    }

    private static void fill(Node d, ProgressListener l) throws IOException {
        File[] fs = d.file.listFiles();
        if (fs == null) throw new IOException("Não foi possível ler: " + d.file.getName());
        Arrays.sort(fs, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (File f : fs) {
            if (l != null && l.isCancelled()) throw new ArchiveCancelledException();
            if (isLink(f)) continue; // não segue links
            if (f.isDirectory()) {
                if (d.depth + 1 > MAX_DEPTH) {
                    throw new IOException("Pastas aninhadas demais para ISO9660 (máximo " + MAX_DEPTH + " níveis)");
                }
                Node k = new Node(f, true, d.depth + 1);
                k.parent = d;
                d.kids.add(k);
                fill(k, l);
            } else if (f.isFile()) {
                if (f.length() > MAX_FILE) {
                    throw new IOException("Arquivo maior que 4 GB não cabe em ISO9660: " + f.getName());
                }
                Node k = new Node(f, false, d.depth + 1);
                k.parent = d;
                k.size = f.length();
                d.kids.add(k);
            }
        }
        Set<String> used = new HashSet<>();
        for (Node k : d.kids) {
            String name = k.file.getName();
            int dot = k.dir ? -1 : name.lastIndexOf('.');
            if (dot > 0) {
                k.base = toIso(name.substring(0, dot));
                k.ext = toIso(name.substring(dot + 1));
            } else {
                k.base = toIso(name);
                k.ext = "";
            }
            if (k.base.isEmpty()) k.base = "FILE";
            if (k.base.length() > 8) k.base = k.base.substring(0, 8);
            if (k.ext.length() > 3) k.ext = k.ext.substring(0, 3);
            k.isoName = uniqueName(used, k);
        }
    }

    private static String toIso(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toUpperCase(Locale.ROOT).toCharArray()) {
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_') sb.append(c);
            else sb.append('_');
        }
        return sb.toString();
    }

    private static String uniqueName(Set<String> used, Node k) {
        for (int n = 0; ; n++) {
            String b;
            if (n == 0) {
                b = k.base;
            } else {
                String suf = "_" + n;
                int keep = Math.max(1, 8 - suf.length());
                b = k.base.substring(0, Math.min(k.base.length(), keep)) + suf;
            }
            String name;
            if (k.dir) {
                name = b;
            } else {
                name = (k.ext.isEmpty() ? b : b + "." + k.ext) + ";1";
            }
            if (used.add(name)) return name;
        }
    }

    private static byte[] isoBytes(Node k) {
        return k.isoName.getBytes(StandardCharsets.US_ASCII);
    }

    private static byte[] pathName(Node d) {
        return d.parent == null ? new byte[]{0} : isoBytes(d);
    }

    private static int pathRecLen(int nameLen) {
        return 8 + nameLen + (nameLen % 2 == 1 ? 1 : 0);
    }

    // ------------------------------------------------------------------ registros de diretório

    private static List<byte[]> dirRecords(Node d, long lba, long size) {
        List<byte[]> recs = new ArrayList<>();
        long pl = d.parent == null ? lba : d.parent.lba;
        long ps = d.parent == null ? size : d.parent.size;
        recs.add(record(new byte[]{0}, lba, size, true, d.mtime));
        recs.add(record(new byte[]{1}, pl, ps, true, d.mtime));
        for (Node k : d.kids) {
            recs.add(record(isoBytes(k), k.lba, k.size, k.dir, k.mtime));
        }
        return recs;
    }

    /** Mesma regra de posicionamento usada para gravar: nenhum registro cruza um setor. */
    private static int layoutLen(List<byte[]> recs) {
        int p = 0;
        for (byte[] r : recs) {
            if ((p % SEC) + r.length > SEC) p = (p / SEC + 1) * SEC;
            p += r.length;
        }
        return p;
    }

    private static byte[] buildDir(Node d) {
        List<byte[]> recs = dirRecords(d, d.lba, d.size);
        byte[] out = new byte[d.dirSectors * SEC];
        int p = 0;
        for (byte[] r : recs) {
            if ((p % SEC) + r.length > SEC) p = (p / SEC + 1) * SEC;
            System.arraycopy(r, 0, out, p, r.length);
            p += r.length;
        }
        return out;
    }

    private static byte[] record(byte[] name, long lba, long size, boolean dir, long mtime) {
        int lenFi = name.length;
        int len = 33 + lenFi + (lenFi % 2 == 0 ? 1 : 0);
        byte[] r = new byte[len];
        r[0] = (byte) len;
        both32(r, 2, lba);
        both32(r, 10, size);
        date7(r, 18, mtime);
        r[25] = (byte) (dir ? 2 : 0);
        both16(r, 28, 1);
        r[32] = (byte) lenFi;
        System.arraycopy(name, 0, r, 33, lenFi);
        return r;
    }

    // ------------------------------------------------------------------ tabelas e descritores

    private static byte[] pathTable(boolean be, List<Node> dirs, int ptSectors) {
        byte[] out = new byte[ptSectors * SEC];
        int p = 0;
        for (Node d : dirs) {
            byte[] nm = pathName(d);
            int len = nm.length;
            out[p] = (byte) len;
            out[p + 1] = 0;
            int parentId = d.parent == null ? 1 : d.parent.id;
            if (be) {
                beInt(out, p + 2, (int) d.lba);
                beShort(out, p + 6, parentId);
            } else {
                leInt(out, p + 2, (int) d.lba);
                leShort(out, p + 6, parentId);
            }
            System.arraycopy(nm, 0, out, p + 8, len);
            p += pathRecLen(len);
        }
        return out;
    }

    private static byte[] primaryDescriptor(String label, Node top, long totalSectors, int pathLen,
                                            long lbaL, long lbaM) {
        byte[] b = new byte[SEC];
        b[0] = 1;
        putAscii(b, 1, "CD001");
        b[6] = 1;
        Arrays.fill(b, 8, 40, (byte) ' ');
        String vol = toIso(label == null ? "ARCFM" : label);
        if (vol.isEmpty()) vol = "ARCFM";
        if (vol.length() > 32) vol = vol.substring(0, 32);
        Arrays.fill(b, 40, 72, (byte) ' ');
        putAscii(b, 40, vol);
        both32(b, 80, totalSectors);
        both16(b, 120, 1);
        both16(b, 124, 1);
        both16(b, 128, SEC);
        both32(b, 132, pathLen);
        leInt(b, 140, (int) lbaL);
        beInt(b, 148, (int) lbaM);
        byte[] rootRec = record(new byte[]{0}, top.lba, top.size, true, top.mtime);
        System.arraycopy(rootRec, 0, b, 156, rootRec.length);
        Arrays.fill(b, 190, 813, (byte) ' ');
        longDate(b, 813, System.currentTimeMillis());
        longDate(b, 830, System.currentTimeMillis());
        longDate(b, 847, 0);
        longDate(b, 864, 0);
        b[881] = 1;
        return b;
    }

    // ------------------------------------------------------------------ arquivos

    private static void copyFile(Node f, OutputStream os, byte[] buf, ProgressListener l, long[] done, long total)
            throws IOException {
        long left = f.size;
        try (InputStream in = new FileInputStream(f.file)) {
            while (left > 0) {
                if (l != null && l.isCancelled()) throw new ArchiveCancelledException();
                int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                if (n < 0) throw new IOException("Arquivo mudou durante a criação da ISO: " + f.file.getName());
                os.write(buf, 0, n);
                left -= n;
                done[0] += n;
                if (l != null) l.onProgress("ISO: " + f.file.getName(), done[0], total);
            }
        }
        long pad = sectorsFor(f.size) * (long) SEC - f.size;
        if (pad > 0) os.write(new byte[(int) pad]);
    }

    private static int sectorsFor(long bytes) {
        return (int) ((bytes + SEC - 1) / SEC);
    }

    // ------------------------------------------------------------------ primitivas de bytes

    private static void putAscii(byte[] b, int off, String s) {
        byte[] x = s.getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(x, 0, b, off, x.length);
    }

    private static void both32(byte[] b, int off, long v) {
        leInt(b, off, (int) v);
        beInt(b, off + 4, (int) v);
    }

    private static void both16(byte[] b, int off, int v) {
        leShort(b, off, v);
        beShort(b, off + 2, v);
    }

    private static void leInt(byte[] b, int off, int v) {
        b[off] = (byte) v;
        b[off + 1] = (byte) (v >>> 8);
        b[off + 2] = (byte) (v >>> 16);
        b[off + 3] = (byte) (v >>> 24);
    }

    private static void beInt(byte[] b, int off, int v) {
        b[off] = (byte) (v >>> 24);
        b[off + 1] = (byte) (v >>> 16);
        b[off + 2] = (byte) (v >>> 8);
        b[off + 3] = (byte) v;
    }

    private static void leShort(byte[] b, int off, int v) {
        b[off] = (byte) v;
        b[off + 1] = (byte) (v >>> 8);
    }

    private static void beShort(byte[] b, int off, int v) {
        b[off] = (byte) (v >>> 8);
        b[off + 1] = (byte) v;
    }

    private static Calendar utc(long millis) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
        c.setTimeInMillis(millis);
        return c;
    }

    /** Data de registro de diretório: 7 bytes binários. */
    private static void date7(byte[] r, int off, long millis) {
        Calendar c = utc(millis);
        r[off] = (byte) (c.get(Calendar.YEAR) - 1900);
        r[off + 1] = (byte) (c.get(Calendar.MONTH) + 1);
        r[off + 2] = (byte) c.get(Calendar.DAY_OF_MONTH);
        r[off + 3] = (byte) c.get(Calendar.HOUR_OF_DAY);
        r[off + 4] = (byte) c.get(Calendar.MINUTE);
        r[off + 5] = (byte) c.get(Calendar.SECOND);
        r[off + 6] = 0;
    }

    /** Data do descritor: 16 caracteres ASCII + deslocamento de fuso. */
    private static void longDate(byte[] b, int off, long millis) {
        Calendar c = utc(millis);
        String s = String.format(Locale.US, "%04d%02d%02d%02d%02d%02d00",
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH),
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), c.get(Calendar.SECOND));
        putAscii(b, off, s);
        b[off + 16] = 0;
    }
}
