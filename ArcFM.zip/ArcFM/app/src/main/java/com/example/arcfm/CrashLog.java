package com.example.arcfm;

import android.content.Context;
import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Salva o rastro completo de um crash em ArcFM/crash.txt (armazenamento) para diagnóstico. */
final class CrashLog {
    private CrashLog() {
    }

    static void install(final Context ctx) {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                write(ctx, thread, error);
            } catch (Throwable ignored) {
                // nunca impedir o crash de seguir o caminho normal
            }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    private static void write(Context ctx, Thread thread, Throwable error) throws Exception {
        File dir = new File(Environment.getExternalStorageDirectory(), "ArcFM");
        if (!dir.isDirectory() && !dir.mkdirs()) dir = ctx.getFilesDir();
        File f = new File(dir, "crash.txt");
        StringWriter sw = new StringWriter();
        error.printStackTrace(new PrintWriter(sw));
        String text = "==== " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + " ====\n"
                + "Thread: " + thread.getName() + "\n"
                + "Android " + Build.VERSION.RELEASE + " | " + Build.MODEL + " | ABI " + Build.SUPPORTED_ABIS[0] + "\n"
                + sw + "\n";
        try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(f, true), StandardCharsets.UTF_8)) {
            w.write(text);
        }
    }
}
