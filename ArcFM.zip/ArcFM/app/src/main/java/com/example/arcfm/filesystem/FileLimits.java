package com.example.arcfm.filesystem;

import java.io.IOException;

/** Limites contra bombas de descompressão e arquivos malformados. */
public final class FileLimits {
    public boolean enabled = true;
    public long maxEntries = 500_000;
    public int maxDepth = 64;
    public long maxTotalBytes = 256L << 30;
    public long maxEntryBytes = 64L << 30;
    public double maxRatio = 5000;      // só vale depois de 1 GB extraído

    private long entries;
    private long total;
    private long archiveBytes;

    public void begin(long archiveBytes) {
        this.archiveBytes = archiveBytes;
        entries = 0;
        total = 0;
    }

    public void entry(String name, long declaredSize) throws IOException {
        if (!enabled) return;
        if (++entries > maxEntries) throw new IOException("Arquivo com entradas demais (limite de segurança)");
        if (declaredSize > maxEntryBytes) throw new IOException("Entrada grande demais: " + name);
    }

    /** Chamado com os bytes realmente extraídos (o tamanho declarado pode mentir). */
    public void bytes(long n) throws IOException {
        if (!enabled) return;
        total += n;
        if (total > maxTotalBytes) throw new IOException("Limite de tamanho total da extração excedido");
        if (archiveBytes > 0 && total > (1L << 30) && total / (double) archiveBytes > maxRatio) {
            throw new IOException("Possível bomba de descompressão (taxa de expansão muito alta)");
        }
    }
}
