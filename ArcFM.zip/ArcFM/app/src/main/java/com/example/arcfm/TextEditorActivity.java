package com.example.arcfm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class TextEditorActivity extends Activity {
    private static final int MENU_SEARCH = 1;
    private static final int MENU_SAVE = 2;
    private static final int MENU_MORE = 3;
    private File file;
    private EditText editor;
    private TextView lineNumbers;
    private Charset charset = StandardCharsets.UTF_8;
    private String syntax = "Automático";
    private boolean wrap = true;
    private boolean showLines = true;
    private String fontName = "Sans Serif";
    private int fontSize = 14;
    private int lastSearch = 0;

    @Override protected void onCreate(Bundle state) {
        setTheme(Prefs.isDark(this) ? R.style.AppDark : R.style.AppLight);
        super.onCreate(state);
        file = new File(getIntent().getStringExtra("path"));
        setTitle(file.getName());
        loadPreferences();
        buildUi();
        loadFile();
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void loadPreferences() {
        android.content.SharedPreferences p = Prefs.get(this);
        wrap = p.getBoolean("txtWrap", true);
        showLines = p.getBoolean("txtLines", true);
        fontName = p.getString("txtFont", "Sans Serif");
        fontSize = p.getInt("txtFontSize", 14);
        syntax = p.getString("txtSyntax", "Automático");
        try { charset = Charset.forName(p.getString("txtCharset", "UTF-8")); } catch (Exception ignored) { }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        lineNumbers = new TextView(this);
        lineNumbers.setGravity(Gravity.TOP | Gravity.END);
        lineNumbers.setPadding(dp(8), dp(10), dp(8), dp(10));
        lineNumbers.setTextColor(isDark() ? 0xFF9AA4AE : 0xFF71808D);
        lineNumbers.setBackgroundColor(isDark() ? 0x22111111 : 0x11000000);
        root.addView(lineNumbers, new LinearLayout.LayoutParams(dp(48), -1));
        editor = new EditText(this);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setPadding(dp(10), dp(10), dp(10), dp(80));
        editor.setTextSize(fontSize);
        editor.setTypeface(typefaceFor(fontName));
        editor.setSingleLine(false);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        applyWrap();
        root.addView(editor, new LinearLayout.LayoutParams(0, -1, 1));
        setContentView(root);
        lineNumbers.setVisibility(showLines ? View.VISIBLE : View.GONE);
        editor.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) { }
            public void onTextChanged(CharSequence s, int st, int before, int count) { updateLineNumbers(); }
            public void afterTextChanged(Editable e) { }
        });
        updateLineNumbers();
    }

    private boolean isDark() { return Prefs.isDark(this); }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private Typeface typefaceFor(String name) {
        if ("Serif".equals(name)) return Typeface.create(Typeface.SERIF, Typeface.NORMAL);
        if ("Monospace".equals(name)) return Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL);
        if ("Sans Serif Condensed".equals(name)) return Typeface.create("sans-serif-condensed", Typeface.NORMAL);
        if ("Personalizada".equals(name)) return Typeface.create(Prefs.get(this).getString("txtFontCustom", "sans-serif"), Typeface.NORMAL);
        return Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
    }
    private void applyWrap() {
        editor.setHorizontallyScrolling(!wrap);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setTextSize(fontSize);
        editor.setTypeface(typefaceFor(fontName));
    }
    private void updateLineNumbers() {
        if (lineNumbers == null || editor == null) return;
        int count = Math.max(1, editor.getText().toString().split("\\n", -1).length);
        StringBuilder b = new StringBuilder();
        for (int i = 1; i <= count; i++) b.append(i).append('\n');
        lineNumbers.setText(b.toString());
    }
    private void loadFile() {
        StringBuilder b = new StringBuilder();
        try (Reader r = new InputStreamReader(new FileInputStream(file), charset)) {
            char[] buf = new char[8192]; int n;
            while ((n = r.read(buf)) >= 0) b.append(buf, 0, n);
            editor.setText(b.toString()); editor.setSelection(0);
        } catch (Exception e) { Toast.makeText(this, "Não foi possível ler o arquivo", Toast.LENGTH_LONG).show(); }
    }
    private void saveFile() {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file), charset)) {
            w.write(editor.getText().toString());
            Toast.makeText(this, "Arquivo salvo", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "Não foi possível salvar: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_SEARCH, 0, "🔍").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add(0, MENU_SAVE, 1, "💾").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add(0, MENU_MORE, 2, "⋮").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return true;
    }
    @Override public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        if (item.getItemId() == MENU_SEARCH) { showSearch(); return true; }
        if (item.getItemId() == MENU_SAVE) { saveFile(); return true; }
        if (item.getItemId() == MENU_MORE) { showMore(); return true; }
        return super.onOptionsItemSelected(item);
    }
    private void showSearch() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("Texto para pesquisar");
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Pesquisar").setView(input)
                .setNegativeButton("Cancelar", null).setPositiveButton("Próximo", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String q = input.getText().toString(); if (q.isEmpty()) return;
            String text = editor.getText().toString(); int at = text.indexOf(q, lastSearch);
            if (at < 0) { lastSearch = 0; at = text.indexOf(q); }
            if (at >= 0) { editor.requestFocus(); editor.setSelection(at, at + q.length()); lastSearch = at + q.length(); }
            else Toast.makeText(this, "Texto não encontrado", Toast.LENGTH_SHORT).show();
        }));
        d.getWindow(); d.show();
    }
    private void showMore() {
        String[] options = {"Visualizador", "Fonte", "Tamanho da fonte", "Codificação", "Sintaxe", "Sair do visualizador"};
        new AlertDialog.Builder(this).setTitle("Mais opções").setItems(options, (d, which) -> {
            switch (which) {
                case 0: showViewerOptions(); break;
                case 1: showFontOptions(); break;
                case 2: showSizeOptions(); break;
                case 3: showEncodingOptions(); break;
                case 4: showSyntaxOptions(); break;
                default: finish();
            }
        }).show();
    }
    private void showViewerOptions() {
        String[] a = {"Mostrar número das linhas", "Quebra de linha"};
        boolean[] checked = {showLines, wrap};
        new AlertDialog.Builder(this).setTitle("Visualizador").setMultiChoiceItems(a, checked, (d, which, on) -> {
            if (which == 0) { showLines = on; lineNumbers.setVisibility(on ? View.VISIBLE : View.GONE); }
            else { wrap = on; applyWrap(); }
            Prefs.get(this).edit().putBoolean("txtLines", showLines).putBoolean("txtWrap", wrap).apply();
        }).setPositiveButton("OK", null).show();
    }
    private void showFontOptions() {
        String[] a = {"Sans Serif", "Serif", "Monospace", "Sans Serif Condensed", "Personalizada"};
        new AlertDialog.Builder(this).setTitle("Fonte").setItems(a, (d, which) -> {
            if (which == 4) {
                EditText e = new EditText(this); e.setHint("Nome da fonte Android, ex.: sans-serif-light");
                new AlertDialog.Builder(this).setTitle("Fonte personalizada").setView(e).setNegativeButton("Cancelar", null).setPositiveButton("Aplicar", (x,w) -> {
                    Prefs.get(this).edit().putString("txtFontCustom", e.getText().toString().trim()).apply(); fontName = "Personalizada"; applyWrap();
                }).show();
            } else { fontName = a[which]; Prefs.get(this).edit().putString("txtFont", fontName).apply(); applyWrap(); }
        }).show();
    }
    private void showSizeOptions() {
        String[] a = new String[9]; for (int i=0;i<a.length;i++) a[i] = String.valueOf(8 + i * 2) + " sp";
        new AlertDialog.Builder(this).setTitle("Tamanho da fonte").setSingleChoiceItems(a, Math.max(0, Math.min(8, (fontSize - 8) / 2)), (d, which) -> { fontSize = 8 + which * 2; Prefs.get(this).edit().putInt("txtFontSize", fontSize).apply(); applyWrap(); d.dismiss(); }).show();
    }
    private void showEncodingOptions() {
        String[] names = {"UTF-8", "ISO-8859-1", "Windows-1252", "UTF-16"};
        new AlertDialog.Builder(this).setTitle("Codificação").setItems(names, (d, which) -> { charset = Charset.forName(names[which]); Prefs.get(this).edit().putString("txtCharset", names[which]).apply(); loadFile(); }).show();
    }
    private void showSyntaxOptions() {
        String[] a = {"Automático", "Texto simples", "JSON", "XML / HTML", "Markdown", "Java / Kotlin"};
        new AlertDialog.Builder(this).setTitle("Sintaxe").setItems(a, (d, which) -> { syntax = a[which]; Prefs.get(this).edit().putString("txtSyntax", syntax).apply(); Toast.makeText(this, "Sintaxe: " + syntax, Toast.LENGTH_SHORT).show(); }).show();
    }
    @Override public void onBackPressed() { saveFile(); super.onBackPressed(); }
}
