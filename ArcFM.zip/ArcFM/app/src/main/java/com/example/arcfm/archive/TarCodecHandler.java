package com.example.arcfm.archive;

import com.example.arcfm.filesystem.FileScanner;
import com.example.arcfm.filesystem.SafePath;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Locale;

/** TAR (puro ou com LZ4/GZ/XZ/BZ2) e arquivos de um só fluxo (.gz, .xz, .bz2, .lz4). */
public class TarCodecHandler extends BaseHandler {
    private final int codec;
    private final String[] tarExt;
    private final String[] singleExt;

    protected TarCodecHandler(ArchiveOptions o, int codec, String[] tarExt, String[] singleExt) {
        super(o);
        this.codec = codec;
        this.tarExt = tarExt;
        this.singleExt = singleExt;
    }

    @Override
    public boolean canRead(File f) {
        return ends(f, tarExt) || ends(f, singleExt);
    }

    @Override
    public String[] getExtensions() {
        String[] r = new String[tarExt.length + singleExt.length];
        System.arraycopy(tarExt, 0, r, 0, tarExt.length);
        System.arraycopy(singleExt, 0, r, tarExt.length, singleExt.length);
        return r;
    }

    /** Nome conhecido como fluxo único => não é TAR; nomes desconhecidos (temporários) são TAR. */
    private boolean isTar(File f) {
        if (ends(f, tarExt)) return true;
        return !ends(f, singleExt);
    }

    // ------------------------------------------------------------------ compactar

    @Override
    public void compress(List<File> inputs, File output, ProgressListener l) throws IOException {
        long total = FileScanner.sizeOf(inputs);
        OutputStream fos = new BufferedOutputStream(new FileOutputStream(output), 64 * 1024);
        OutputStream sink = fos;
        boolean done = false;
        try {
            if (codec != Codecs.NONE) {
                int th = codec == Codecs.LZ4 ? Codecs.lz4Threads(total, o.threads) : o.threads;
                sink = Codecs.wrapOut(fos, codec, o.level, th);
            }
            TarIO.Writer tar = new TarIO.Writer(sink);
            long[] cnt = {0};
            byte[] buf = new byte[64 * 1024];
            for (File f : inputs) addTar(tar, f, f.getName(), output, buf, cnt, total, l);
            checkCancel(l);
            tar.finish();
            sink.close();
            done = true;
        } finally {
            if (!done) {
                if (sink instanceof ParallelLz4Out) ((ParallelLz4Out) sink).abort();
                try {
                    sink.close();
                } catch (IOException ignored) {
                    // incompleto: será apagado
                }
            }
        }
    }

    private void addTar(TarIO.Writer tar, File f, String name, File out, byte[] buf, long[] cnt, long total,
                        ProgressListener l) throws IOException {
        checkCancel(l);
        if (f.getAbsolutePath().equals(out.getAbsolutePath())) return;
        if (f.isDirectory()) {
            tar.putEntry(name, true, 0, f.lastModified(), 0755);
            tar.closeEntry();
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) addTar(tar, k, name + "/" + k.getName(), out, buf, cnt, total, l);
            }
            return;
        }
        if (!f.isFile()) return;
        FileInputStream in;
        try {
            in = new FileInputStream(f);
        } catch (FileNotFoundException e) {
            o.stats.skipped++;
            return;
        }
        try {
            tar.putEntry(name, false, f.length(), f.lastModified(), f.canExecute() ? 0755 : 0644);
            int n;
            while ((n = in.read(buf)) != -1) {
                tar.write(buf, 0, n);
                cnt[0] += n;
                l.onProgress(name, cnt[0], total);
                checkCancel(l);
            }
            tar.closeEntry();
        } finally {
            in.close();
        }
    }

    // ------------------------------------------------------------------ extrair

    @Override
    public void extract(File input, File dest, ProgressListener l) throws IOException {
        if (!dest.exists() && !dest.mkdirs()) throw new IOException("Não foi possível criar a pasta de destino");
        if (!isTar(input)) {
            decompressSingle(input, dest, l);
        } else if (codec != Codecs.NONE && !o.pipe) {
            File scratch = o.scratchDir != null ? o.scratchDir : dest;
            File tmp = File.createTempFile(".arcfm-pipe-", ".tar", scratch);
            try {
                copyDecoded(input, tmp, codec, l);
                extractTar(tmp, dest, Codecs.NONE, l);
            } finally {
                tmp.delete();
            }
        } else {
            extractTar(input, dest, codec, l);
        }
    }

    private void extractTar(File input, File dest, int cod, ProgressListener l) throws IOException {
        long total = input.length();
        TarIO.Counting cin = new TarIO.Counting(new BufferedInputStream(new FileInputStream(input), 64 * 1024));
        InputStream src = null;
        try {
            src = Codecs.wrapIn(cin, cod);
            TarIO.Reader tar = new TarIO.Reader(src);
            o.limits.begin(input.length());
            byte[] buf = new byte[64 * 1024];
            TarIO.Entry e;
            while ((e = tar.next()) != null) {
                checkCancel(l);
                o.limits.entry(e.name, e.size);
                File out = SafePath.resolve(dest, e.name, o.limits);
                if (e.isDir()) {
                    out.mkdirs();
                    continue;
                }
                if (!e.isRegular()) {
                    o.stats.ignored++; // links, dispositivos etc.
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                File target = resolveConflict(out);
                if (target == null) continue;
                boolean ok = false;
                try (OutputStream os = new FileOutputStream(target)) {
                    long got = 0;
                    int n;
                    while ((n = tar.read(buf, 0, buf.length)) != -1) {
                        o.limits.bytes(n);
                        os.write(buf, 0, n);
                        got += n;
                        l.onProgress(e.name, cin.count, total);
                        checkCancel(l);
                    }
                    if (got != e.size) throw new IOException("Arquivo TAR truncado: " + e.name);
                    ok = true;
                } finally {
                    if (!ok) target.delete();
                }
                if (e.mtimeMs > 0) target.setLastModified(e.mtimeMs);
                o.stats.files++;
            }
        } finally {
            Codecs.closeAll(src, cin);
        }
    }

    private void copyDecoded(File input, File out, int cod, ProgressListener l) throws IOException {
        long total = input.length();
        TarIO.Counting cin = new TarIO.Counting(new BufferedInputStream(new FileInputStream(input), 64 * 1024));
        InputStream src = null;
        try {
            src = Codecs.wrapIn(cin, cod);
            o.limits.begin(input.length());
            try (OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = src.read(buf)) != -1) {
                    o.limits.bytes(n);
                    os.write(buf, 0, n);
                    l.onProgress(input.getName(), cin.count, total);
                    checkCancel(l);
                }
            }
        } finally {
            Codecs.closeAll(src, cin);
        }
    }

    private void decompressSingle(File input, File dest, ProgressListener l) throws IOException {
        String n = input.getName();
        for (String e : singleExt) {
            if (n.toLowerCase(Locale.ROOT).endsWith(e)) {
                n = n.substring(0, n.length() - e.length());
                break;
            }
        }
        if (n.isEmpty()) n = "arquivo";
        File out = SafePath.resolve(dest, n, o.limits);
        File target = resolveConflict(out);
        if (target == null) return;
        boolean ok = false;
        try {
            copyDecoded(input, target, codec, l);
            ok = true;
        } finally {
            if (!ok) target.delete();
        }
        o.stats.files++;
    }

    // ------------------------------------------------------------------ testar

    @Override
    public void test(File input, ProgressListener l) throws IOException {
        long total = input.length();
        TarIO.Counting cin = new TarIO.Counting(new BufferedInputStream(new FileInputStream(input), 64 * 1024));
        InputStream src = null;
        try {
            src = Codecs.wrapIn(cin, codec);
            byte[] buf = new byte[64 * 1024];
            if (!isTar(input)) {
                while (src.read(buf) != -1) {
                    l.onProgress(input.getName(), cin.count, total);
                    checkCancel(l);
                }
                return;
            }
            TarIO.Reader tar = new TarIO.Reader(src);
            int count = 0;
            TarIO.Entry e;
            while ((e = tar.next()) != null) {
                checkCancel(l);
                count++;
                if (!e.isRegular()) continue;
                long got = 0;
                int n;
                while ((n = tar.read(buf, 0, buf.length)) != -1) {
                    got += n;
                    l.onProgress(e.name, cin.count, total);
                    checkCancel(l);
                }
                if (got != e.size) throw new IOException("Arquivo TAR truncado: " + e.name);
            }
            if (count == 0) throw new IOException("TAR sem entradas");
        } finally {
            Codecs.closeAll(src, cin);
        }
    }
}
