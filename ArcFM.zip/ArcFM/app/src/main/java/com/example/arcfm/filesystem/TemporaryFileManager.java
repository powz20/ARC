package com.example.arcfm.filesystem;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/** Temporários aleatórios na pasta de destino (mesmo sistema de arquivos => troca atômica). */
public final class TemporaryFileManager {
    private TemporaryFileManager() {
    }

    public static File create(File dir, String suffix) throws IOException {
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Pasta de destino indisponível");
        return File.createTempFile(".arcfm-", suffix == null ? ".tmp" : suffix, dir);
    }

    /** Publica só se o temporário não está vazio e o destino ainda não existe. */
    public static void publish(File tmp, File dest) throws IOException {
        if (tmp.length() <= 0) throw new IOException("A saída ficou vazia");
        if (dest.exists()) throw new IOException("O destino já existe: " + dest.getName());
        try {
            Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            if (!tmp.renameTo(dest)) throw e;
        }
    }

    /** Apaga temporários ".arcfm-*" abandonados (app fechado no meio de uma operação). */
    public static void cleanStale(File dir, long maxAgeMs) {
        File[] fs = dir == null ? null : dir.listFiles();
        if (fs == null) return;
        long now = System.currentTimeMillis();
        for (File f : fs) {
            if (f.isFile() && f.getName().startsWith(".arcfm-") && now - f.lastModified() > maxAgeMs) f.delete();
        }
    }
}
