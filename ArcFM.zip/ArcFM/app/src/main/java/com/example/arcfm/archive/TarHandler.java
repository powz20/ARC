package com.example.arcfm.archive;

public final class TarHandler extends TarCodecHandler {
    public TarHandler(ArchiveOptions o) {
        super(o, Codecs.NONE, new String[]{".tar"}, new String[]{});
    }
}
