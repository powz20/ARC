package com.example.arcfm.zstd;

import java.io.IOException;
import java.io.OutputStream;

/** Compressão zstd em streaming. Fechar grava o fim do frame. */
public final class ZstdOutputStream extends OutputStream {
    private final OutputStream out;
    private final byte[] outBuf = new byte[128 * 1024];
    private long h;
    private boolean closed;

    public ZstdOutputStream(OutputStream out, int level) throws IOException {
        this.out = out;
        this.h = Zstd.nCreateC(level);
    }

    @Override
    public void write(int b) throws IOException {
        write(new byte[]{(byte) b}, 0, 1);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (closed) throw new IOException("ZstdOutputStream fechado");
        int pos = off;
        int rem = len;
        int[] st = new int[2];
        for (;;) {
            Zstd.nCompress(h, b, pos, rem, outBuf, 0, outBuf.length, false, st);
            out.write(outBuf, 0, st[1]);
            pos += st[0];
            rem -= st[0];
            if (rem == 0 && st[1] < outBuf.length) break;
        }
    }

    @Override
    public void close() throws IOException {
        if (closed) return;
        closed = true;
        try {
            int[] st = new int[2];
            for (;;) {
                int hint = Zstd.nCompress(h, outBuf, 0, 0, outBuf, 0, outBuf.length, true, st);
                out.write(outBuf, 0, st[1]);
                if (hint == 0) break;
            }
        } finally {
            Zstd.nFreeC(h);
            h = 0;
            out.close();
        }
    }
}
