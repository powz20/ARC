package com.example.arcfm.archive;

public final class Bzip2Handler extends TarCodecHandler {
    public Bzip2Handler(ArchiveOptions o) {
        super(o, Codecs.BZ2, new String[]{".tar.bz2", ".tbz2", ".tbz"}, new String[]{".bz2"});
    }
}
