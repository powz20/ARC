package com.example.arcfm.zstd;

import java.io.IOException;
import java.io.InputStream;

/** Descompressão zstd em streaming (lê um ou mais frames). */
public final class ZstdInputStream extends InputStream {
    private final InputStream in;
    private final byte[] inBuf = new byte[128 * 1024];
    private final int[] st = new int[2];
    private long h;
    private int inPos;
    private int inLen;
    private boolean eof;
    private boolean closed;

    public ZstdInputStream(InputStream in) throws IOException {
        this.in = in;
        this.h = Zstd.nCreateD();
    }

    @Override
    public int read() throws IOException {
        byte[] one = new byte[1];
        int n = read(one, 0, 1);
        return n < 0 ? -1 : one[0] & 0xFF;
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (closed) throw new IOException("ZstdInputStream fechado");
        if (len == 0) return 0;
        for (;;) {
            if (inPos >= inLen && !eof) {
                int k = in.read(inBuf, 0, inBuf.length);
                if (k < 0) {
                    eof = true;
                    inLen = 0;
                } else {
                    inPos = 0;
                    inLen = k;
                }
            }
            int hint = Zstd.nDecompress(h, inBuf, inPos, inLen - inPos, b, off, len, st);
            inPos += st[0];
            if (st[1] > 0) return st[1];
            if (eof) {
                if (hint != 0) throw new IOException("zstd: arquivo truncado");
                return -1;
            }
        }
    }

    @Override
    public void close() throws IOException {
        if (closed) return;
        closed = true;
        try {
            Zstd.nFreeD(h);
            h = 0;
        } finally {
            in.close();
        }
    }
}
