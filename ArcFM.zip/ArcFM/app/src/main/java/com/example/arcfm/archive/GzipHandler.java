package com.example.arcfm.archive;

public final class GzipHandler extends TarCodecHandler {
    public GzipHandler(ArchiveOptions o) {
        super(o, Codecs.GZ, new String[]{".tar.gz", ".tgz"}, new String[]{".gz"});
    }
}
