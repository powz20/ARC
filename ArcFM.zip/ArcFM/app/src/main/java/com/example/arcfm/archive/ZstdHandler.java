package com.example.arcfm.archive;

/** tar.zst / tzst e .zst de um arquivo só, pela biblioteca nativa zstd (com.example.arcfm.zstd). */
public final class ZstdHandler extends TarCodecHandler {
    public ZstdHandler(ArchiveOptions o) {
        super(o, Codecs.ZST, new String[]{".tar.zst", ".tzst"}, new String[]{".zst"});
    }
}
