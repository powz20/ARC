package com.example.arcfm.archive;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Lista e lê entradas de um arquivo compactado, sem extrair tudo (somente leitura). */
public final class ArchiveLister {
    private ArchiveLister() {
    }

    public static final class Entry {
        /** Nome exatamente como está no arquivo (usado para ler). */
        public final String raw;
        /** Caminho normalizado: sem "./", "/" inicial nem "/" final. */
        public final String path;
        public final boolean dir;
        public final long size;
        public final long mtime;

        Entry(String raw, boolean dir, long size, long mtime) {
            this.raw = raw;
            String n = raw.replace('\\', '/');
            while (n.startsWith("./")) n = n.substring(2);
            while (n.startsWith("/")) n = n.substring(1);
            while (n.endsWith("/")) n = n.substring(0, n.length() - 1);
            this.path = n;
            this.dir = dir;
            this.size = size;
            this.mtime = mtime;
        }
    }

    private static final String[] ZIP_EXT = {".zip", ".jar", ".apk", ".xapk", ".cbz", ".mcaddon", ".mcpack", ".mcworld"};

    private static int tarCodec(String n) {
        if (n.endsWith(".tar.lz4") || n.endsWith(".tlz4")) return Codecs.LZ4;
        if (n.endsWith(".tar.gz") || n.endsWith(".tgz")) return Codecs.GZ;
        if (n.endsWith(".tar.xz") || n.endsWith(".txz")) return Codecs.XZ;
        if (n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".tbz")) return Codecs.BZ2;
        if (n.endsWith(".tar.zst") || n.endsWith(".tzst")) return Codecs.ZST;
        if (n.endsWith(".tar")) return Codecs.NONE;
        return -1;
    }

    private static int singleCodec(String n) {
        if (n.endsWith(".lz4")) return Codecs.LZ4;
        if (n.endsWith(".gz")) return Codecs.GZ;
        if (n.endsWith(".xz")) return Codecs.XZ;
        if (n.endsWith(".bz2")) return Codecs.BZ2;
        if (n.endsWith(".zst")) return Codecs.ZST;
        return -1;
    }

    private static boolean isZip(String n) {
        for (String e : ZIP_EXT) {
            if (n.endsWith(e)) return true;
        }
        return false;
    }

    private static String stripSingleExt(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    public static List<Entry> list(File f, ProgressListener l) throws IOException {
        String n = f.getName().toLowerCase(Locale.ROOT);
        List<Entry> out = new ArrayList<>();
        if (isZip(n)) {
            try (ZipFile zf = new ZipFile(f, StandardCharsets.UTF_8)) {
                for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                    ZipEntry e = en.nextElement();
                    out.add(new Entry(e.getName(), e.isDirectory(), Math.max(0, e.getSize()), e.getTime()));
                }
            }
        } else if (n.endsWith(".7z")) {
            try (SevenZFile sz = SevenZFile.builder().setFile(f).get()) {
                for (SevenZArchiveEntry e : sz.getEntries()) {
                    long t = e.getHasLastModifiedDate() ? e.getLastModifiedDate().getTime() : 0;
                    out.add(new Entry(e.getName(), e.isDirectory(), Math.max(0, e.getSize()), t));
                }
            }
        } else if (tarCodec(n) >= 0) {
            int codec = tarCodec(n);
            TarIO.Counting cin = new TarIO.Counting(new BufferedInputStream(new FileInputStream(f), 65536));
            InputStream src = null;
            try {
                src = Codecs.wrapIn(cin, codec);
                TarIO.Reader tar = new TarIO.Reader(src);
                TarIO.Entry e;
                while ((e = tar.next()) != null) {
                    if (l != null && l.isCancelled()) throw new ArchiveCancelledException();
                    out.add(new Entry(e.name, e.isDir(), e.isRegular() ? e.size : 0, e.mtimeMs));
                }
            } finally {
                Codecs.closeAll(src, cin);
            }
        } else if (singleCodec(n) >= 0) {
            out.add(new Entry(stripSingleExt(f.getName()), false, 0, f.lastModified()));
        } else {
            throw new IOException("Formato não suportado para visualizar: " + f.getName());
        }
        return out;
    }

    /** Copia uma entrada (pelo nome exato em Entry.raw) para 'out'. */
    public static void readEntry(File f, Entry entry, File out, ProgressListener l) throws IOException {
        String n = f.getName().toLowerCase(Locale.ROOT);
        try (OutputStream os = new FileOutputStream(out)) {
            if (isZip(n)) {
                try (ZipFile zf = new ZipFile(f, StandardCharsets.UTF_8)) {
                    ZipEntry ze = zf.getEntry(entry.raw);
                    if (ze == null) throw new IOException("Entrada não encontrada");
                    try (InputStream in = zf.getInputStream(ze)) {
                        copy(in, os, l);
                    }
                }
            } else if (n.endsWith(".7z")) {
                try (SevenZFile sz = SevenZFile.builder().setFile(f).get()) {
                    SevenZArchiveEntry e;
                    while ((e = sz.getNextEntry()) != null) {
                        if (!e.isDirectory() && e.getName().equals(entry.raw)) {
                            copy(new InputStreamOf(sz), os, l);
                            return;
                        }
                    }
                    throw new IOException("Entrada não encontrada");
                }
            } else if (tarCodec(n) >= 0) {
                TarIO.Counting cin = new TarIO.Counting(new BufferedInputStream(new FileInputStream(f), 65536));
                InputStream src = null;
                try {
                    src = Codecs.wrapIn(cin, tarCodec(n));
                    TarIO.Reader tar = new TarIO.Reader(src);
                    TarIO.Entry e;
                    while ((e = tar.next()) != null) {
                        if (e.isRegular() && e.name.equals(entry.raw)) {
                            copy(new InputStreamOf(tar), os, l);
                            return;
                        }
                    }
                    throw new IOException("Entrada não encontrada");
                } finally {
                    Codecs.closeAll(src, cin);
                }
            } else if (singleCodec(n) >= 0) {
                InputStream src = null;
                TarIO.Counting cin = new TarIO.Counting(new BufferedInputStream(new FileInputStream(f), 65536));
                try {
                    src = Codecs.wrapIn(cin, singleCodec(n));
                    copy(src, os, l);
                } finally {
                    Codecs.closeAll(src, cin);
                }
            } else {
                throw new IOException("Formato não suportado");
            }
        }
    }

    private static void copy(InputStream in, OutputStream os, ProgressListener l) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int k;
        while ((k = in.read(buf)) != -1) {
            if (l != null && l.isCancelled()) throw new ArchiveCancelledException();
            os.write(buf, 0, k);
        }
    }

    /** Adaptador: expõe um leitor de entrada atual como InputStream (sem copiar). */
    private static final class InputStreamOf extends InputStream {
        private final InputStream in;

        InputStreamOf(InputStream in) {
            this.in = in;
        }

        InputStreamOf(SevenZFile sz) {
            this.in = new InputStream() {
                @Override
                public int read() throws IOException {
                    byte[] one = new byte[1];
                    int n = sz.read(one, 0, 1);
                    return n < 0 ? -1 : one[0] & 0xFF;
                }

                @Override
                public int read(byte[] b, int off, int len) throws IOException {
                    return sz.read(b, off, len);
                }
            };
        }

        InputStreamOf(TarIO.Reader tar) {
            this.in = new InputStream() {
                @Override
                public int read() throws IOException {
                    byte[] one = new byte[1];
                    int n = tar.read(one, 0, 1);
                    return n < 0 ? -1 : one[0] & 0xFF;
                }

                @Override
                public int read(byte[] b, int off, int len) throws IOException {
                    return tar.read(b, off, len);
                }
            };
        }

        @Override
        public int read() throws IOException {
            return in.read();
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            return in.read(b, off, len);
        }
    }
}
