package com.example.arcfm.archive;

import com.example.arcfm.filesystem.FileScanner;
import com.example.arcfm.filesystem.SafePath;

import org.apache.commons.compress.archivers.zip.ParallelScatterZipCreator;
import org.apache.commons.compress.archivers.zip.Zip64Mode;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.parallel.FileBasedScatterGatherBackingStore;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public final class ZipHandler extends BaseHandler {
    private static final String[] EXT = {".zip", ".jar", ".apk", ".xapk", ".cbz", ".mcaddon", ".mcpack", ".mcworld"};

    public ZipHandler(ArchiveOptions o) {
        super(o);
    }

    @Override
    public boolean canRead(File f) {
        return ends(f, EXT);
    }

    @Override
    public String[] getExtensions() {
        return EXT.clone();
    }

    // ------------------------------------------------------------------ compactar

    @Override
    public void compress(List<File> inputs, File output, ProgressListener l) throws IOException {
        long total = FileScanner.sizeOf(inputs);
        if (o.threads >= 2 && !o.compat) parallel(inputs, output, l, total);
        else single(inputs, output, l, total);
        checkCancel(l);
    }

    private void single(List<File> inputs, File out, ProgressListener l, long total) throws IOException {
        long[] done = {0};
        byte[] buf = new byte[64 * 1024];
        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out), 64 * 1024))) {
            zos.setLevel(Codecs.ZIP_LEVELS[Math.max(0, Math.min(o.level, 5))]);
            for (File f : inputs) add(zos, f, f.getName(), out, buf, done, total, l);
        }
    }

    private void add(ZipOutputStream zos, File f, String name, File out, byte[] buf, long[] done, long total,
                     ProgressListener l) throws IOException {
        checkCancel(l);
        if (f.getAbsolutePath().equals(out.getAbsolutePath())) return;
        if (f.isDirectory()) {
            ZipEntry de = new ZipEntry(name + "/");
            de.setTime(f.lastModified());
            zos.putNextEntry(de);
            zos.closeEntry();
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) add(zos, k, name + "/" + k.getName(), out, buf, done, total, l);
            }
            return;
        }
        if (!f.isFile()) return;
        FileInputStream in;
        try {
            in = new FileInputStream(f);
        } catch (FileNotFoundException e) {
            o.stats.skipped++;
            return;
        }
        try {
            ZipEntry ze = new ZipEntry(name);
            ze.setTime(f.lastModified());
            zos.putNextEntry(ze);
            int n;
            while ((n = in.read(buf)) != -1) {
                zos.write(buf, 0, n);
                done[0] += n;
                l.onProgress(name, done[0], total);
                checkCancel(l);
            }
            zos.closeEntry();
        } finally {
            in.close();
        }
    }

    private static final class CountIn extends FilterInputStream {
        private final String name;
        private final ProgressListener l;
        private final AtomicLong done;
        private final long total;

        CountIn(InputStream in, String name, ProgressListener l, AtomicLong done, long total) {
            super(in);
            this.name = name;
            this.l = l;
            this.done = done;
            this.total = total;
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n < 0 ? -1 : one[0] & 0xFF;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (l.isCancelled()) throw new ArchiveCancelledException();
            int n = super.read(b, off, len);
            if (n > 0) l.onProgress(name, done.addAndGet(n), total);
            return n;
        }
    }

    /** ZIP com várias threads (commons-compress ParallelScatterZipCreator). */
    private void parallel(List<File> inputs, File output, ProgressListener l, long total) throws IOException {
        final AtomicLong done = new AtomicLong();
        final ExecutorService pool = Executors.newFixedThreadPool(o.threads);
        final File scratch = o.scratchDir != null ? o.scratchDir : output.getParentFile();
        ParallelScatterZipCreator creator = new ParallelScatterZipCreator(pool,
                () -> new FileBasedScatterGatherBackingStore(File.createTempFile(".arcfm-scatter", ".tmp", scratch)),
                Codecs.ZIP_LEVELS[Math.max(0, Math.min(o.level, 5))]);
        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(
                new BufferedOutputStream(new FileOutputStream(output), 64 * 1024));
        boolean ok = false;
        try {
            zos.setUseZip64(Zip64Mode.AsNeeded);
            for (File f : inputs) addEntries(creator, f, f.getName(), output, l, done, total);
            creator.writeTo(zos);
            zos.close();
            ok = true;
        } catch (ExecutionException | InterruptedException e) {
            if (l.isCancelled()) throw new ArchiveCancelledException();
            Throwable c = e.getCause() != null ? e.getCause() : e;
            throw new IOException(String.valueOf(c));
        } finally {
            if (!ok) {
                pool.shutdownNow();
                try {
                    zos.close();
                } catch (Exception ignored) {
                    // arquivo incompleto: o temporário será apagado
                }
            }
        }
    }

    private void addEntries(ParallelScatterZipCreator c, final File f, final String name, File output,
                            final ProgressListener l, final AtomicLong done, final long total) throws IOException {
        if (f.getAbsolutePath().equals(output.getAbsolutePath())) return;
        if (f.isDirectory()) {
            ZipArchiveEntry de = new ZipArchiveEntry(name + "/");
            de.setTime(f.lastModified());
            de.setMethod(ZipEntry.STORED);
            de.setSize(0);
            de.setCrc(0);
            c.addArchiveEntry(de, () -> new ByteArrayInputStream(new byte[0]));
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) addEntries(c, k, name + "/" + k.getName(), output, l, done, total);
            }
            return;
        }
        if (!f.isFile()) return;
        ZipArchiveEntry ze = new ZipArchiveEntry(name);
        ze.setTime(f.lastModified());
        ze.setMethod(ZipEntry.DEFLATED);
        ze.setSize(f.length());
        c.addArchiveEntry(ze, () -> {
            try {
                return new CountIn(new FileInputStream(f), name, l, done, total);
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        });
    }

    // ------------------------------------------------------------------ extrair

    @Override
    public void extract(File input, File dest, ProgressListener l) throws IOException {
        ZipFile zf = new ZipFile(input, o.zipCharset);
        try {
            o.limits.begin(input.length());
            long total = 0;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) total += Math.max(0, en.nextElement().getSize());
            if (!dest.exists() && !dest.mkdirs()) throw new IOException("Não foi possível criar a pasta de destino");
            long done = 0;
            byte[] buf = new byte[64 * 1024];
            en = zf.entries();
            while (en.hasMoreElements()) {
                checkCancel(l);
                ZipEntry e = en.nextElement();
                o.limits.entry(e.getName(), e.getSize());
                File out = SafePath.resolve(dest, e.getName(), o.limits);
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                File target = resolveConflict(out);
                if (target == null) {
                    if (e.getSize() > 0) done += e.getSize();
                    continue;
                }
                CRC32 crc = new CRC32();
                boolean ok = false;
                try (InputStream in = zf.getInputStream(e); OutputStream os = new FileOutputStream(target)) {
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        o.limits.bytes(n);
                        os.write(buf, 0, n);
                        crc.update(buf, 0, n);
                        done += n;
                        l.onProgress(e.getName(), done, total);
                        checkCancel(l);
                    }
                    ok = true;
                } finally {
                    if (!ok) target.delete();
                }
                if (o.verifyAfterExtract && e.getCrc() != -1 && crc.getValue() != e.getCrc()) {
                    target.delete();
                    throw new IOException("CRC inválido após extrair: " + e.getName());
                }
                if (e.getTime() > 0) target.setLastModified(e.getTime());
                o.stats.files++;
            }
        } finally {
            zf.close();
        }
    }

    // ------------------------------------------------------------------ testar

    @Override
    public void test(File input, ProgressListener l) throws IOException {
        ZipFile zf = new ZipFile(input, o.zipCharset);
        try {
            long total = 0;
            Enumeration<? extends ZipEntry> en = zf.entries();
            int count = 0;
            while (en.hasMoreElements()) {
                total += Math.max(0, en.nextElement().getSize());
                count++;
            }
            if (count == 0) throw new IOException("ZIP sem entradas");
            long done = 0;
            byte[] buf = new byte[64 * 1024];
            en = zf.entries();
            while (en.hasMoreElements()) {
                checkCancel(l);
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                CRC32 crc = new CRC32();
                try (InputStream in = zf.getInputStream(e)) {
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        crc.update(buf, 0, n);
                        done += n;
                        l.onProgress(e.getName(), done, total);
                        checkCancel(l);
                    }
                }
                if (e.getCrc() != -1 && crc.getValue() != e.getCrc()) {
                    throw new IOException("CRC inválido em " + e.getName());
                }
            }
        } finally {
            zf.close();
        }
    }
}
