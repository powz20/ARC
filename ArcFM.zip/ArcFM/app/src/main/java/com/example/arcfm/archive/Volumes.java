package com.example.arcfm.archive;

import com.example.arcfm.filesystem.TemporaryFileManager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Volumes "nome.ext.001, .002 ..." (divisão e junção simples dos bytes). */
public final class Volumes {
    private Volumes() {
    }

    private static final Pattern P = Pattern.compile("^(.*)\\.(\\d{3})$");

    public static boolean isVolume(File f) {
        return P.matcher(f.getName()).matches();
    }

    public static boolean isFirst(File f) {
        Matcher m = P.matcher(f.getName());
        return m.matches() && m.group(2).equals("001");
    }

    /** "nome.zip.001" -> "nome.zip" (só o nome, para descobrir o formato). */
    public static File virtualBase(File f) {
        Matcher m = P.matcher(f.getName());
        return m.matches() ? new File(f.getParentFile(), m.group(1)) : f;
    }

    private static String partName(String base, int i) {
        return base + "." + String.format(Locale.US, "%03d", i);
    }

    public static List<File> parts(File first) {
        List<File> out = new ArrayList<>();
        File base = virtualBase(first);
        for (int i = 1; i <= 999; i++) {
            File p = new File(base.getParentFile(), partName(base.getName(), i));
            if (!p.isFile()) break;
            out.add(p);
        }
        return out;
    }

    public static void join(File first, File out, ProgressListener l) throws IOException {
        List<File> ps = parts(first);
        long total = 0;
        for (File p : ps) total += p.length();
        long done = 0;
        byte[] buf = new byte[1 << 20];
        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
            for (File p : ps) {
                try (InputStream in = new BufferedInputStream(new FileInputStream(p), 1 << 16)) {
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        os.write(buf, 0, n);
                        done += n;
                        l.onProgress("Juntando volumes", done, total);
                        if (l.isCancelled()) throw new ArchiveCancelledException();
                    }
                }
            }
        }
    }

    /** Divide src em volumes de volumeBytes e publica finalBase + ".001", ".002"... */
    public static List<File> split(File src, File finalBase, long volumeBytes, ProgressListener l) throws IOException {
        long len = src.length();
        long count = (len + volumeBytes - 1) / volumeBytes;
        if (count > 999) throw new IOException("Volumes demais (máximo 999): aumente o tamanho do volume");
        File dir = finalBase.getParentFile();
        List<File> tmps = new ArrayList<>();
        List<File> finals = new ArrayList<>();
        for (int i = 1; i <= count; i++) {
            File f = new File(dir, partName(finalBase.getName(), i));
            if (f.exists()) throw new IOException("Já existe: " + f.getName());
            finals.add(f);
        }
        boolean ok = false;
        try (InputStream in = new BufferedInputStream(new FileInputStream(src), 1 << 16)) {
            byte[] buf = new byte[1 << 20];
            long done = 0;
            for (int i = 0; i < count; i++) {
                File t = TemporaryFileManager.create(dir, ".part");
                tmps.add(t);
                long left = Math.min(volumeBytes, len - (long) i * volumeBytes);
                try (OutputStream os = new BufferedOutputStream(new FileOutputStream(t), 1 << 16)) {
                    while (left > 0) {
                        int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                        if (n < 0) throw new IOException("Arquivo menor do que o esperado");
                        os.write(buf, 0, n);
                        left -= n;
                        done += n;
                        l.onProgress("Dividindo em volumes", done, len);
                        if (l.isCancelled()) throw new ArchiveCancelledException();
                    }
                }
            }
            for (int i = 0; i < count; i++) TemporaryFileManager.publish(tmps.get(i), finals.get(i));
            ok = true;
        } finally {
            for (File t : tmps) t.delete();
            if (!ok) for (File f : finals) f.delete();
        }
        return finals;
    }
}
