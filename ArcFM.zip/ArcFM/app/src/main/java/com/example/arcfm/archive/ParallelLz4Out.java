package com.example.arcfm.archive;

import net.jpountz.lz4.LZ4Compressor;
import net.jpountz.xxhash.XXHashFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * Escritor LZ4 Frame (mesmo formato do LZ4FrameOutputStream: blocos independentes de 4 MB, sem
 * checksum de conteúdo) com compressão de blocos em paralelo. Só é usado para arquivos grandes;
 * o restante usa o LZ4FrameOutputStream direto.
 *
 * Os blocos passam por um anel de (threads + 1) slots reutilizáveis: nenhum byte[] é alocado por bloco
 * e a memória fica limitada. Os blocos são gravados na ordem original.
 */
public final class ParallelLz4Out extends OutputStream {
    private static final int BLOCK = 4 << 20;
    private static final int MAX_THREADS = 4;

    private final OutputStream out;
    private final int slotCount;
    private final Slot[] slots;
    private final Object lock = new Object();
    private final ExecutorService pool;
    private final ThreadLocal<LZ4Compressor> compressors;

    private Slot filling;   // bloco em preenchimento
    private long seq;       // número do bloco em preenchimento
    private long nextWrite; // próximo bloco a gravar
    private IOException failure;
    private volatile boolean aborted;
    private boolean closed;

    private static final class Slot {
        final byte[] in = new byte[BLOCK];
        final byte[] out;
        int len;       // bytes de entrada
        int outLen;    // bytes gerados (cabeçalho de 4 + dados)
        boolean busy;  // despachado e ainda não gravado
        boolean ready; // compressão terminada

        Slot(int outCap) {
            out = new byte[outCap];
        }
    }

    /**
     * @param level   1..5 (mesmo significado de Codecs.lz4Compressor)
     * @param threads 2..4; valores fora disso são limitados. Escreve o cabeçalho do frame.
     */
    public ParallelLz4Out(OutputStream out, int level, int threads) throws IOException {
        this.out = out;
        final int lv = Math.max(1, Math.min(level, 5));
        int th = Math.max(2, Math.min(threads, Math.min(MAX_THREADS, Runtime.getRuntime().availableProcessors())));
        this.slotCount = th + 1;
        this.compressors = ThreadLocal.withInitial(() -> Codecs.lz4Compressor(lv));
        int cap = Codecs.lz4Compressor(lv).maxCompressedLength(BLOCK) + 4;
        this.slots = new Slot[slotCount];
        for (int i = 0; i < slotCount; i++) slots[i] = new Slot(cap);
        this.pool = Executors.newFixedThreadPool(th, new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "arcfm-lz4");
                t.setDaemon(true);
                return t;
            }
        });

        byte flg = 0x60; // versão 01, blocos independentes, sem checksums
        byte bd = 0x70;  // blocos de até 4 MB (igual ao LZ4FrameOutputStream)
        int hc = (XXHashFactory.fastestInstance().hash32().hash(new byte[]{flg, bd}, 0, 2, 0) >> 8) & 0xFF;
        out.write(new byte[]{0x04, 0x22, 0x4D, 0x18, flg, bd, (byte) hc});
    }

    @Override
    public void write(int b) throws IOException {
        byte[] one = {(byte) b};
        write(one, 0, 1);
    }

    @Override
    public void write(byte[] b, int off, int n) throws IOException {
        checkOpen();
        while (n > 0) {
            if (filling == null) {
                // o slot que será usado recebeu o bloco seq - slotCount: ele precisa já ter sido gravado
                writeUntil(seq - slotCount + 1);
                filling = slots[(int) (seq % slotCount)];
                filling.len = 0;
            }
            int k = Math.min(n, BLOCK - filling.len);
            System.arraycopy(b, off, filling.in, filling.len, k);
            filling.len += k;
            off += k;
            n -= k;
            if (filling.len == BLOCK) {
                dispatch(filling);
                filling = null;
                seq++;
            }
        }
    }

    private void checkOpen() throws IOException {
        if (closed) throw new IOException("Escritor LZ4 já fechado");
        if (aborted) throw new ArchiveCancelledException();
    }

    private void dispatch(final Slot s) throws IOException {
        synchronized (lock) {
            s.busy = true;
            s.ready = false;
        }
        try {
            pool.execute(() -> compress(s));
        } catch (RuntimeException e) {
            // pool recusou a tarefa (encerrado): comprime aqui mesmo
            compress(s);
        }
    }

    /** Roda numa thread do pool. Nunca lança: o erro vai para 'failure'. */
    private void compress(Slot s) {
        IOException err = null;
        try {
            if (!aborted) {
                LZ4Compressor c = compressors.get();
                int n = s.len;
                int cl = c.compress(s.in, 0, n, s.out, 4);
                int header;
                if (cl >= n) { // incompressível: guarda sem comprimir (bit alto do tamanho)
                    System.arraycopy(s.in, 0, s.out, 4, n);
                    header = n | 0x80000000;
                    cl = n;
                } else {
                    header = cl;
                }
                s.out[0] = (byte) header;
                s.out[1] = (byte) (header >>> 8);
                s.out[2] = (byte) (header >>> 16);
                s.out[3] = (byte) (header >>> 24);
                s.outLen = 4 + cl;
            }
        } catch (Throwable t) {
            err = new IOException("Erro ao comprimir bloco LZ4: " + t);
        }
        synchronized (lock) {
            if (err != null && failure == null) failure = err;
            s.ready = true;
            lock.notifyAll();
        }
    }

    /** Grava, em ordem, todos os blocos com número menor que 'limit'. */
    private void writeUntil(long limit) throws IOException {
        while (nextWrite < limit) {
            Slot s = slots[(int) (nextWrite % slotCount)];
            synchronized (lock) {
                while (!s.ready && failure == null && !aborted) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new ArchiveCancelledException();
                    }
                }
                if (failure != null) throw failure;
                if (aborted) throw new ArchiveCancelledException();
            }
            out.write(s.out, 0, s.outLen);
            synchronized (lock) {
                s.busy = false;
            }
            nextWrite++;
        }
    }

    /** Cancelamento ou erro: não grava mais nada e encerra as threads. Quem chama fecha o stream. */
    public void abort() {
        aborted = true;
        synchronized (lock) {
            lock.notifyAll();
        }
        pool.shutdownNow();
    }

    @Override
    public void close() throws IOException {
        if (closed) return;
        closed = true;
        try {
            if (!aborted) {
                if (filling != null) {
                    dispatch(filling);
                    filling = null;
                    seq++;
                }
                writeUntil(seq);
                out.write(new byte[4]); // marca de fim do frame
            }
        } finally {
            pool.shutdownNow();
            try {
                pool.awaitTermination(5, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            out.close();
        }
    }
}
