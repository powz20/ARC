package com.example.arcfm.archive;

import java.io.IOException;

public class ArchiveCancelledException extends IOException {
    public ArchiveCancelledException() {
        super("Operação cancelada");
    }
}
