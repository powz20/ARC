package com.example.arcfm.archive;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Leitor e escritor TAR mínimos, sem dependências.
 * Lê: ustar, GNU (nomes longos "L") e pax ("x"/"g"), tamanhos em base-256.
 * Escreve: ustar, com cabeçalho pax quando o nome passa de 100 bytes ou o arquivo de 8 GiB.
 */
public final class TarIO {
    private TarIO() {
    }

    static final int BLOCK = 512;
    private static final long MAX_OCTAL_11 = 077777777777L; // maior valor em 11 dígitos octais
    private static final int MAX_META = 1 << 20;            // limite para nomes longos / pax

    // ------------------------------------------------------------------ entrada

    public static final class Entry {
        public String name;
        public long size;
        public long mtimeMs;
        public int mode;
        public char type;

        public boolean isDir() {
            return type == '5' || ((type == '0' || type == '\0') && name.endsWith("/"));
        }

        public boolean isRegular() {
            return (type == '0' || type == '\0' || type == '7') && !name.endsWith("/");
        }
    }

    /** Conta quantos bytes foram lidos do fluxo de baixo (usado para a barra de progresso). */
    public static final class Counting extends FilterInputStream {
        public long count;

        public Counting(InputStream in) {
            super(in);
        }

        @Override
        public int read() throws IOException {
            int b = super.read();
            if (b >= 0) count++;
            return b;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int n = super.read(b, off, len);
            if (n > 0) count += n;
            return n;
        }

        @Override
        public long skip(long n) throws IOException {
            long s = super.skip(n);
            if (s > 0) count += s;
            return s;
        }
    }

    public static final class Reader {
        private final InputStream in;
        private final byte[] block = new byte[BLOCK];
        private final byte[] skipBuf = new byte[64 * 1024];
        private long remaining;
        private int padding;

        public Reader(InputStream in) {
            this.in = in;
        }

        /** Próxima entrada, ou null no fim do arquivo. Os dados anteriores não lidos são descartados. */
        public Entry next() throws IOException {
            skipFully(remaining + padding);
            remaining = 0;
            padding = 0;

            String longName = null;
            Map<String, String> pax = new HashMap<>();

            while (true) {
                if (!readBlock()) return null;
                if (isZero(block)) return null;
                verifyChecksum();

                char type = (char) (block[156] & 0xFF);
                long size = parseNumber(block, 124, 12);

                if (type == 'L' || type == 'K' || type == 'x' || type == 'g') {
                    if (size < 0 || size > MAX_META) {
                        throw new IOException("Cabeçalho TAR grande demais");
                    }
                    byte[] data = new byte[(int) size];
                    readFully(data, data.length);
                    skipFully((BLOCK - (size % BLOCK)) % BLOCK);
                    if (type == 'L') {
                        longName = cstring(data, 0, data.length);
                    } else if (type == 'x') {
                        parsePax(data, pax);
                    }
                    continue;
                }

                Entry e = new Entry();
                e.type = type;
                e.size = size;
                e.mtimeMs = parseNumber(block, 136, 12) * 1000L;
                e.mode = (int) parseNumber(block, 100, 8);
                e.name = headerName();
                if (longName != null) e.name = longName;

                String v = pax.get("path");
                if (v != null) e.name = v;
                v = pax.get("size");
                if (v != null) e.size = Long.parseLong(v.trim());
                v = pax.get("mtime");
                if (v != null) {
                    try {
                        e.mtimeMs = (long) (Double.parseDouble(v.trim()) * 1000.0);
                    } catch (NumberFormatException ignored) {
                    }
                }

                boolean noData = type >= '1' && type <= '6';
                remaining = noData ? 0 : e.size;
                if (noData) e.size = 0;
                padding = (int) ((BLOCK - (remaining % BLOCK)) % BLOCK);
                return e;
            }
        }

        /** Lê dados da entrada atual; -1 ao terminar. */
        public int read(byte[] b, int off, int len) throws IOException {
            if (remaining <= 0) return -1;
            int n = in.read(b, off, (int) Math.min(len, remaining));
            if (n < 0) throw new EOFException("Arquivo TAR truncado");
            remaining -= n;
            return n;
        }

        private boolean readBlock() throws IOException {
            int got = 0;
            while (got < BLOCK) {
                int n = in.read(block, got, BLOCK - got);
                if (n < 0) {
                    if (got == 0) return false;
                    throw new EOFException("Arquivo TAR truncado");
                }
                got += n;
            }
            return true;
        }

        private void readFully(byte[] b, int len) throws IOException {
            int got = 0;
            while (got < len) {
                int n = in.read(b, got, len - got);
                if (n < 0) throw new EOFException("Arquivo TAR truncado");
                got += n;
            }
        }

        private void skipFully(long n) throws IOException {
            while (n > 0) {
                int r = in.read(skipBuf, 0, (int) Math.min(skipBuf.length, n));
                if (r < 0) throw new EOFException("Arquivo TAR truncado");
                n -= r;
            }
        }

        private String headerName() {
            String name = cstring(block, 0, 100);
            boolean posix = block[257] == 'u' && block[258] == 's' && block[259] == 't'
                    && block[260] == 'a' && block[261] == 'r' && block[262] == 0;
            if (posix) {
                String prefix = cstring(block, 345, 155);
                if (!prefix.isEmpty()) return prefix + "/" + name;
            }
            return name;
        }

        private void verifyChecksum() throws IOException {
            long stored = parseNumber(block, 148, 8);
            long unsigned = 0;
            long signed = 0;
            for (int i = 0; i < BLOCK; i++) {
                int b = (i >= 148 && i < 156) ? ' ' : block[i];
                unsigned += b & 0xFF;
                signed += b;
            }
            if (stored != unsigned && stored != signed) {
                throw new IOException("Cabeçalho TAR inválido (o arquivo está corrompido ou não é TAR)");
            }
        }
    }

    private static boolean isZero(byte[] b) {
        for (byte x : b) {
            if (x != 0) return false;
        }
        return true;
    }

    private static String cstring(byte[] b, int off, int max) {
        int end = off;
        int limit = Math.min(b.length, off + max);
        while (end < limit && b[end] != 0) end++;
        return new String(b, off, end - off, StandardCharsets.UTF_8);
    }

    private static long parseNumber(byte[] b, int off, int len) throws IOException {
        if ((b[off] & 0x80) != 0) { // base-256
            long v = b[off] & 0x7F;
            for (int i = 1; i < len; i++) {
                v = (v << 8) | (b[off + i] & 0xFF);
                if (v < 0) throw new IOException("Número grande demais no cabeçalho TAR");
            }
            return v;
        }
        int i = off;
        int end = off + len;
        while (i < end && (b[i] == ' ' || b[i] == 0)) i++;
        long v = 0;
        while (i < end && b[i] >= '0' && b[i] <= '7') {
            v = (v << 3) | (b[i] - '0');
            i++;
        }
        while (i < end) {
            if (b[i] != ' ' && b[i] != 0) {
                throw new IOException("Número inválido no cabeçalho TAR");
            }
            i++;
        }
        return v;
    }

    private static void parsePax(byte[] data, Map<String, String> out) throws IOException {
        int pos = 0;
        while (pos < data.length) {
            int sp = pos;
            int len = 0;
            while (sp < data.length && data[sp] != ' ') {
                if (data[sp] < '0' || data[sp] > '9') throw new IOException("Cabeçalho pax inválido");
                len = len * 10 + (data[sp] - '0');
                sp++;
            }
            int contentStart = sp + 1;
            int contentEnd = pos + len - 1; // sem o '\n'
            if (sp >= data.length || len <= 0 || contentEnd > data.length || contentEnd < contentStart) {
                throw new IOException("Cabeçalho pax inválido");
            }
            String rec = new String(data, contentStart, contentEnd - contentStart, StandardCharsets.UTF_8);
            int eq = rec.indexOf('=');
            if (eq > 0) out.put(rec.substring(0, eq), rec.substring(eq + 1));
            pos += len;
        }
    }

    // ------------------------------------------------------------------ saída

    public static final class Writer {
        private final OutputStream out;
        private long remaining;
        private int pad;
        private boolean open;

        public Writer(OutputStream out) {
            this.out = out;
        }

        public void putEntry(String name, boolean dir, long size, long mtimeMs, int mode) throws IOException {
            if (open) throw new IOException("A entrada anterior não foi fechada");
            if (dir && !name.endsWith("/")) name = name + "/";
            long dataSize = dir ? 0 : size;
            long mtime = Math.max(0, mtimeMs / 1000);
            byte[] nameBytes = name.getBytes(StandardCharsets.UTF_8);

            ByteArrayOutputStream pax = new ByteArrayOutputStream();
            if (nameBytes.length > 100) writeRecord(pax, "path", name);
            if (dataSize > MAX_OCTAL_11) writeRecord(pax, "size", Long.toString(dataSize));
            if (pax.size() > 0) {
                byte[] data = pax.toByteArray();
                out.write(header("PaxHeader/entry".getBytes(StandardCharsets.UTF_8),
                        data.length, mtime, 0644, 'x'));
                out.write(data);
                int p = (int) ((BLOCK - (data.length % BLOCK)) % BLOCK);
                if (p > 0) out.write(new byte[p]);
            }

            byte[] shortName = nameBytes;
            if (shortName.length > 100) {
                int cut = 100;
                while (cut > 0 && (nameBytes[cut] & 0xC0) == 0x80) cut--; // não corta no meio de um caractere
                shortName = Arrays.copyOf(nameBytes, cut);
            }
            out.write(header(shortName, Math.min(dataSize, MAX_OCTAL_11), mtime, mode, dir ? '5' : '0'));

            remaining = dataSize;
            pad = (int) ((BLOCK - (remaining % BLOCK)) % BLOCK);
            open = true;
        }

        public void write(byte[] b, int off, int len) throws IOException {
            if (!open || len > remaining) throw new IOException("Dados além do tamanho declarado no TAR");
            out.write(b, off, len);
            remaining -= len;
        }

        public void closeEntry() throws IOException {
            if (!open) return;
            if (remaining != 0) {
                throw new IOException("O tamanho do arquivo mudou durante a compactação");
            }
            if (pad > 0) out.write(new byte[pad]);
            open = false;
        }

        public void finish() throws IOException {
            out.write(new byte[BLOCK * 2]);
        }
    }

    private static void writeRecord(ByteArrayOutputStream out, String key, String value) throws IOException {
        byte[] kv = (" " + key + "=" + value + "\n").getBytes(StandardCharsets.UTF_8);
        int digits = 1;
        int total;
        while (true) {
            total = kv.length + digits;
            if (Integer.toString(total).length() == digits) break;
            digits++;
        }
        out.write(Integer.toString(total).getBytes(StandardCharsets.US_ASCII));
        out.write(kv);
    }

    private static byte[] header(byte[] name, long size, long mtime, int mode, char type) {
        byte[] h = new byte[BLOCK];
        System.arraycopy(name, 0, h, 0, Math.min(name.length, 100));
        octal(h, 100, 8, mode & 07777);
        octal(h, 108, 8, 0);
        octal(h, 116, 8, 0);
        octal(h, 124, 12, size);
        octal(h, 136, 12, Math.min(mtime, MAX_OCTAL_11));
        Arrays.fill(h, 148, 156, (byte) ' ');
        h[156] = (byte) type;
        byte[] magic = {'u', 's', 't', 'a', 'r', 0, '0', '0'};
        System.arraycopy(magic, 0, h, 257, magic.length);
        octal(h, 329, 8, 0);
        octal(h, 337, 8, 0);

        long sum = 0;
        for (byte b : h) sum += b & 0xFF;
        String s = Long.toOctalString(sum);
        while (s.length() < 6) s = "0" + s;
        for (int i = 0; i < 6; i++) h[148 + i] = (byte) s.charAt(i);
        h[154] = 0;
        h[155] = ' ';
        return h;
    }

    private static void octal(byte[] h, int off, int len, long v) {
        int digits = len - 1;
        String s = Long.toOctalString(v);
        while (s.length() < digits) s = "0" + s;
        for (int i = 0; i < digits; i++) {
            h[off + i] = (byte) s.charAt(s.length() - digits + i);
        }
        h[off + digits] = 0;
    }
}
