package com.example.arcfm.archive;

import com.example.arcfm.filesystem.FileLimits;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public final class ArchiveOptions {
    public static final int REPLACE = 0;
    public static final int SKIP = 1;
    public static final int KEEP_BOTH = 2;

    public interface ConflictResolver {
        int resolve(File existing);
    }

    public static final class Stats {
        public int files;
        public int skipped;
        public int ignored;
        public long partialOut;

        public String summary() {
            String m = files + " arquivo(s) extraído(s)";
            if (skipped > 0) m += ", " + skipped + " ignorado(s)";
            if (ignored > 0) m += ", " + ignored + " link(s)/item(ns) especial(is) não suportado(s)";
            return m;
        }
    }

    public int level = 3;                       // índice 0..5 (Sem compressão ... Ultra)
    public int threads = 1;
    public String method7z = "LZMA2";
    public boolean compat;                      // perfil "Compatibilidade"
    public Charset zipCharset = StandardCharsets.UTF_8;
    public char[] password;                     // só para ler 7z protegido
    public ConflictResolver conflicts;          // null = substitui
    public FileLimits limits = new FileLimits();
    public File scratchDir;                     // onde ficam temporários grandes
    public boolean verifyAfterExtract = true;
    public boolean pipe = true;
    public long volumeBytes;                    // 0 = não dividir
    public final Stats stats = new Stats();
}
