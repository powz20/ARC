package com.example.arcfm.task;

import com.example.arcfm.archive.ProgressListener;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/** Uma operação (compactar, extrair, testar...). Não guarda referência à Activity. */
public class ArchiveTask implements ProgressListener {
    public interface Listener {
        void onChanged(TaskProgress p);
    }

    private static final AtomicLong IDS = new AtomicLong();

    public final long id = IDS.incrementAndGet();
    public volatile String format = "";
    public volatile String input = "";
    public volatile String output = "";

    private volatile TaskState state = TaskState.AGUARDANDO;
    private volatile long total;
    private volatile long processed;
    private volatile String error;
    private volatile String cancelReason;
    private volatile Listener listener;
    private final AtomicBoolean cancel = new AtomicBoolean();
    private volatile boolean paused;
    private long startedAt;
    private long finishedAt;
    private long lastNotify;
    private long lastSpeedT;
    private long lastSpeedBytes;
    private volatile long speed;

    public void setListener(Listener l) {
        this.listener = l;
    }

    public TaskState getState() {
        return state;
    }

    public synchronized void start() {
        startedAt = System.currentTimeMillis();
        lastSpeedT = startedAt;
        state = TaskState.EXECUTANDO;
        notifyNow();
    }

    public void cancel(String reason) {
        cancelReason = reason;
        cancel.set(true);
        if (!state.finished()) state = TaskState.CANCELANDO;
        synchronized (this) {
            paused = false;
            notifyAll();
        }
        notifyNow();
    }

    public synchronized void pause() {
        if (state == TaskState.EXECUTANDO) {
            paused = true;
            state = TaskState.PAUSADO;
            notifyNow();
        }
    }

    public synchronized void resume() {
        if (state == TaskState.PAUSADO) {
            paused = false;
            state = TaskState.EXECUTANDO;
            notifyAll();
            notifyNow();
        }
    }

    public boolean isPaused() {
        return paused;
    }

    @Override
    public boolean isCancelled() {
        return cancel.get();
    }

    /** Chamado por bloco, nunca por byte. */
    @Override
    public void onProgress(String label, long done, long total) {
        if (paused) {
            synchronized (this) {
                while (paused && !cancel.get()) {
                    try {
                        wait(200);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
            }
        }
        this.processed = done;
        this.total = total;
        long now = System.currentTimeMillis();
        if (now - lastNotify >= 100) {
            long dt = now - lastSpeedT;
            if (dt >= 500) {
                long v = (done - lastSpeedBytes) * 1000 / dt;
                speed = speed == 0 ? v : (speed * 3 + v) / 4;
                lastSpeedT = now;
                lastSpeedBytes = done;
            }
            lastNotify = now;
            notifyNow();
        }
    }

    public void finishOk() {
        finishedAt = System.currentTimeMillis();
        state = cancel.get() ? TaskState.CANCELADO : TaskState.CONCLUIDO;
        notifyNow();
    }

    public void finishFailed(Throwable t) {
        finishedAt = System.currentTimeMillis();
        error = t.getClass().getSimpleName() + ": " + t.getMessage();
        state = cancel.get() ? TaskState.CANCELADO : TaskState.FALHOU;
        notifyNow();
    }

    public void finishCancelled() {
        finishedAt = System.currentTimeMillis();
        if (cancelReason == null) cancelReason = "Cancelado";
        state = TaskState.CANCELADO;
        notifyNow();
    }

    public TaskProgress snapshot() {
        long end = finishedAt > 0 ? finishedAt : System.currentTimeMillis();
        long el = startedAt > 0 ? end - startedAt : 0;
        return new TaskProgress(id, state, format, input, output, total, processed, speed, el, error, cancelReason);
    }

    public String getCancelReason() {
        return cancelReason;
    }

    private void notifyNow() {
        Listener l = listener;
        if (l != null) l.onChanged(snapshot());
    }
}
