package com.example.arcfm.filesystem;

import java.io.File;

public final class FileNames {
    private FileNames() {
    }

    public static File unique(File dir, String base, String ext) {
        File f = new File(dir, base + ext);
        for (int i = 2; f.exists(); i++) f = new File(dir, base + " (" + i + ")" + ext);
        return f;
    }

    /** Outro nome livre na mesma pasta ("nome (2).ext"). */
    public static File sibling(File f) {
        String n = f.getName();
        int dot = n.lastIndexOf('.');
        File dir = f.getParentFile();
        if (dot > 0) return unique(dir, n.substring(0, dot), n.substring(dot));
        return unique(dir, n, "");
    }
}
