package com.example.arcfm.filesystem;

import java.io.File;
import java.util.List;

public final class FileScanner {
    private FileScanner() {
    }

    public static long sizeOf(File f) {
        if (f.isFile()) return f.length();
        long s = 0;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) s += sizeOf(k);
        }
        return s;
    }

    public static long sizeOf(List<File> items) {
        long s = 0;
        for (File f : items) s += sizeOf(f);
        return s;
    }

    public static void deleteTree(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) deleteTree(k);
            }
        }
        f.delete();
    }
}
