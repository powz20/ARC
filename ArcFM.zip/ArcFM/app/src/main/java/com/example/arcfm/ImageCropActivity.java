package com.example.arcfm;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Recorte visual: usa os mesmos gestos do visualizador, mas salva somente a área marcada. */
public class ImageCropActivity extends Activity {
    private ImageView image;
    private CropOverlay overlay;
    private Bitmap bmp;
    private final Matrix matrix = new Matrix();
    private float minScale = 1f;
    private ScaleGestureDetector scaleDetector;
    private android.view.GestureDetector gestureDetector;
    private boolean toolbarMode;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        toolbarMode = "toolbar".equals(getIntent().getStringExtra("mode"));
        Uri uri = getIntent().getData();
        if (uri == null) { finish(); return; }
        try {
            android.graphics.BitmapFactory.Options bounds = new android.graphics.BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            java.io.InputStream first = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(first, null, bounds);
            if (first != null) first.close();
            int sample = 1;
            while (Math.max(bounds.outWidth, bounds.outHeight) / sample > 4096) sample *= 2;
            android.graphics.BitmapFactory.Options options = new android.graphics.BitmapFactory.Options();
            options.inSampleSize = sample;
            java.io.InputStream second = getContentResolver().openInputStream(uri);
            bmp = BitmapFactory.decodeStream(second, null, options);
            if (second != null) second.close();
        } catch (Exception ignored) { }
        if (bmp == null) {
            Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.MATRIX);
        image.setImageBitmap(bmp);
        root.addView(image, new FrameLayout.LayoutParams(-1, -1));
        overlay = new CropOverlay(this);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(dp(12), dp(8), dp(12), dp(8));
        actions.setBackgroundColor(0xDD101010);
        TextView title = new TextView(this);
        title.setText(toolbarMode ? "Selecione a área da barra" : "Selecione o wallpaper");
        title.setTextColor(Color.WHITE); title.setTextSize(15); title.setGravity(Gravity.CENTER_VERTICAL);
        actions.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button cancel = new Button(this); cancel.setText("Cancelar");
        Button apply = new Button(this); apply.setText("Aplicar");
        actions.addView(cancel); actions.addView(apply);
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(actions, alp);
        cancel.setOnClickListener(v -> finish());
        apply.setOnClickListener(v -> saveCrop());
        setContentView(root);

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float cur = currentScale();
                float target = Math.max(minScale, Math.min(cur * d.getScaleFactor(), minScale * 12f));
                matrix.postScale(target / cur, target / cur, d.getFocusX(), d.getFocusY());
                applyMatrix(); return true;
            }
        });
        gestureDetector = new android.view.GestureDetector(this, new android.view.GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                matrix.postTranslate(-dx, -dy); applyMatrix(); return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                float cur = currentScale();
                float target = cur > minScale * 1.5f ? minScale : minScale * 3f;
                matrix.postScale(target / cur, target / cur, e.getX(), e.getY());
                applyMatrix(); return true;
            }
        });
        image.setOnTouchListener((v, e) -> { scaleDetector.onTouchEvent(e); gestureDetector.onTouchEvent(e); return true; });
        image.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override public void onGlobalLayout() {
                image.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                fit();
            }
        });
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private float currentScale() { float[] v = new float[9]; matrix.getValues(v); return v[Matrix.MSCALE_X]; }
    private void fit() {
        if (image.getWidth() == 0 || image.getHeight() == 0) return;
        float s = Math.min((float) image.getWidth() / bmp.getWidth(), (float) image.getHeight() / bmp.getHeight());
        minScale = s; matrix.reset(); matrix.postScale(s, s);
        matrix.postTranslate((image.getWidth() - bmp.getWidth() * s) / 2f, (image.getHeight() - bmp.getHeight() * s) / 2f);
        applyMatrix();
    }
    private void applyMatrix() { keepInside(); image.setImageMatrix(matrix); overlay.invalidate(); }
    private void keepInside() {
        RectF r = new RectF(0, 0, bmp.getWidth(), bmp.getHeight()); matrix.mapRect(r);
        float dx = r.width() <= image.getWidth() ? (image.getWidth() - r.width()) / 2f - r.left : (r.left > 0 ? -r.left : (r.right < image.getWidth() ? image.getWidth() - r.right : 0));
        float dy = r.height() <= image.getHeight() ? (image.getHeight() - r.height()) / 2f - r.top : (r.top > 0 ? -r.top : (r.bottom < image.getHeight() ? image.getHeight() - r.bottom : 0));
        matrix.postTranslate(dx, dy);
    }
    private RectF cropFrame() {
        float margin = dp(18), top = dp(50), bottom = dp(76);
        float w = getResources().getDisplayMetrics().widthPixels - 2 * margin;
        float ratio = toolbarMode ? (float) getResources().getDisplayMetrics().widthPixels / Math.max(1, dp(68))
                : (float) getResources().getDisplayMetrics().widthPixels / Math.max(1, getResources().getDisplayMetrics().heightPixels);
        float h = w / ratio;
        if (!toolbarMode) { h = getResources().getDisplayMetrics().heightPixels - top - bottom; w = h * ratio; }
        float left = (getResources().getDisplayMetrics().widthPixels - w) / 2f;
        float y = toolbarMode ? (getResources().getDisplayMetrics().heightPixels - h) / 2f : top;
        return new RectF(left, y, left + w, y + h);
    }
    private void saveCrop() {
        try {
            RectF frame = cropFrame();
            Matrix inv = new Matrix();
            if (!matrix.invert(inv)) throw new Exception("imagem inválida");
            RectF src = new RectF(frame); inv.mapRect(src);
            src.intersect(new RectF(0, 0, bmp.getWidth(), bmp.getHeight()));
            int l = Math.max(0, Math.round(src.left)), t = Math.max(0, Math.round(src.top));
            int r = Math.min(bmp.getWidth(), Math.round(src.right)), b = Math.min(bmp.getHeight(), Math.round(src.bottom));
            if (r <= l || b <= t) throw new Exception("área inválida");
            Bitmap out = Bitmap.createBitmap(bmp, l, t, r - l, b - t);
            if (toolbarMode) Prefs.saveToolbarBitmap(this, out);
            else Prefs.saveBackgroundBitmap(this, out);
            setResult(RESULT_OK); finish();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível aplicar o recorte", Toast.LENGTH_LONG).show();
        }
    }
    private class CropOverlay extends View {
        private final Paint dim = new Paint(); private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        CropOverlay(android.content.Context c) { super(c); dim.setColor(0x99000000); border.setColor(Color.WHITE); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(dp(2)); }
        @Override protected void onDraw(Canvas c) {
            RectF r = cropFrame();
            c.drawRect(0, 0, getWidth(), r.top, dim);
            c.drawRect(0, r.bottom, getWidth(), getHeight(), dim);
            c.drawRect(0, r.top, r.left, r.bottom, dim);
            c.drawRect(r.right, r.top, getWidth(), r.bottom, dim);
            c.drawRect(r, border);
            border.setColor(0x88FFFFFF); border.setStrokeWidth(1);
            c.drawLine(r.centerX(), r.top, r.centerX(), r.bottom, border); c.drawLine(r.left, r.centerY(), r.right, r.centerY(), border);
            border.setColor(Color.WHITE); border.setStrokeWidth(dp(2));
        }
    }
    @Override protected void onDestroy() { if (bmp != null && !bmp.isRecycled()) bmp.recycle(); super.onDestroy(); }
}
